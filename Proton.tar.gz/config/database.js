const mysql = require('mysql2/promise');
require('dotenv').config();

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  port: process.env.DB_PORT || 3306,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0
});

// Función para ejecutar consultas
async function query(sql, params) {
  try {
    const [rows] = await pool.execute(sql, params);
    return rows;
  } catch (error) {
    console.error('Error en consulta MySQL:', error);
    throw error;
  }
}

// Inicializar tablas
async function initializeDatabase() {
  const queries = [
    // Tabla de servidores
    `CREATE TABLE IF NOT EXISTS servers (
            id VARCHAR(255) PRIMARY KEY,
            name VARCHAR(255),
            owner_id VARCHAR(255),
            prefix VARCHAR(10) DEFAULT '!',
            logs_channel VARCHAR(255),
            premium_level INT DEFAULT 0,
            premium_until DATETIME,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )`,
    
    // Tabla de configuración anti-raid
    `CREATE TABLE IF NOT EXISTS antiraid_config (
            id INT AUTO_INCREMENT PRIMARY KEY,
            server_id VARCHAR(255),
            module VARCHAR(50),
            enabled BOOLEAN DEFAULT FALSE,
            sanction VARCHAR(20) DEFAULT 'kick',
            whitelist_enabled BOOLEAN DEFAULT FALSE,
            FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
        )`,
    
    // Tabla de whitelist
    `CREATE TABLE IF NOT EXISTS whitelist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            server_id VARCHAR(255),
            user_id VARCHAR(255),
            added_by VARCHAR(255),
            reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
        )`,
    
    // Tabla de blacklist global
    `CREATE TABLE IF NOT EXISTS blacklist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(255),
            added_by VARCHAR(255),
            reason TEXT,
            evidence TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,
    
    // Tabla de usuarios premium
    `CREATE TABLE IF NOT EXISTS premium_users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id VARCHAR(255),
            guild_id VARCHAR(255),
            tier INT DEFAULT 1,
            expires_at DATETIME,
            payment_id VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,
    
    // Tabla de reportes
    `CREATE TABLE IF NOT EXISTS reports (
            id INT AUTO_INCREMENT PRIMARY KEY,
            reporter_id VARCHAR(255),
            reported_id VARCHAR(255),
            guild_id VARCHAR(255),
            reason TEXT,
            evidence TEXT,
            status ENUM('pending', 'reviewed', 'action_taken', 'dismissed') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`,
    
    // Tabla de logs
    `CREATE TABLE IF NOT EXISTS logs (
            id INT AUTO_INCREMENT PRIMARY KEY,
            guild_id VARCHAR(255),
            user_id VARCHAR(255),
            action VARCHAR(100),
            target_id VARCHAR(255),
            reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )`
  ];
  
  for (const sql of queries) {
    try {
      await pool.execute(sql);
    } catch (error) {
      console.error('Error creando tabla:', error.message);
    }
  }
  
  console.log('✅ Base de datos inicializada');
}

module.exports = { pool, query, initializeDatabase };