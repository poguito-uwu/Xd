class Blacklist {
  constructor(data) {
    this.id = data.id;
    this.user_id = data.user_id;
    this.added_by = data.added_by;
    this.reason = data.reason;
    this.evidence = data.evidence;
    this.severity = data.severity || 'medium';
    this.expires_at = data.expires_at;
    this.created_at = data.created_at;
    this.updated_at = data.updated_at;
  }
  
  isExpired() {
    if (!this.expires_at) return false;
    return new Date(this.expires_at) < new Date();
  }
  
  isActive() {
    return !this.isExpired();
  }
  
  getSeverityColor() {
    const colors = {
      low: '#43b581',
      medium: '#faa61a',
      high: '#f04747',
      critical: '#ed4245'
    };
    return colors[this.severity] || '#faa61a';
  }
  
  toJSON() {
    return {
      id: this.id,
      user_id: this.user_id,
      added_by: this.added_by,
      reason: this.reason,
      evidence: this.evidence,
      severity: this.severity,
      expires_at: this.expires_at,
      is_active: this.isActive(),
      created_at: this.created_at,
      updated_at: this.updated_at
    };
  }
}

module.exports = Blacklist;