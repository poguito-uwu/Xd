class Server {
  constructor(data) {
    this.id = data.id;
    this.name = data.name;
    this.owner_id = data.owner_id;
    this.prefix = data.prefix || '!';
    this.logs_channel = data.logs_channel;
    this.locale = data.locale || 'es';
    this.premium_level = data.premium_level || 0;
    this.premium_until = data.premium_until;
    this.backup_count = data.backup_count || 0;
    this.created_at = data.created_at;
    this.updated_at = data.updated_at;
  }
  
  isPremium() {
    if (!this.premium_until) return false;
    return new Date(this.premium_until) > new Date();
  }
  
  getPremiumDaysLeft() {
    if (!this.isPremium()) return 0;
    const diff = new Date(this.premium_until) - new Date();
    return Math.ceil(diff / (1000 * 60 * 60 * 24));
  }
  
  toJSON() {
    return {
      id: this.id,
      name: this.name,
      owner_id: this.owner_id,
      prefix: this.prefix,
      logs_channel: this.logs_channel,
      locale: this.locale,
      premium_level: this.premium_level,
      premium_until: this.premium_until,
      is_premium: this.isPremium(),
      premium_days_left: this.getPremiumDaysLeft(),
      backup_count: this.backup_count,
      created_at: this.created_at,
      updated_at: this.updated_at
    };
  }
}

module.exports = Server;