// src/database/mysql.js - VERSIÓN COMPLETA CORREGIDA
const mysql = require('mysql2/promise');
require('dotenv').config();

class Database {
  constructor() {
    this.pool = null;
    this.isInitialized = false;
  }
  
  async initialize() {
    if (this.isInitialized) {
      console.log('✅ Base de datos ya inicializada');
      return this;
    }
    
    try {
      console.log('🔄 Conectando a MySQL...');
      
      if (!process.env.DB_HOST || !process.env.DB_USER || !process.env.DB_NAME) {
        console.error('❌ Variables de entorno de DB no configuradas');
        this.isInitialized = true;
        return this;
      }
      
      this.pool = mysql.createPool({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD || '',
        database: process.env.DB_NAME,
        port: process.env.DB_PORT || 3306,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
      });
      
      const connection = await this.pool.getConnection();
      console.log('✅ Conexión a MySQL establecida');
      connection.release();
      
      await this.createTables();
      this.isInitialized = true;
      console.log('✅ Base de datos completamente inicializada');
      return this;
    } catch (error) {
      console.error('❌ Error conectando a MySQL:', error.message);
      this.isInitialized = true;
      return this;
    }
  }
  
  async createTables() {
    if (!this.pool) return;
    
    const queries = [
      `CREATE TABLE IF NOT EXISTS servers (
        id VARCHAR(255) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        owner_id VARCHAR(255) NOT NULL,
        prefix VARCHAR(10) DEFAULT '!',
        logs_channel VARCHAR(255),
        locale VARCHAR(10) DEFAULT 'es',
        premium_level INT DEFAULT 0,
        premium_until DATETIME,
        backup_count INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
      
      `CREATE TABLE IF NOT EXISTS antiraid_config (
        id INT AUTO_INCREMENT PRIMARY KEY,
        server_id VARCHAR(255) NOT NULL,
        module VARCHAR(50) NOT NULL,
        enabled BOOLEAN DEFAULT FALSE,
        sanction VARCHAR(20) DEFAULT 'kick',
        whitelist_enabled BOOLEAN DEFAULT FALSE,
        custom_settings JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY unique_module (server_id, module)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`,
      
      `CREATE TABLE IF NOT EXISTS logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        guild_id VARCHAR(255) NOT NULL,
        user_id VARCHAR(255),
        action VARCHAR(100) NOT NULL,
        target_id VARCHAR(255),
        details JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    ];
    
    for (const sql of queries) {
      try {
        await this.pool.execute(sql);
      } catch (error) {
        console.error('Error creando tabla:', error.message);
      }
    }
  }
  
  async query(sql, params = []) {
    if (!this.pool || !this.isInitialized) return [];
    try {
      const [rows] = await this.pool.execute(sql, params);
      return rows;
    } catch (error) {
      console.error('❌ Error en consulta:', error.message);
      return [];
    }
  }
  
  async getServer(guildId) {
    try {
      const rows = await this.query('SELECT * FROM servers WHERE id = ?', [guildId]);
      return rows[0] || null;
    } catch (error) {
      console.error('Error obteniendo servidor:', error.message);
      return null;
    }
  }
  
  async updateServer(guildId, data) {
    try {
      const fields = Object.keys(data).map(key => `${key} = ?`).join(', ');
      const values = Object.values(data);
      values.push(guildId);
      
      const result = await this.query(
        `UPDATE servers SET ${fields}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        values
      );
      
      return result.affectedRows > 0;
    } catch (error) {
      console.error('Error actualizando servidor:', error.message);
      return false;
    }
  }
  
  async createLog(guildId, userId, action, targetId = null, details = null) {
    try {
      await this.query(
        `INSERT INTO logs (guild_id, user_id, action, target_id, details) 
         VALUES (?, ?, ?, ?, ?)`,
        [guildId, userId, action, targetId, JSON.stringify(details)]
      );
      return true;
    } catch (error) {
      console.error('Error creando log:', error.message);
      return false;
    }
  }
}

let dbInstance = null;

async function initializeDatabase() {
  if (!dbInstance) {
    dbInstance = new Database();
    await dbInstance.initialize();
  }
  return dbInstance;
}

function getInstance() {
  return dbInstance;
}

async function query(sql, params = []) {
  if (!dbInstance) await initializeDatabase();
  return dbInstance.query(sql, params);
}

module.exports = {
  initializeDatabase,
  query,
  getInstance,
  Database
};