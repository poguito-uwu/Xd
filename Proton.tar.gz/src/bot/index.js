const { Client, Collection, GatewayIntentBits, Partials, REST, Routes } = require('discord.js');
const { initializeDatabase, getInstance } = require('../database/mysql');
const ProtonEmbeds = require('../utils/embeds');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

// Colores para consola
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    dim: '\x1b[2m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m'
};

class Proton extends Client {
    constructor() {
        super({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.GuildMembers,
                GatewayIntentBits.GuildPresences,
                GatewayIntentBits.GuildModeration,
                GatewayIntentBits.GuildWebhooks,
                GatewayIntentBits.GuildInvites,
                GatewayIntentBits.GuildVoiceStates,
                GatewayIntentBits.GuildMessageReactions
            ],
            partials: [
                Partials.User, 
                Partials.Channel, 
                Partials.GuildMember, 
                Partials.Message, 
                Partials.Reaction
            ],
            failIfNotExists: false,
            allowedMentions: { 
                parse: ['users', 'roles'], 
                repliedUser: false 
            }
        });
        
        // Propiedades personalizadas
        this.commands = new Collection();
        this.embeds = new ProtonEmbeds();
        this.premium = require('../premium/manager');
        this.tempCache = new Map();
        
        // Inicializar db como objeto vacío primero
        this.db = {
            query: async (sql, params) => {
                console.error(`${colors.red}⚠️ DB no inicializada todavía. Query:${colors.reset}`, sql.substring(0, 50));
                return [];
            }
        };
        
        // Solo cargar estructura (sin logs individuales)
        this.loadCommands();
        this.loadEvents();
    }
    
    async initialize() {
        try {
            this.printBanner();
            
            // Inicializar base de datos PRIMERO
            console.log(`\n${colors.cyan}┌─────────────────────────────────────┐${colors.reset}`);
            console.log(`${colors.cyan}│${colors.reset}   ${colors.bright}🔄 INICIALIZANDO SISTEMA${colors.reset}        ${colors.cyan}│${colors.reset}`);
            console.log(`${colors.cyan}└─────────────────────────────────────┘${colors.reset}\n`);
            
            console.log(`${colors.yellow}📦 Base de datos:${colors.reset} Conectando...`);
            await initializeDatabase();
            
            const dbInstance = getInstance();
            
            // Exponer TODOS los métodos necesarios
            this.db = {
                query: dbInstance.query.bind(dbInstance),
                getServer: dbInstance.getServer.bind(dbInstance),
                createLog: dbInstance.createLog.bind(dbInstance),
                updateServer: dbInstance.updateServer.bind(dbInstance),
                getLogs: dbInstance.getLogs ? dbInstance.getLogs.bind(dbInstance) : null
            };
            
            console.log(`${colors.green}✅ Base de datos lista${colors.reset}`);
            
            // Iniciar sesión del bot
            console.log(`\n${colors.yellow}🔌 Discord:${colors.reset} Conectando...`);
            await this.login(process.env.TOKEN);
            
            console.log(`${colors.green}✅ Conectado como:${colors.reset} ${this.user.tag}`);
            console.log(`${colors.cyan}📊 Servidores:${colors.reset} ${this.guilds.cache.size}`);
            
            // Registrar comandos slash
            await this.registerSlashCommands();
            
            // Iniciar servidor API después de que el bot esté listo
            try {
                console.log(`\n${colors.yellow}🌐 API Server:${colors.reset} Iniciando...`);
                const apiServer = require('../api/server');
                // El servidor se inicia automáticamente al requerirlo
                console.log(`${colors.green}✅ API Server iniciado${colors.reset}`);
            } catch (error) {
                console.log(`${colors.yellow}⚠️ API Server no disponible:${colors.reset}`, error.message);
                console.log(`${colors.dim}   (Puedes ignorar esto si no usas el dashboard)${colors.reset}`);
            }
            
            console.log(`\n${colors.green}${colors.bright}✅ SISTEMA INICIADO CORRECTAMENTE${colors.reset}\n`);
            
        } catch (error) {
            console.error(`\n${colors.red}❌ Error al inicializar el bot:${colors.reset}`, error);
            process.exit(1);
        }
    }
    
    printBanner() {
        console.clear();
        console.log(`
${colors.cyan}╔══════════════════════════════════════════════════════════╗
║${colors.reset}${colors.bright}                    PROTON BOT v2.0.0                    ${colors.cyan}║
║${colors.reset}           Sistema Anti-Raid & Moderación Premium         ${colors.cyan}║
╚══════════════════════════════════════════════════════════╝${colors.reset}
        `);
    }
    
    async loadCommands() {
        const commandsPath = path.join(__dirname, '../commands');
        
        if (!fs.existsSync(commandsPath)) {
            console.log(`${colors.yellow}⚠️ No se encontró la carpeta de comandos${colors.reset}`);
            return;
        }
        
        const categories = fs.readdirSync(commandsPath);
        let totalCommands = 0;
        
        for (const category of categories) {
            const categoryPath = path.join(commandsPath, category);
            
            if (!fs.statSync(categoryPath).isDirectory()) continue;
            
            const commandFiles = fs.readdirSync(categoryPath)
                .filter(file => file.endsWith('.js'));
            
            let categoryCount = 0;
            
            for (const file of commandFiles) {
                const commandPath = path.join(categoryPath, file);
                
                try {
                    const command = require(commandPath);
                    
                    if (command.data && command.execute) {
                        this.commands.set(command.data.name, command);
                        categoryCount++;
                        totalCommands++;
                    }
                } catch (error) {
                    // Solo mostrar errores críticos
                    if (error.message.includes('Unexpected identifier') || error.message.includes('missing after argument')) {
                        console.log(`${colors.red}❌ Error en ${file}:${colors.reset} ${error.message}`);
                    }
                }
            }
            
            if (categoryCount > 0 && process.env.VERBOSE === 'true') {
                console.log(`${colors.dim}📁 ${category}: ${categoryCount} comandos${colors.reset}`);
            }
        }
        
        console.log(`${colors.cyan}📚 Comandos cargados:${colors.reset} ${totalCommands}`);
    }
    
    async loadEvents() {
        const eventsPath = path.join(__dirname, '../events');
        
        if (!fs.existsSync(eventsPath)) {
            console.log(`${colors.yellow}⚠️ No se encontró la carpeta de eventos${colors.reset}`);
            return;
        }
        
        let totalEvents = 0;
        
        // Buscar archivos directamente en events/
        const rootEvents = fs.readdirSync(eventsPath)
            .filter(file => file.endsWith('.js'));
            
        for (const file of rootEvents) {
            try {
                const eventPath = path.join(eventsPath, file);
                const event = require(eventPath);
                
                if (event.name && event.execute) {
                    if (event.once) {
                        this.once(event.name, (...args) => event.execute(...args, this));
                    } else {
                        this.on(event.name, (...args) => event.execute(...args, this));
                    }
                    totalEvents++;
                }
            } catch (error) {
                // Ignorar errores de eventos
            }
        }
        
        // Buscar en subcarpetas
        const eventCategories = fs.readdirSync(eventsPath)
            .filter(item => fs.statSync(path.join(eventsPath, item)).isDirectory());
        
        for (const category of eventCategories) {
            const categoryPath = path.join(eventsPath, category);
            const eventFiles = fs.readdirSync(categoryPath)
                .filter(file => file.endsWith('.js'));
            
            for (const file of eventFiles) {
                try {
                    const eventPath = path.join(categoryPath, file);
                    const event = require(eventPath);
                    
                    if (event.name && event.execute) {
                        if (event.once) {
                            this.once(event.name, (...args) => event.execute(...args, this));
                        } else {
                            this.on(event.name, (...args) => event.execute(...args, this));
                        }
                        totalEvents++;
                    }
                } catch (error) {
                    // Ignorar errores
                }
            }
        }
        
        console.log(`${colors.cyan}🎭 Eventos cargados:${colors.reset} ${totalEvents}`);
    }
    
    async registerSlashCommands() {
        try {
            const commands = [];
            
            for (const command of this.commands.values()) {
                commands.push(command.data.toJSON());
            }
            
            if (commands.length === 0) {
                console.log(`${colors.yellow}⚠️ No hay comandos para registrar${colors.reset}`);
                return;
            }
            
            const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
            
            console.log(`\n${colors.yellow}📡 Registrando comandos slash...${colors.reset}`);
            
            await rest.put(
                Routes.applicationCommands(process.env.CLIENT_ID),
                { body: commands }
            );
            
            console.log(`${colors.green}✅ ${commands.length} comandos slash registrados globalmente${colors.reset}`);
            
        } catch (error) {
            console.error(`${colors.red}❌ Error registrando comandos:${colors.reset}`, error.message);
        }
    }
    
    // Método para obtener configuración del servidor
    async getServerConfig(guildId) {
        try {
            if (!this.db || !this.db.query) {
                throw new Error('Base de datos no disponible');
            }
            
            const [server] = await this.db.query(
                'SELECT * FROM servers WHERE id = ?',
                [guildId]
            );
            
            if (!server) {
                const guild = this.guilds.cache.get(guildId);
                if (!guild) return null;
                
                await this.db.query(
                    'INSERT INTO servers (id, name, owner_id) VALUES (?, ?, ?)',
                    [guildId, guild.name, guild.ownerId]
                );
                
                return { 
                    id: guildId, 
                    name: guild.name, 
                    owner_id: guild.ownerId, 
                    premium_level: 0,
                    logs_channel: null
                };
            }
            
            return server;
        } catch (error) {
            console.error(`${colors.red}Error obteniendo configuración:${colors.reset}`, error.message);
            return null;
        }
    }
}

// Crear instancia del bot
const client = new Proton();

// Inicializar después de crear la instancia
client.initialize().catch(error => {
    console.error(`\n${colors.red}❌ Error fatal al inicializar:${colors.reset}`, error);
    process.exit(1);
});

// Manejo de errores
process.on('unhandledRejection', (reason, promise) => {
    console.error(`${colors.red}❌ Unhandled Rejection:${colors.reset}`, reason);
});

process.on('uncaughtException', (error) => {
    console.error(`${colors.red}❌ Uncaught Exception:${colors.reset}`, error);
});

module.exports = client;
