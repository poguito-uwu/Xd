const { REST, Routes } = require('discord.js');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function deployCommands() {
    const commands = [];
    const commandsPath = path.join(__dirname, '../commands');
    
    // Recorrer todas las categorías de comandos
    const categories = fs.readdirSync(commandsPath);
    
    for (const category of categories) {
        const categoryPath = path.join(commandsPath, category);
        
        if (!fs.statSync(categoryPath).isDirectory()) continue;
        
        const commandFiles = fs.readdirSync(categoryPath)
            .filter(file => file.endsWith('.js'));
        
        for (const file of commandFiles) {
            const commandPath = path.join(categoryPath, file);
            const command = require(commandPath);
            
            if (command.data) {
                commands.push(command.data.toJSON());
                console.log(`📁 Cargando comando: ${command.data.name}`);
            }
        }
    }
    
    const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
    
    try {
        console.log(`🔄 Registrando ${commands.length} comandos slash...`);
        
        // Comandos globales
        const data = await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: commands }
        );
        
        console.log(`✅ ${data.length} comandos slash registrados globalmente`);
        
        // También puedes registrar comandos por servidor para testing
        if (process.env.TEST_GUILD_ID) {
            console.log(`🔄 Registrando comandos en servidor de prueba...`);
            
            const guildData = await rest.put(
                Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.TEST_GUILD_ID),
                { body: commands }
            );
            
            console.log(`✅ ${guildData.length} comandos registrados en servidor de prueba`);
        }
        
    } catch (error) {
        console.error('❌ Error registrando comandos:', error);
    }
}

deployCommands();