const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const { inspect } = require('util');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('eval')
        .setDescription('Ejecuta código JavaScript (Solo dueños)')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addStringOption(option =>
            option.setName('codigo')
                .setDescription('Código JavaScript a ejecutar')
                .setRequired(true))
        .addBooleanOption(option =>
            option.setName('silencioso')
                .setDescription('Ejecutar sin mostrar resultado')
                .setRequired(false)),
    
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        
        // Verificar si es dueño
        const owners = process.env.OWNER_IDS?.split(',') || [];
        if (!owners.includes(interaction.user.id)) {
            return interaction.editReply({
                content: '❌ Este comando es solo para dueños del bot.'
            });
        }
        
        const code = interaction.options.getString('codigo');
        const silent = interaction.options.getBoolean('silencioso') || false;
        const embeds = new RB3Embeds();
        
        try {
            // Medir tiempo de ejecución
            const start = process.hrtime.bigint();
            
            // Ejecutar código
            let evaled = await eval(code);
            
            // Calcular tiempo
            const diff = (process.hrtime.bigint() - start) / BigInt(1000000); // ms
            
            // Si es una promesa, esperar
            if (evaled && evaled.then) {
                evaled = await evaled;
            }
            
            // Formatear salida
            let output = inspect(evaled, { 
                depth: 0,
                maxArrayLength: 10,
                maxStringLength: 1000
            });
            
            // Ocultar tokens sensibles
            const tokens = [
                client.token,
                process.env.TOKEN,
                process.env.DB_PASSWORD,
                process.env.JWT_SECRET,
                process.env.API_SECRET
            ];
            
            tokens.forEach(token => {
                if (token) {
                    output = output.replace(new RegExp(token, 'gi'), '[TOKEN OCULTO]');
                }
            });
            
            // Limitar longitud
            if (output.length > 1900) {
                output = output.substring(0, 1900) + '... (truncado)';
            }
            
            if (silent) {
                await interaction.editReply({
                    embeds: [embeds.success(
                        'Código ejecutado',
                        `✅ Código ejecutado en **${diff}ms** (silencioso)`
                    )]
                });
                
                // Registrar eval
                await client.db.createLog(interaction.guild?.id, interaction.user?.id, '0', null, interaction.user.id, 'eval_executed', null, {
                    time: Number(diff),
                    silent: true
                });
                
                return;
            }
            
            const embed = new EmbedBuilder()
                .setTitle('📝 Eval Resultado')
                .setColor('#43b581')
                .addFields(
                    {
                        name: '⏱️ Tiempo de ejecución',
                        value: `\`${diff}ms\``,
                        inline: true
                    },
                    {
                        name: '📤 Tipo de retorno',
                        value: `\`${typeof evaled}\``,
                        inline: true
                    }
                )
                .setDescription(`\`\`\`js\n${output}\n\`\`\``)
                .setFooter({ 
                    text: `Ejecutado por ${interaction.user.tag}`,
                    iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                })
                .setTimestamp();
            
            await interaction.editReply({ embeds: [embed] });
            
            // Registrar eval
            await client.db.createLog(interaction.guild?.id, interaction.user?.id, '0', null, interaction.user.id, 'eval_executed', null, {
                time: Number(diff),
                type: typeof evaled,
                output_length: output.length
            });
            
        } catch (error) {
            console.error('Error en eval:', error);
            
            let errorOutput = error.toString();
            
            // Ocultar tokens sensibles en errores también
            const tokens = [
                client.token,
                process.env.TOKEN,
                process.env.DB_PASSWORD,
                process.env.JWT_SECRET,
                process.env.API_SECRET
            ];
            
            tokens.forEach(token => {
                if (token) {
                    errorOutput = errorOutput.replace(new RegExp(token, 'gi'), '[TOKEN OCULTO]');
                }
            });
            
            // Limitar longitud
            if (errorOutput.length > 1900) {
                errorOutput = errorOutput.substring(0, 1900) + '... (truncado)';
            }
            
            const embed = embeds.error(
                '❌ Error en Eval',
                `\`\`\`js\n${errorOutput}\n\`\`\``
            );
            
            await interaction.editReply({ embeds: [embed] });
            
            // Registrar error de eval
            await client.db.createLog(interaction.guild?.id, interaction.user?.id, '0', null, interaction.user.id, 'eval_error', null, {
                error: error.message,
                stack: error.stack?.substring(0, 500)
            });
        }
    }
};