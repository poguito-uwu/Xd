const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('backup')
        .setDescription('Gestiona backups de la configuración')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Crea un backup de la configuración actual')
                .addStringOption(option =>
                    option.setName('nombre')
                        .setDescription('Nombre del backup')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('Lista todos los backups disponibles'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('load')
                .setDescription('Carga un backup específico')
                .addStringOption(option =>
                    option.setName('id')
                        .setDescription('ID del backup a cargar')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('delete')
                .setDescription('Elimina un backup')
                .addStringOption(option =>
                    option.setName('id')
                        .setDescription('ID del backup a eliminar')
                        .setRequired(true))),
    
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        
        const subcommand = interaction.options.getSubcommand();
        const embeds = new RB3Embeds();
        
        switch (subcommand) {
            case 'create':
                await this.createBackup(interaction, client, embeds);
                break;
            case 'list':
                await this.listBackups(interaction, client, embeds);
                break;
            case 'load':
                await this.loadBackup(interaction, client, embeds);
                break;
            case 'delete':
                await this.deleteBackup(interaction, client, embeds);
                break;
        }
    },
    
    async createBackup(interaction, client, embeds) {
        const guildId = interaction.guildId;
        const name = interaction.options.getString('nombre') || `Backup-${new Date().toISOString().split('T')[0]}`;
        
        // Verificar límites premium
        const premium = await client.premium.hasPremium(guildId);
        const tier = premium ? premium.tier : 0;
        const limits = client.premium.getLimits(tier);
        
        // Obtener conteo actual de backups
        const [count] = await client.db.query(
            'SELECT COUNT(*) as count FROM backups WHERE guild_id = ?',
            [guildId]
        );
        
        if (count.count >= limits.maxBackups) {
            return interaction.editReply({
                embeds: [embeds.error(
                    'Límite de backups alcanzado',
                    `
Tu servidor ha alcanzado el límite máximo de backups.
                    
**Límite actual:** ${limits.maxBackups} backups
**Backups actuales:** ${count.count}
                    
**Planes superiores:**
• **Tier 1 (Básico):** ${client.premium.getLimits(1).maxBackups} backups - $4.99/mes
• **Tier 2 (Pro):** ${client.premium.getLimits(2).maxBackups} backups - $9.99/mes
                    
[**Mejorar a Premium**](${process.env.DASHBOARD_URL}/premium)
                    `
                )]
            });
        }
        
        try {
            // Obtener configuración actual
            const antiraidConfig = await client.db.query(
                'SELECT * FROM antiraid_config WHERE server_id = ?',
                [guildId]
            );
            
            const whitelist = await client.db.query(
                'SELECT * FROM whitelist WHERE server_id = ?',
                [guildId]
            );
            
            const backupData = {
                antiraid: antiraidConfig,
                whitelist: whitelist,
                timestamp: new Date().toISOString(),
                created_by: interaction.user.id,
                guild_name: interaction.guild.name
            };
            
            // Crear backup
            await client.db.query(
                'INSERT INTO backups (guild_id, name, data, created_by) VALUES (?, ?, ?, ?)',
                [guildId, name, JSON.stringify(backupData), interaction.user.id]
            );
            
            // Actualizar conteo de backups
            await client.db.query(
                'UPDATE servers SET backup_count = backup_count + 1 WHERE id = ?',
                [guildId]
            );
            
            const embed = embeds.success(
                'Backup creado',
                `
✅ **Backup creado exitosamente**
                
**Nombre:** ${name}
**ID:** \`${name.replace(/[^a-zA-Z0-9]/g, '-').toLowerCase()}\`
**Contenido:**
• Configuración anti-raid: ${antiraidConfig.length} módulos
• Whitelist: ${whitelist.length} usuarios
• Fecha: <t:${Math.floor(Date.now() / 1000)}:F>
                
**Total de backups:** ${count.count + 1}/${limits.maxBackups}
                `
            );
            
            await interaction.editReply({ embeds: [embed] });
            
            // Registrar en logs
            await client.db.createLog(interaction.guild?.id, interaction.user?.id, guildId, null, interaction.user.id, 'backup_create', null, {
                backup_name: name,
                modules: antiraidConfig.length,
                whitelist_users: whitelist.length
            });
            
        } catch (error) {
            console.error('Error creando backup:', error);
            
            await interaction.editReply({
                embeds: [embeds.error(
                    'Error',
                    'Ocurrió un error al crear el backup.'
                )]
            });
        }
    },
    
    async listBackups(interaction, client, embeds) {
        const guildId = interaction.guildId;
        
        const backups = await client.db.query(
            'SELECT * FROM backups WHERE guild_id = ? ORDER BY created_at DESC',
            [guildId]
        );
        
        if (backups.length === 0) {
            return interaction.editReply({
                embeds: [embeds.info(
                    'No hay backups',
                    'No hay backups disponibles para este servidor.'
                )]
            });
        }
        
        const backupList = backups.map((backup, index) => {
            const data = JSON.parse(backup.data);
            return `**${index + 1}.** \`${backup.name}\` - ${data.antiraid.length} módulos, ${data.whitelist.length} usuarios - <t:${Math.floor(new Date(backup.created_at).getTime() / 1000)}:R>`;
        }).join('\n');
        
        const embed = embeds.info(
            'Backups disponibles',
            `
**Total de backups:** ${backups.length}
                
${backupList}
                
**Para cargar un backup:** \`/backup load id:<nombre>\`
**Para eliminar un backup:** \`/backup delete id:<nombre>\`
                `
        );
        
        await interaction.editReply({ embeds: [embed] });
    },
    
    async loadBackup(interaction, client, embeds) {
        const guildId = interaction.guildId;
        const backupId = interaction.options.getString('id');
        
        try {
            // Buscar backup
            const [backup] = await client.db.query(
                'SELECT * FROM backups WHERE guild_id = ? AND (id = ? OR name = ?)',
                [guildId, backupId, backupId]
            );
            
            if (!backup) {
                return interaction.editReply({
                    embeds: [embeds.error(
                        'Backup no encontrado',
                        `No se encontró un backup con ID o nombre \`${backupId}\`.`
                    )]
                });
            }
            
            const backupData = JSON.parse(backup.data);
            
            // Confirmación
            const embed = embeds.warning(
                'Confirmar carga de backup',
                `
⚠️ **¿Estás seguro de que deseas cargar este backup?**
                
**Backup:** ${backup.name}
**Fecha de creación:** <t:${Math.floor(new Date(backup.created_at).getTime() / 1000)}:F>
**Creado por:** <@${backupData.created_by}>
                
**Este proceso:**
1. **Eliminará** toda la configuración anti-raid actual
2. **Eliminará** todos los usuarios de la whitelist actual
3. **Restaurará** la configuración del backup
                
**Contenido del backup:**
• **Módulos anti-raid:** ${backupData.antiraid.length}
• **Usuarios whitelist:** ${backupData.whitelist.length}
                
**Esta acción no se puede deshacer.**
                `
            );
            
            // Aquí deberías añadir botones de confirmación
            // Por simplicidad, procedemos directamente
            
            // Eliminar configuración actual
            await client.db.query(
                'DELETE FROM antiraid_config WHERE server_id = ?',
                [guildId]
            );
            
            await client.db.query(
                'DELETE FROM whitelist WHERE server_id = ?',
                [guildId]
            );
            
            // Restaurar configuración del backup
            for (const config of backupData.antiraid) {
                await client.db.query(
                    `INSERT INTO antiraid_config (server_id, module, enabled, sanction, whitelist_enabled) 
                     VALUES (?, ?, ?, ?, ?)`,
                    [guildId, config.module, config.enabled, config.sanction, config.whitelist_enabled]
                );
            }
            
            for (const wl of backupData.whitelist) {
                await client.db.query(
                    `INSERT INTO whitelist (server_id, user_id, added_by, reason, expires_at) 
                     VALUES (?, ?, ?, ?, ?)`,
                    [guildId, wl.user_id, wl.added_by, wl.reason, wl.expires_at]
                );
            }
            
            const successEmbed = embeds.success(
                'Backup cargado',
                `
✅ **Backup cargado exitosamente**
                
**Backup:** ${backup.name}
**Módulos restaurados:** ${backupData.antiraid.length}
**Usuarios whitelist restaurados:** ${backupData.whitelist.length}
**Restaurado por:** <@${interaction.user.id}>
                
**Configuración anterior eliminada.**
                `
            );
            
            await interaction.editReply({ embeds: [successEmbed] });
            
            // Registrar en logs
            await client.db.createLog(interaction.guild?.id, interaction.user?.id, guildId, null, interaction.user.id, 'backup_load', null, {
                backup_name: backup.name,
                modules: backupData.antiraid.length,
                whitelist_users: backupData.whitelist.length
            });
            
        } catch (error) {
            console.error('Error cargando backup:', error);
            
            await interaction.editReply({
                embeds: [embeds.error(
                    'Error',
                    'Ocurrió un error al cargar el backup.'
                )]
            });
        }
    },
    
    async deleteBackup(interaction, client, embeds) {
        const guildId = interaction.guildId;
        const backupId = interaction.options.getString('id');
        
        try {
            // Buscar backup
            const [backup] = await client.db.query(
                'SELECT * FROM backups WHERE guild_id = ? AND (id = ? OR name = ?)',
                [guildId, backupId, backupId]
            );
            
            if (!backup) {
                return interaction.editReply({
                    embeds: [embeds.error(
                        'Backup no encontrado',
                        `No se encontró un backup con ID o nombre \`${backupId}\`.`
                    )]
                });
            }
            
            // Eliminar backup
            await client.db.query(
                'DELETE FROM backups WHERE id = ?',
                [backup.id]
            );
            
            // Actualizar conteo de backups
            await client.db.query(
                'UPDATE servers SET backup_count = GREATEST(backup_count - 1, 0) WHERE id = ?',
                [guildId]
            );
            
            const embed = embeds.success(
                'Backup eliminado',
                `
✅ **Backup eliminado exitosamente**
                
**Backup eliminado:** ${backup.name}
**Eliminado por:** <@${interaction.user.id}>
                
**Esta acción no se puede deshacer.**
                `
            );
            
            await interaction.editReply({ embeds: [embed] });
            
            // Registrar en logs
            await client.db.createLog(interaction.guild?.id, interaction.user?.id, guildId, null, interaction.user.id, 'backup_delete', null, {
                backup_name: backup.name
            });
            
        } catch (error) {
            console.error('Error eliminando backup:', error);
            
            await interaction.editReply({
                embeds: [embeds.error(
                    'Error',
                    'Ocurrió un error al eliminar el backup.'
                )]
            });
        }
    }
};