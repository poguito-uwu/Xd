const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription('[OWNER] Gestiona la blacklist global del bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addSubcommand(subcommand =>
      subcommand
        .setName('add')
        .setDescription('Añade un usuario a la blacklist global')
        .addUserOption(option =>
          option.setName('usuario')
            .setDescription('Usuario a blacklistear')
            .setRequired(true))
        .addStringOption(option =>
          option.setName('razon')
            .setDescription('Razón de la blacklist')
            .setRequired(true))
        .addAttachmentOption(option =>
          option.setName('evidencia')
            .setDescription('Evidencia (imágenes, logs, etc.)')
            .setRequired(false)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('remove')
        .setDescription('Remueve un usuario de la blacklist global')
        .addUserOption(option =>
          option.setName('usuario')
            .setDescription('Usuario a remover')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('check')
        .setDescription('Verifica si un usuario está en la blacklist')
        .addUserOption(option =>
          option.setName('usuario')
            .setDescription('Usuario a verificar')
            .setRequired(true)))
    .addSubcommand(subcommand =>
      subcommand
        .setName('list')
        .setDescription('Muestra la lista de usuarios blacklisteados')),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    // VALIDACIÓN CRÍTICA: Solo el owner puede usar este comando
    const owners = (process.env.OWNER_IDS || process.env.OWNER_ID || '')
      .split(',')
      .map(id => id.trim())
      .filter(Boolean);
    
    if (!owners.includes(interaction.user.id)) {
      return interaction.editReply({
        embeds: [client.embeds.error(
          'Sin permisos',
          'Solo el owner del bot puede usar este comando.'
        )]
      });
    }
    
    const subcommand = interaction.options.getSubcommand();
    
    try {
      switch (subcommand) {
        case 'add':
          await this.addToBlacklist(interaction, client);
          break;
        case 'remove':
          await this.removeFromBlacklist(interaction, client);
          break;
        case 'check':
          await this.checkBlacklist(interaction, client);
          break;
        case 'list':
          await this.listBlacklist(interaction, client);
          break;
      }
    } catch (error) {
      console.error('[Blacklist] Error:', error);
      
      await interaction.editReply({
        embeds: [client.embeds.error(
          'Error',
          'Ocurrió un error al procesar el comando.'
        )]
      }).catch(() => {});
    }
  },
  
  async addToBlacklist(interaction, client) {
    const user = interaction.options.getUser('usuario');
    const reason = interaction.options.getString('razon');
    const evidence = interaction.options.getAttachment('evidencia');
    
    // VALIDACIÓN: No blacklistear al owner
    const owners = (process.env.OWNER_IDS || process.env.OWNER_ID || '')
      .split(',')
      .map(id => id.trim())
      .filter(Boolean);
    
    if (owners.includes(user.id)) {
      return interaction.editReply({
        embeds: [client.embeds.error(
          'Error',
          'No puedes blacklistear al owner del bot.'
        )]
      });
    }
    
    // VALIDACIÓN: No blacklistear al bot mismo
    if (user.id === client.user.id) {
      return interaction.editReply({
        embeds: [client.embeds.error(
          'Error',
          'No puedes blacklistear al bot.'
        )]
      });
    }
    
    // Verificar si ya está blacklisteado
    const existing = await client.db.query(
      'SELECT * FROM blacklist WHERE user_id = ?',
      [user.id]
    );
    
    if (existing && existing.length > 0) {
      return interaction.editReply({
        embeds: [client.embeds.warning(
          'Usuario ya blacklisteado',
          `<@${user.id}> ya está en la blacklist global.\n\n**Razón anterior:** ${existing[0].reason}\n**Añadido por:** <@${existing[0].added_by}>\n**Fecha:** <t:${Math.floor(new Date(existing[0].created_at).getTime() / 1000)}:F>`
        )]
      });
    }
    
    // Añadir a la blacklist
    await client.db.query(
      'INSERT INTO blacklist (user_id, added_by, reason, evidence) VALUES (?, ?, ?, ?)',
      [user.id, interaction.user.id, reason, evidence?.url || null]
    );
    
    // Banear en servidores (con límite de seguridad)
    let bannedIn = 0;
    let errors = 0;
    const guilds = Array.from(client.guilds.cache.values());
    const maxBans = 50; // Límite de seguridad para evitar rate limiting
    
    for (const guild of guilds.slice(0, maxBans)) {
      try {
        // Verificar que el bot tenga permisos
        const botMember = guild.members.me;
        if (!botMember || !botMember.permissions.has('BanMembers')) {
          continue;
        }
        
        const member = await guild.members.fetch(user.id).catch(() => null);
        
        if (member) {
          // Verificar jerarquía
          if (member.roles.highest.position >= botMember.roles.highest.position) {
            continue; // No puede banear por jerarquía
          }
          
          // No banear al owner del servidor
          if (guild.ownerId === user.id) {
            continue;
          }
          
          await member.ban({
            reason: `Blacklist Global: ${reason} | Moderador: ${interaction.user.tag}`,
            deleteMessageSeconds: 0 // No borrar mensajes antiguos
          });
          
          bannedIn++;
          
          // Enviar log al servidor (sin bloquear)
          try {
            const serverConfig = await client.db.getServer(guild.id);
            
            if (serverConfig?.logs_channel) {
              const logChannel = guild.channels.cache.get(serverConfig.logs_channel);
              
              if (logChannel && logChannel.permissionsFor(botMember).has(['SendMessages', 'EmbedLinks'])) {
                const logEmbed = client.embeds.error(
                  '🔨 Blacklist Global',
                  `**Usuario blacklisteado:** <@${user.id}> (\`${user.tag}\`)\n**Razón:** ${reason}\n**Moderador:** ${interaction.user.tag}\n\nEste usuario ha sido baneado de este servidor automáticamente.`
                );
                
                await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
              }
            }
          } catch (logError) {
            // Ignorar errores de log, continuar con siguiente servidor
          }
          
          // Pequeño delay para evitar rate limiting
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      } catch (error) {
        errors++;
        console.error(`[Blacklist] Error baneando en ${guild.name}:`, error.message);
      }
    }
    
    // Respuesta al moderador
    const embed = client.embeds.success(
      '✅ Usuario añadido a la blacklist global',
      `**Usuario:** <@${user.id}> (\`${user.tag}\`)
**ID:** \`${user.id}\`
**Razón:** ${reason}
${evidence ? `**Evidencia:** [Ver archivo](${evidence.url})` : ''}

**Resultados:**
• Baneado en: **${bannedIn}** servidor(es)
• Errores: **${errors}**
${guilds.length > maxBans ? `\n⚠️ Se procesaron solo ${maxBans} de ${guilds.length} servidores para evitar rate limiting.` : ''}`
    );
    
    await interaction.editReply({ embeds: [embed] });
    
    // Log en consola
    console.log(`[Blacklist] ${user.tag} (${user.id}) añadido por ${interaction.user.tag}. Baneado en ${bannedIn} servidores.`);
  },
  
  async removeFromBlacklist(interaction, client) {
    const user = interaction.options.getUser('usuario');
    
    // Verificar si está blacklisteado
    const existing = await client.db.query(
      'SELECT * FROM blacklist WHERE user_id = ?',
      [user.id]
    );
    
    if (!existing || existing.length === 0) {
      return interaction.editReply({
        embeds: [client.embeds.warning(
          'Usuario no encontrado',
          `<@${user.id}> no está en la blacklist global.`
        )]
      });
    }
    
    // Remover de la blacklist
    await client.db.query(
      'DELETE FROM blacklist WHERE user_id = ?',
      [user.id]
    );
    
    const embed = client.embeds.success(
      '✅ Usuario removido de la blacklist',
      `**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Razón original:** ${existing[0].reason}
**Añadido por:** <@${existing[0].added_by}>

El usuario ha sido removido de la blacklist global. **Nota:** Los bans en servidores individuales NO se remueven automáticamente.`
    );
    
    await interaction.editReply({ embeds: [embed] });
    
    console.log(`[Blacklist] ${user.tag} (${user.id}) removido por ${interaction.user.tag}`);
  },
  
  async checkBlacklist(interaction, client) {
    const user = interaction.options.getUser('usuario');
    
    const existing = await client.db.query(
      'SELECT * FROM blacklist WHERE user_id = ?',
      [user.id]
    );
    
    if (!existing || existing.length === 0) {
      return interaction.editReply({
        embeds: [client.embeds.success(
          '✅ Usuario no blacklisteado',
          `<@${user.id}> (\`${user.tag}\`) **NO** está en la blacklist global.`
        )]
      });
    }
    
    const blacklist = existing[0];
    
    const embed = client.embeds.warning(
      '⚠️ Usuario blacklisteado',
      `**Usuario:** <@${user.id}> (\`${user.tag}\`)
**ID:** \`${user.id}\`
**Razón:** ${blacklist.reason}
**Añadido por:** <@${blacklist.added_by}>
**Fecha:** <t:${Math.floor(new Date(blacklist.created_at).getTime() / 1000)}:F>
${blacklist.evidence ? `**Evidencia:** [Ver archivo](${blacklist.evidence})` : ''}`
    );
    
    await interaction.editReply({ embeds: [embed] });
  },
  
  async listBlacklist(interaction, client) {
    const blacklist = await client.db.query(
      'SELECT * FROM blacklist ORDER BY created_at DESC LIMIT 20'
    );
    
    if (!blacklist || blacklist.length === 0) {
      return interaction.editReply({
        embeds: [client.embeds.info(
          '📋 Blacklist vacía',
          'No hay usuarios en la blacklist global actualmente.'
        )]
      });
    }
    
    const list = blacklist.map((entry, index) => {
      const date = Math.floor(new Date(entry.created_at).getTime() / 1000);
      return `**${index + 1}.** <@${entry.user_id}> (\`${entry.user_id}\`)
   • Razón: ${entry.reason.substring(0, 100)}${entry.reason.length > 100 ? '...' : ''}
   • Por: <@${entry.added_by}> | <t:${date}:R>`;
    }).join('\n\n');
    
    const embed = client.embeds.info(
      '📋 Blacklist Global',
      `**Total de usuarios:** ${blacklist.length}${blacklist.length >= 20 ? ' (mostrando últimos 20)' : ''}\n\n${list}`
    );
    
    await interaction.editReply({ embeds: [embed] });
  }
};