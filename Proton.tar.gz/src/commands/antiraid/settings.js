const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('settings')
        .setDescription('Configura las funciones avanzadas de protección')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('view')
                .setDescription('Ver configuración actual'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('configure')
                .setDescription('Configurar una función específica')
                .addStringOption(option =>
                    option.setName('funcion')
                        .setDescription('Función a configurar')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Anti Flood', value: 'anti-flood' },
                            { name: 'Anti Alts', value: 'anti-alts' },
                            { name: 'Anti Links Maliciosos', value: 'anti-links' },
                            { name: 'Anti Mass Mute', value: 'anti-mass-mute' },
                            { name: 'Anti Webhook Spam', value: 'anti-webhook-spam' },
                            { name: 'Anti Everyone Permission', value: 'anti-everyone-permission' }
                        ))),
    
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        
        const subcommand = interaction.options.getSubcommand();
        const embeds = new RB3Embeds();
        
        if (subcommand === 'view') {
            await this.viewSettings(interaction, client, embeds);
        } else if (subcommand === 'configure') {
            await this.configureFunction(interaction, client, embeds);
        }
    },
    
    async viewSettings(interaction, client, embeds) {
        const guildId = interaction.guildId;
        const premium = await client.premium.hasPremium(guildId);
        const tier = premium ? premium.tier : 0;
        const limits = client.premium.getLimits(tier);
        
        // Obtener configuración actual
        const configs = await client.db.query(
            'SELECT * FROM antiraid_config WHERE server_id = ?',
            [guildId]
        );
        
        const enabledModules = configs.filter(c => c.enabled).length;
        
        // Crear embed de configuración
        const embed = new EmbedBuilder()
            .setTitle('<:config:947090506289119272> Configuración de Proton')
            .setColor('#2c2f33')
            .addFields(
                {
                    name: '📊 Estado Premium',
                    value: premium 
                        ? `**Tier ${tier}** (Expira: <t:${Math.floor(new Date(premium.expires_at).getTime() / 1000)}:R>)`
                        : '**Gratuito** - [Mejorar](https://tudominio.com/premium)',
                    inline: true
                },
                {
                    name: '🛡️ Módulos Activos',
                    value: `${enabledModules}/${limits.maxModules}`,
                    inline: true
                },
                {
                    name: '👤 Whitelist',
                    value: '0/∞', // Podrías obtener el conteo real
                    inline: true
                }
            )
            .addFields(
                {
                    name: '🚫 Funciones Premium',
                    value: `
${this.getFeatureStatus('Anti Flood', await client.premium.canUseFeature(guildId, 'anti-flood'))}
${this.getFeatureStatus('Anti Alts', await client.premium.canUseFeature(guildId, 'anti-alts'))}
${this.getFeatureStatus('Anti Links', await client.premium.canUseFeature(guildId, 'anti-links'))}
${this.getFeatureStatus('Anti Mass Mute', await client.premium.canUseFeature(guildId, 'anti-mass-mute'))}
${this.getFeatureStatus('Anti Webhook Spam', await client.premium.canUseFeature(guildId, 'anti-webhook-spam'))}
${this.getFeatureStatus('Anti Everyone', await client.premium.canUseFeature(guildId, 'anti-everyone-permission'))}
                    `,
                    inline: false
                }
            )
            .setFooter({ 
                text: `Tier ${tier} • Usa /settings configure para modificar` 
            })
            .setTimestamp();
        
        await interaction.editReply({ embeds: [embed] });
    },
    
    getFeatureStatus(name, available) {
        const icon = available ? '<a:aprobado:867704134861979698>' : '<a:denegado:867704135864418314>';
        const status = available ? 'Disponible' : 'Requiere Premium';
        return `${icon} **${name}:** ${status}`;
    },
    
    async configureFunction(interaction, client, embeds) {
        const functionName = interaction.options.getString('funcion');
        const guildId = interaction.guildId;
        
        // Verificar si la función está disponible
        const canUse = await client.premium.canUseFeature(guildId, functionName);
        
        if (!canUse) {
            return interaction.editReply({
                embeds: [embeds.error(
                    'Función Premium',
                    `
Esta función requiere **Premium Tier 1** o superior.
                    
**Funciones incluidas en Premium:**
• Anti Flood - Detección de spam avanzada
• Anti Alts - Detección de cuentas alternativas
• Anti Links - Bloqueo de enlaces maliciosos
• Anti Everyone - Protección contra permisos peligrosos
                    
[**Obtener Premium**](https://tudominio.com/premium)
                    `
                )]
            });
        }
        
        // Mostrar configuración específica
        const functionConfigs = {
            'anti-flood': {
                name: 'Anti Flood',
                description: 'Protección contra spam de mensajes',
                options: [
                    { name: 'Máximo de mensajes', value: '5', default: true },
                    { name: 'Tiempo de ventana (segundos)', value: '10', default: true },
                    { name: 'Sanción', value: 'timeout', default: true }
                ]
            },
            'anti-alts': {
                name: 'Anti Alts',
                description: 'Detección de cuentas alternativas',
                options: [
                    { name: 'Edad mínima de cuenta (días)', value: '7', default: true },
                    { name: 'Acción', value: 'kick', default: true },
                    { name: 'Verificación requerida', value: 'false', default: true }
                ]
            },
            'anti-links': {
                name: 'Anti Links Maliciosos',
                description: 'Bloqueo de enlaces peligrosos',
                options: [
                    { name: 'Bloquear invitaciones Discord', value: 'true', default: true },
                    { name: 'Bloquear URL acortadas', value: 'true', default: true },
                    { name: 'Lista blanca de dominios', value: '', default: false }
                ]
            },
            'anti-mass-mute': {
                name: 'Anti Mass Mute',
                description: 'Protección contra mute masivo',
                options: [
                    { name: 'Máximo de mutes por minuto', value: '3', default: true },
                    { name: 'Acción', value: 'derank', default: true }
                ]
            },
            'anti-webhook-spam': {
                name: 'Anti Webhook Spam',
                description: 'Protección contra spam de webhooks',
                options: [
                    { name: 'Máximo de webhooks por usuario', value: '2', default: true },
                    { name: 'Sanción', value: 'ban', default: true }
                ]
            },
            'anti-everyone-permission': {
                name: 'Anti Everyone Permission',
                description: 'Protección contra permisos peligrosos en @everyone',
                options: [
                    { name: 'Monitorear permisos', value: 'true', default: true },
                    { name: 'Restaurar automáticamente', value: 'true', default: true }
                ]
            }
        };
        
        const config = functionConfigs[functionName];
        
        if (!config) {
            return interaction.editReply({
                embeds: [embeds.error('Error', 'Función no encontrada.')]
            });
        }
        
        // Crear embed de configuración
        const optionsText = config.options.map(opt => {
            const defaultValue = opt.default ? `(Predeterminado: ${opt.value})` : '';
            return `• **${opt.name}:** ${opt.value} ${defaultValue}`;
        }).join('\n');
        
        const embed = embeds.info(
            config.name,
            `
**Descripción:** ${config.description}
                    
**Configuración actual:**
${optionsText}
                    
**Para configurar esta función:**
1. Visita nuestro [Dashboard](${process.env.DASHBOARD_URL})
2. Selecciona tu servidor
3. Configura la función "${config.name}"
4. Guarda los cambios
                    
**Nota:** La configuración avanzada requiere el panel web para una mejor experiencia.
            `
        );
        
        // Botón para ir al dashboard
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setLabel('Configurar en Dashboard')
                    .setURL(`${process.env.DASHBOARD_URL}/dashboard/${guildId}`)
                    .setStyle(ButtonStyle.Link)
            );
        
        await interaction.editReply({
            embeds: [embed],
            components: [row]
        });
    }
};