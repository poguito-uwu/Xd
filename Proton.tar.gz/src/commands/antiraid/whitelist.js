const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('whitelist')
        .setDescription('Gestiona la whitelist del servidor')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Añade un usuario a la whitelist')
                .addUserOption(option =>
                    option.setName('usuario')
                        .setDescription('Usuario a whitelistear')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('razon')
                        .setDescription('Razón de la whitelist')
                        .setRequired(false))
                .addStringOption(option =>
                    option.setName('duracion')
                        .setDescription('Duración (ej: 7d, 1m, 1y)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Remueve un usuario de la whitelist')
                .addUserOption(option =>
                    option.setName('usuario')
                        .setDescription('Usuario a remover')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('Muestra la lista de usuarios whitelisteados'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('check')
                .setDescription('Verifica si un usuario está whitelisteado')
                .addUserOption(option =>
                    option.setName('usuario')
                        .setDescription('Usuario a verificar')
                        .setRequired(true))),
    
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        
        const subcommand = interaction.options.getSubcommand();
        const embeds = new RB3Embeds();
        
        switch (subcommand) {
            case 'add':
                await this.addWhitelist(interaction, client, embeds);
                break;
            case 'remove':
                await this.removeWhitelist(interaction, client, embeds);
                break;
            case 'list':
                await this.listWhitelist(interaction, client, embeds);
                break;
            case 'check':
                await this.checkWhitelist(interaction, client, embeds);
                break;
        }
    },
    
    async addWhitelist(interaction, client, embeds) {
        const user = interaction.options.getUser('usuario');
        const reason = interaction.options.getString('razon') || 'Sin razón especificada';
        const duration = interaction.options.getString('duracion');
        const guildId = interaction.guildId;
        
        // Verificar límites premium
        const premium = await client.premium.hasPremium(guildId);
        const tier = premium ? premium.tier : 0;
        const limits = client.premium.getLimits(tier);
        
        // Obtener conteo actual
        const [count] = await client.db.query(
            'SELECT COUNT(*) as count FROM whitelist WHERE server_id = ?',
            [guildId]
        );
        
        if (count.count >= limits.maxWhitelist) {
            return interaction.editReply({
                embeds: [embeds.error(
                    'Límite de whitelist alcanzado',
                    `
Tu servidor ha alcanzado el límite máximo de usuarios en whitelist.
                    
**Límite actual:** ${limits.maxWhitelist} usuarios
**Usuarios actuales:** ${count.count}
                    
**Planes superiores:**
• **Tier 1 (Básico):** ${client.premium.getLimits(1).maxWhitelist} usuarios - $4.99/mes
• **Tier 2 (Pro):** ${client.premium.getLimits(2).maxWhitelist} usuarios - $9.99/mes
                    
[**Mejorar a Premium**](${process.env.DASHBOARD_URL}/premium)
                    `
                )]
            });
        }
        
        // Verificar si ya está whitelisteado
        const existing = await client.db.query(
            'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
            [guildId, user.id]
        );
        
        if (existing.length > 0) {
            return interaction.editReply({
                embeds: [embeds.error(
                    'Usuario ya whitelisteado',
                    `<@${user.id}> ya está en la whitelist de este servidor.`
                )]
            });
        }
        
        // Calcular fecha de expiración
        let expiresAt = null;
        
        if (duration) {
            const match = duration.match(/(\d+)([dmy])/i);
            if (match) {
                const amount = parseInt(match[1]);
                const unit = match[2].toLowerCase();
                expiresAt = new Date();
                
                switch (unit) {
                    case 'd': expiresAt.setDate(expiresAt.getDate() + amount); break;
                    case 'm': expiresAt.setMonth(expiresAt.getMonth() + amount); break;
                    case 'y': expiresAt.setFullYear(expiresAt.getFullYear() + amount); break;
                }
            }
        }
        
        try {
            await client.db.query(
                `INSERT INTO whitelist (server_id, user_id, added_by, reason, expires_at) 
                 VALUES (?, ?, ?, ?, ?)`,
                [guildId, user.id, interaction.user.id, reason, expiresAt]
            );
            
            const embed = embeds.success(
                'Usuario añadido a whitelist',
                `
✅ **Usuario whitelisteado correctamente**
                
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Razón:** ${reason}
**Añadido por:** <@${interaction.user.id}>
${expiresAt ? `**Expira:** <t:${Math.floor(expiresAt.getTime() / 1000)}:F>` : '**Expiración:** Permanente'}
                
**Permisos otorgados:**
• Bypass del sistema anti-raid
• Inmunidad a sanciones automáticas
• Acceso a acciones protegidas
                `
            );
            
            await interaction.editReply({ embeds: [embed] });
            
            // Registrar en logs
            await client.db.createLog(interaction.guild?.id, interaction.user?.id, guildId, null, interaction.user.id, 'whitelist_add', user.id, {
                user_tag: user.tag,
                reason: reason,
                expires_at: expiresAt
            });
            
        } catch (error) {
            console.error('Error añadiendo whitelist:', error);
            
            await interaction.editReply({
                embeds: [embeds.error(
                    'Error',
                    'Ocurrió un error al añadir el usuario a la whitelist.'
                )]
            });
        }
    },
    
    async removeWhitelist(interaction, client, embeds) {
        const user = interaction.options.getUser('usuario');
        const guildId = interaction.guildId;
        
        const existing = await client.db.query(
            'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
            [guildId, user.id]
        );
        
        if (existing.length === 0) {
            return interaction.editReply({
                embeds: [embeds.error(
                    'Usuario no encontrado',
                    `<@${user.id}> no está en la whitelist de este servidor.`
                )]
            });
        }
        
        try {
            await client.db.query(
                'DELETE FROM whitelist WHERE server_id = ? AND user_id = ?',
                [guildId, user.id]
            );
            
            const embed = embeds.success(
                'Usuario removido de whitelist',
                `
✅ **Usuario removido de la whitelist**
                
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Removido por:** <@${interaction.user.id}>
                
**Nota:** El usuario ya no tendrá inmunidad al sistema anti-raid.
                `
            );
            
            await interaction.editReply({ embeds: [embed] });
            
            // Registrar en logs
            await client.db.createLog(interaction.guild?.id, interaction.user?.id, guildId, null, interaction.user.id, 'whitelist_remove', user.id, {
                user_tag: user.tag
            });
            
        } catch (error) {
            console.error('Error removiendo whitelist:', error);
            
            await interaction.editReply({
                embeds: [embeds.error(
                    'Error',
                    'Ocurrió un error al remover el usuario de la whitelist.'
                )]
            });
        }
    },
    
    async listWhitelist(interaction, client, embeds) {
        const guildId = interaction.guildId;
        
        const whitelist = await client.db.query(
            'SELECT * FROM whitelist WHERE server_id = ? ORDER BY created_at DESC LIMIT 20',
            [guildId]
        );
        
        if (whitelist.length === 0) {
            return interaction.editReply({
                embeds: [embeds.info(
                    'Whitelist vacía',
                    'No hay usuarios en la whitelist de este servidor.'
                )]
            });
        }
        
        // Formatear lista
        const list = whitelist.map((wl, index) => {
            const expires = wl.expires_at 
                ? `Expira: <t:${Math.floor(new Date(wl.expires_at).getTime() / 1000)}:R>`
                : 'Permanente';
            
            return `**${index + 1}.** <@${wl.user_id}> - ${expires}`;
        }).join('\n');
        
        const embed = embeds.info(
            'Whitelist del servidor',
            `
**Usuarios whitelisteados:** ${whitelist.length}
                
${list}
                
**Nota:** Los usuarios whitelisteados tienen inmunidad al sistema anti-raid.
                `
        );
        
        await interaction.editReply({ embeds: [embed] });
    },
    
    async checkWhitelist(interaction, client, embeds) {
        const user = interaction.options.getUser('usuario');
        const guildId = interaction.guildId;
        
        const [whitelist] = await client.db.query(
            'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
            [guildId, user.id]
        );
        
        if (!whitelist) {
            return interaction.editReply({
                embeds: [embeds.info(
                    'Usuario no whitelisteado',
                    `<@${user.id}> **NO está** en la whitelist de este servidor.`
                )]
            });
        }
        
        const addedBy = await client.users.fetch(whitelist.added_by).catch(() => ({ tag: 'Usuario desconocido' }));
        
        const embed = embeds.info(
            'Usuario en Whitelist',
            `
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Añadido por:** <@${addedBy.id}> (\`${addedBy.tag}\`)
**Fecha:** <t:${Math.floor(new Date(whitelist.created_at).getTime() / 1000)}:F>
**Razón:** ${whitelist.reason || 'No especificada'}
${whitelist.expires_at ? `**Expira:** <t:${Math.floor(new Date(whitelist.expires_at).getTime() / 1000)}:F>` : '**Expiración:** Permanente'}
                
**Estado:** ${whitelist.expires_at && new Date(whitelist.expires_at) < new Date() ? 'Expirado ❌' : 'Activo ✅'}
                `
        );
        
        await interaction.editReply({ embeds: [embed] });
    }
};