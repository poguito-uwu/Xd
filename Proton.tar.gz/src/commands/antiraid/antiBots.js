module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    // Verificar si es un bot
    if (!member.user.bot) return;
    
    const guild = member.guild;
    const guildId = guild.id;
    
    try {
      // Obtener configuración anti-bots
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'bot']
      );
      
      if (!config) return;
      
      // Verificar si el bot está verificado por Discord
      const isVerifiedBot = member.user.flags?.has('VerifiedBot');
      
      // Si no es un bot verificado y la protección está activada
      if (!isVerifiedBot) {
        const auditLogs = await guild.fetchAuditLogs({
          limit: 1,
          type: 28 // BOT_ADD
        });
        
        const auditEntry = auditLogs.entries.first();
        if (!auditEntry) return;
        
        const executor = guild.members.cache.get(auditEntry.executor.id);
        if (!executor) return;
        
        // Verificar permisos
        let perm = false;
        
        if (client.user.id === executor.id ||
          guild.ownerId === executor.id ||
          client.config.owner.includes(executor.id) ||
          await client.db.get(`owner_${client.user.id}_${executor.id}`) === true) {
          perm = true;
        }
        
        // Verificar whitelist global
        const [globalWhitelist] = await client.db.query(
          'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
          [guildId, executor.id]
        );
        
        if (globalWhitelist) perm = true;
        
        // Verificar whitelist del módulo
        if (config.whitelist_enabled) {
          const [moduleWhitelist] = await client.db.query(
            'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
            [guildId, executor.id]
          );
          
          if (moduleWhitelist) perm = true;
        }
        
        if (!perm) {
          const raison = `Anti-Bots | Bot no verificado añadido por ${executor.user.tag}`;
          
          // Eliminar el bot
          try {
            await member.ban({ reason: raison });
          } catch (error) {
            console.error(`Error baneando bot en ${guild.name}:`, error);
            
            // Si no se puede banear, intentar expulsar
            try {
              await member.kick(raison);
            } catch (kickError) {
              console.error(`Error expulsando bot en ${guild.name}:`, kickError);
            }
          }
          
          // Aplicar sanción al ejecutor
          let userPunish = false;
          
          try {
            switch (config.sanction) {
              case 'ban':
                await executor.ban({ reason: raison });
                userPunish = true;
                break;
              case 'kick':
                await executor.kick({ reason: raison });
                userPunish = true;
                break;
              case 'derank':
                await executor.roles.set([], { reason: raison });
                userPunish = true;
                break;
            }
          } catch (sanctionError) {
            console.error(`Error aplicando sanción ${config.sanction}:`, sanctionError);
          }
          
          // Enviar log
          const serverConfig = await client.db.getServer(guildId);
          
          if (serverConfig?.logs_channel) {
            const logChannel = guild.channels.cache.get(serverConfig.logs_channel);
            
            if (logChannel) {
              const embed = client.embeds.warning(
                'Bot no verificado detectado',
                `
**Bot:** ${member.user.tag} (\`${member.user.id}\`)
**Añadido por:** <@${executor.id}>
**Acción:** Bot eliminado
**Sanción ejecutor:** ${config.sanction} ${userPunish ? '✅' : '❌'}
**Razón:** ${raison}
                                `
              );
              
              await logChannel.send({ embeds: [embed] }).catch(() => {});
            }
          }
          
          // Registrar en base de datos
          await client.db.createLog(interaction.guild?.id, interaction.user?.id, guildId, null, executor.id, 'antibot_trigger', member.id, {
            bot_tag: member.user.tag,
            sanction: config.sanction,
            success: userPunish
          });
        }
      }
      
    } catch (error) {
      console.error('Error en antiBots:', error);
    }
  }
};