const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup')
        .setDescription('Configura el sistema anti-raid completo')
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(subcommand =>
            subcommand
                .setName('quick')
                .setDescription('Configuración rápida con valores por defecto')
                .addStringOption(option =>
                    option.setName('nivel')
                        .setDescription('Nivel de protección')
                        .setRequired(true)
                        .addChoices(
                            { name: 'Básico', value: 'basic' },
                            { name: 'Medio', value: 'medium' },
                            { name: 'Alto', value: 'high' },
                            { name: 'Máximo', value: 'max' }
                        )))
        .addSubcommand(subcommand =>
            subcommand
                .setName('manual')
                .setDescription('Configuración manual módulo por módulo'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('logs')
                .setDescription('Configura el canal de logs')
                .addChannelOption(option =>
                    option.setName('canal')
                        .setDescription('Canal para los logs')
                        .setRequired(true))),
    
    async execute(interaction, client) {
        await interaction.deferReply({ flags: 64 });
        
        const subcommand = interaction.options.getSubcommand();
        
        switch (subcommand) {
            case 'quick':
                await this.quickSetup(interaction, client);
                break;
            case 'manual':
                await this.manualSetup(interaction, client);
                break;
            case 'logs':
                await this.setupLogs(interaction, client);
                break;
        }
    },
    
    async quickSetup(interaction, client) {
        const level = interaction.options.getString('nivel');
        const guildId = interaction.guildId;
        
        const configs = {
            basic: {
                modules: ['channelcreate', 'channeldelete', 'rolecreate', 'roledelete', 'ban'],
                sanction: 'kick',
                whitelist: false
            },
            medium: {
                modules: ['channelcreate', 'channeldelete', 'channeledit', 'rolecreate', 'roledelete', 'roleedit', 'ban', 'kick', 'bot'],
                sanction: 'derank',
                whitelist: true
            },
            high: {
                modules: ['channelcreate', 'channeldelete', 'channeledit', 'rolecreate', 'roledelete', 'roleedit', 'ban', 'kick', 'bot', 'webhook', 'update', 'roleadd'],
                sanction: 'ban',
                whitelist: true
            },
            max: {
                modules: ['channelcreate', 'channeldelete', 'channeledit', 'rolecreate', 'roledelete', 'roleedit', 'ban', 'kick', 'bot', 'webhook', 'update', 'roleadd', 'pub', 'ping', 'spam'],
                sanction: 'ban',
                whitelist: true
            }
        };
        
        const config = configs[level];
        
        try {
            // Verificar si la base de datos está disponible
            if (!client.db || !client.db.query) {
                throw new Error('Base de datos no disponible');
            }
            
            // Eliminar configuraciones anteriores
            await client.db.query(
                'DELETE FROM antiraid_config WHERE server_id = ?',
                [guildId]
            );
            
            // Insertar nuevas configuraciones
            for (const module of config.modules) {
                await client.db.query(
                    `INSERT INTO antiraid_config (server_id, module, enabled, sanction, whitelist_enabled) 
                     VALUES (?, ?, TRUE, ?, ?)`,
                    [guildId, module, config.sanction, config.whitelist]
                );
            }
            
            const embed = client.embeds.success(
                'Configuración rápida completada',
                `✅ **Configuración anti-raid aplicada:** ${level.toUpperCase()}
                
**Módulos activados:** ${config.modules.length}
**Sanción predeterminada:** ${config.sanction}
**Whitelist bypass:** ${config.whitelist ? 'Activado' : 'Desactivado'}
                
**Módulos incluidos:**
${config.modules.map(m => `• ${this.getModuleName(m)}`).join('\n')}`
            );
            
            await interaction.editReply({ embeds: [embed] });
            
            // Registrar en logs
            if (client.db && client.db.createLog) {
                await client.db.createLog(
                    guildId,
                    interaction.user.id,
                    'antiraid_setup',
                    null,
                    {
                        level: level,
                        modules: config.modules,
                        sanction: config.sanction,
                        type: 'quick'
                    }
                );
            }
            
        } catch (error) {
            console.error('Error en quick setup:', error);
            
            await interaction.editReply({
                embeds: [client.embeds.error(
                    'Error',
                    'Ocurrió un error al configurar el anti-raid. Intenta de nuevo.'
                )]
            });
        }
    },
    
    async manualSetup(interaction, client) {
        const modules = [
            { label: 'Creación de canales', value: 'channelcreate', emoji: '📁' },
            { label: 'Eliminación de canales', value: 'channeldelete', emoji: '🗑️' },
            { label: 'Edición de canales', value: 'channeledit', emoji: '✏️' },
            { label: 'Creación de roles', value: 'rolecreate', emoji: '🎭' },
            { label: 'Eliminación de roles', value: 'roledelete', emoji: '❌' },
            { label: 'Edición de roles', value: 'roleedit', emoji: '⚙️' },
            { label: 'Añadir roles peligrosos', value: 'roleadd', emoji: '⚠️' },
            { label: 'Baneos', value: 'ban', emoji: '🔨' },
            { label: 'Expulsiones', value: 'kick', emoji: '👢' },
            { label: 'Añadir bots', value: 'bot', emoji: '🤖' },
            { label: 'Webhooks', value: 'webhook', emoji: '🔗' },
            { label: 'Editar servidor', value: 'update', emoji: '🏰' },
            { label: 'Publicidad', value: 'pub', emoji: '📢' },
            { label: 'Ping masivo', value: 'ping', emoji: '🔔' },
            { label: 'Spam', value: 'spam', emoji: '💬' }
        ];
        
        try {
            // Obtener configuración actual
            let enabledModules = [];
            if (client.db && client.db.query) {
                const currentConfig = await client.db.query(
                    'SELECT * FROM antiraid_config WHERE server_id = ? AND enabled = TRUE',
                    [interaction.guildId]
                );
                enabledModules = currentConfig.map(c => c.module);
            }
            
            // Variables para guardar las selecciones del usuario
            let selectedModules = [...enabledModules];
            let selectedSanction = 'derank';
            let whitelistEnabled = false;
            
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('setup_modules')
                .setPlaceholder('Selecciona los módulos a activar')
                .setMinValues(0)
                .setMaxValues(modules.length)
                .addOptions(
                    modules.map(module => ({
                        label: module.label,
                        value: module.value,
                        emoji: module.emoji,
                        default: enabledModules.includes(module.value)
                    }))
                );
            
            const sanctionMenu = new StringSelectMenuBuilder()
                .setCustomId('setup_sanction')
                .setPlaceholder('Selecciona sanción predeterminada')
                .addOptions([
                    { label: 'Derank (Quitar roles)', value: 'derank', emoji: '⬇️' },
                    { label: 'Kick (Expulsar)', value: 'kick', emoji: '👢' },
                    { label: 'Ban (Banear)', value: 'ban', emoji: '🔨' }
                ]);
            
            const whitelistMenu = new StringSelectMenuBuilder()
                .setCustomId('setup_whitelist')
                .setPlaceholder('Configurar whitelist bypass')
                .addOptions([
                    { label: 'Activado', value: 'true', emoji: '✅' },
                    { label: 'Desactivado', value: 'false', emoji: '❌' }
                ]);
            
            const rows = [
                new ActionRowBuilder().addComponents(selectMenu),
                new ActionRowBuilder().addComponents(sanctionMenu),
                new ActionRowBuilder().addComponents(whitelistMenu),
                new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('setup_apply')
                        .setLabel('Aplicar configuración')
                        .setStyle(ButtonStyle.Success)
                        .setEmoji('✅'),
                    new ButtonBuilder()
                        .setCustomId('setup_cancel')
                        .setLabel('Cancelar')
                        .setStyle(ButtonStyle.Danger)
                        .setEmoji('❌')
                )
            ];
            
            const embed = client.embeds.info(
                'Configuración manual anti-raid',
                `**Selecciona los módulos que deseas activar:**
                
**Módulos de protección:**
• **Canales:** Creación, eliminación y edición
• **Roles:** Creación, eliminación, edición y adición peligrosa
• **Miembros:** Baneos, expulsiones y añadir bots
• **Servidor:** Edición del servidor y webhooks
• **Mensajes:** Publicidad, ping masivo y spam

**Sanción predeterminada:** Acción a tomar cuando se detecte una infracción
**Whitelist bypass:** Permitir que usuarios whitelisteados realicen estas acciones

**Módulos actualmente activos:** ${enabledModules.length}`
            );
            
            const message = await interaction.editReply({
                embeds: [embed],
                components: rows
            });
            
            // Crear collector para manejar todas las interacciones
            const collector = message.createMessageComponentCollector({
                time: 300000 // 5 minutos
            });
            
            collector.on('collect', async (i) => {
                // Verificar que solo el usuario que ejecutó el comando pueda interactuar
                if (i.user.id !== interaction.user.id) {
                    return i.reply({
                        content: '❌ Solo quien ejecutó el comando puede usar estos menús.',
                        flags: 64
                    });
                }
                
                // Manejar selección de módulos
                if (i.customId === 'setup_modules') {
                    selectedModules = i.values;
                    await i.deferUpdate();
                }
                
                // Manejar selección de sanción
                if (i.customId === 'setup_sanction') {
                    selectedSanction = i.values[0];
                    await i.deferUpdate();
                }
                
                // Manejar selección de whitelist
                if (i.customId === 'setup_whitelist') {
                    whitelistEnabled = i.values[0] === 'true';
                    await i.deferUpdate();
                }
                
                // Aplicar configuración
                if (i.customId === 'setup_apply') {
                    await i.deferUpdate();
                    collector.stop('applied');
                    
                    try {
                        // Validar que haya al menos un módulo seleccionado
                        if (selectedModules.length === 0) {
                            const warnEmbed = client.embeds.warning(
                                'Sin módulos seleccionados',
                                'Debes seleccionar al menos un módulo para aplicar la configuración.'
                            );
                            
                            return await i.editReply({
                                embeds: [warnEmbed],
                                components: []
                            });
                        }
                        
                        // Guardar configuración en la base de datos
                        await client.db.query(
                            'DELETE FROM antiraid_config WHERE server_id = ?',
                            [interaction.guildId]
                        );
                        
                        for (const module of selectedModules) {
                            await client.db.query(
                                `INSERT INTO antiraid_config (server_id, module, enabled, sanction, whitelist_enabled) 
                                 VALUES (?, ?, TRUE, ?, ?)`,
                                [interaction.guildId, module, selectedSanction, whitelistEnabled]
                            );
                        }
                        
                        const successEmbed = client.embeds.success(
                            'Configuración aplicada',
                            `✅ **Configuración anti-raid guardada exitosamente**
                            
**Módulos activados:** ${selectedModules.length}
**Sanción predeterminada:** ${selectedSanction}
**Whitelist bypass:** ${whitelistEnabled ? 'Activado' : 'Desactivado'}

**Módulos configurados:**
${selectedModules.map(m => `• ${this.getModuleName(m)}`).join('\n')}`
                        );
                        
                        await i.editReply({
                            embeds: [successEmbed],
                            components: []
                        });
                        
                        // Registrar en logs
                        if (client.db && client.db.createLog) {
                            await client.db.createLog(
                                interaction.guildId,
                                interaction.user.id,
                                'antiraid_setup',
                                null,
                                {
                                    modules: selectedModules,
                                    sanction: selectedSanction,
                                    whitelist: whitelistEnabled,
                                    type: 'manual'
                                }
                            );
                        }
                        
                    } catch (error) {
                        console.error('Error al aplicar configuración:', error);
                        
                        await i.editReply({
                            embeds: [client.embeds.error(
                                'Error',
                                'Ocurrió un error al guardar la configuración. Intenta nuevamente.'
                            )],
                            components: []
                        });
                    }
                }
                
                // Cancelar configuración
                if (i.customId === 'setup_cancel') {
                    await i.deferUpdate();
                    collector.stop('cancelled');
                    
                    const cancelEmbed = client.embeds.info(
                        'Configuración cancelada',
                        'No se realizaron cambios en la configuración del anti-raid.'
                    );
                    
                    await i.editReply({
                        embeds: [cancelEmbed],
                        components: []
                    });
                }
            });
            
            // Manejar cuando el collector termina
            collector.on('end', (collected, reason) => {
                if (reason === 'time') {
                    interaction.editReply({
                        embeds: [client.embeds.error(
                            'Tiempo agotado',
                            'Se acabó el tiempo para configurar. Ejecuta el comando nuevamente.'
                        )],
                        components: []
                    }).catch(() => {});
                }
            });
            
        } catch (error) {
            console.error('Error en manual setup:', error);
            await interaction.editReply({
                embeds: [client.embeds.error(
                    'Error',
                    'Error al cargar la configuración manual. Intenta nuevamente.'
                )]
            });
        }
    },
    
    async setupLogs(interaction, client) {
        try {
            const channel = interaction.options.getChannel('canal');
            
            if (!channel) {
                return interaction.editReply({
                    embeds: [client.embeds.error('Error', 'Debes especificar un canal válido')]
                });
            }
            
            // Verificar que sea un canal de texto
            if (channel.type !== 0) { // 0 = GUILD_TEXT
                return interaction.editReply({
                    embeds: [client.embeds.error(
                        'Error',
                        'El canal debe ser un canal de texto.'
                    )]
                });
            }
            
            // Verificar permisos
            if (!channel.permissionsFor(client.user).has('ViewChannel')) {
                return interaction.editReply({
                    embeds: [client.embeds.error(
                        'Error',
                        'No tengo permisos para ver ese canal.'
                    )]
                });
            }
            
            if (!channel.permissionsFor(client.user).has('SendMessages')) {
                return interaction.editReply({
                    embeds: [client.embeds.error(
                        'Error',
                        'No tengo permisos para enviar mensajes en ese canal.'
                    )]
                });
            }
            
            // Guardar configuración
            if (client.db && client.db.updateServer) {
                await client.db.updateServer(interaction.guildId, {
                    logs_channel: channel.id
                });
                
                await interaction.editReply({
                    embeds: [client.embeds.success(
                        'Logs configurados',
                        `✅ Los logs del anti-raid serán enviados a: ${channel.toString()}
                        
**Canal:** ${channel.name}
**ID:** ${channel.id}
**Configurado por:** ${interaction.user.tag}`
                    )]
                });
                
                // Enviar mensaje de prueba al canal de logs
                try {
                    const testEmbed = client.embeds.info(
                        'Canal de logs configurado',
                        `Este canal ha sido configurado como el canal de logs del sistema anti-raid.
                        
**Configurado por:** <@${interaction.user.id}>
**Fecha:** <t:${Math.floor(Date.now() / 1000)}:F>

Todos los eventos del anti-raid serán registrados aquí.`
                    );
                    
                    await channel.send({ embeds: [testEmbed] });
                } catch (sendError) {
                    console.error('Error al enviar mensaje de prueba:', sendError);
                    await interaction.followUp({
                        embeds: [client.embeds.warning(
                            'Advertencia',
                            `El canal fue configurado correctamente, pero no pude enviar un mensaje de prueba en ${channel}. Verifica mis permisos.`
                        )],
                        flags: 64
                    });
                }
                
                // Registrar en logs
                if (client.db && client.db.createLog) {
                    await client.db.createLog(
                        interaction.guildId,
                        interaction.user.id,
                        'logs_configured',
                        null,
                        { 
                            channel: channel.id, 
                            channel_name: channel.name 
                        }
                    );
                }
                
            } else {
                console.error('⚠️ updateServer no disponible en client.db');
                await interaction.editReply({
                    embeds: [client.embeds.error(
                        'Error',
                        'No se pudo guardar la configuración. El sistema de base de datos no está disponible.'
                    )]
                });
            }
            
        } catch (error) {
            console.error('Error en setupLogs:', error);
            await interaction.editReply({
                embeds: [client.embeds.error(
                    'Error',
                    'Ocurrió un error al configurar los logs. Intenta nuevamente.'
                )]
            });
        }
    },
    
    getModuleName(module) {
        const names = {
            'channelcreate': 'Creación de canales',
            'channeldelete': 'Eliminación de canales',
            'channeledit': 'Edición de canales',
            'rolecreate': 'Creación de roles',
            'roledelete': 'Eliminación de roles',
            'roleedit': 'Edición de roles',
            'roleadd': 'Añadir roles peligrosos',
            'ban': 'Baneos',
            'kick': 'Expulsiones',
            'bot': 'Añadir bots',
            'webhook': 'Webhooks',
            'update': 'Editar servidor',
            'pub': 'Publicidad',
            'ping': 'Ping masivo',
            'spam': 'Spam'
        };
        
        return names[module] || module;
    }
};
