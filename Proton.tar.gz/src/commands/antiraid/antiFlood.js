module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (!message.guild || message.author.bot) return;
    
    const guild = message.guild;
    const guildId = guild.id;
    const userId = message.author.id;
    
    try {
      // Verificar si anti-flood está activado (función premium)
      const canUse = await client.premium.canUseFeature(guildId, 'anti-flood');
      if (!canUse) return;
      
      // Obtener configuración avanzada
      const [advancedConfig] = await client.db.query(
        'SELECT * FROM advanced_config WHERE guild_id = ? AND config_type = ?',
        [guildId, 'anti-flood']
      );
      
      if (!advancedConfig) return;
      
      const config = JSON.parse(advancedConfig.settings);
      const maxMessages = config.max_messages || 5;
      const timeWindow = config.time_window || 10000; // 10 segundos
      const sanction = config.sanction || 'timeout';
      
      // Almacenar mensajes en caché temporal
      const key = `flood_${guildId}_${userId}`;
      const now = Date.now();
      
      let userData = client.tempCache.get(key) || {
        messages: [],
        warned: false
      };
      
      // Filtrar mensajes fuera de la ventana de tiempo
      userData.messages = userData.messages.filter(time => now - time < timeWindow);
      
      // Añadir mensaje actual
      userData.messages.push(now);
      
      // Verificar si excede el límite
      if (userData.messages.length >= maxMessages) {
        const member = message.member;
        if (!member) return;
        
        // Verificar whitelist
        const [whitelist] = await client.db.query(
          'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
          [guildId, userId]
        );
        
        if (whitelist) return;
        
        // Aplicar sanción
        const raison = `Anti-Flood | ${userData.messages.length} mensajes en ${timeWindow/1000} segundos`;
        
        try {
          switch (sanction) {
            case 'timeout':
              await member.timeout(5 * 60 * 1000, raison); // 5 minutos
              break;
            case 'kick':
              await member.kick(raison);
              break;
            case 'derank':
              await member.roles.set([], { reason: raison });
              break;
          }
          
          // Eliminar mensajes de flood
          const messagesToDelete = await message.channel.messages.fetch({ limit: maxMessages });
          const userMessages = messagesToDelete.filter(msg => msg.author.id === userId);
          
          if (message.channel.isTextBased()) {
            await message.channel.bulkDelete(userMessages).catch(() => {});
          }
          
          // Enviar advertencia
          if (!userData.warned) {
            const warning = await message.channel.send({
              content: `<@${userId}>`,
              embeds: [client.embeds.warning(
                'Anti-Flood Activado',
                `Has sido ${sanction === 'timeout' ? 'silenciado por 5 minutos' : sanction} por enviar demasiados mensajes rápidamente.`
              )]
            }).catch(() => {});
            
            if (warning) {
              setTimeout(() => warning.delete().catch(() => {}), 5000);
            }
            
            userData.warned = true;
          }
          
          // Enviar log
          const serverConfig = await client.db.getServer(guildId);
          
          if (serverConfig?.logs_channel) {
            const logChannel = guild.channels.cache.get(serverConfig.logs_channel);
            
            if (logChannel) {
              const embed = client.embeds.info(
                'Anti-Flood Activado',
                `
**Usuario:** <@${userId}> (\`${message.author.tag}\`)
**Mensajes:** ${userData.messages.length} en ${timeWindow/1000}s
**Sanción:** ${sanction}
**Canal:** <#${message.channel.id}>
**Razón:** ${raison}
                                `
              );
              
              await logChannel.send({ embeds: [embed] }).catch(() => {});
            }
          }
          
          // Registrar en base de datos
          await client.db.createLog(interaction.guild?.id, interaction.user?.id, guildId, null, userId, 'antiflood_trigger', null, {
            messages_count: userData.messages.length,
            time_window: timeWindow,
            sanction: sanction,
            channel_id: message.channel.id
          });
          
        } catch (error) {
          console.error('Error aplicando anti-flood:', error);
        }
        
        // Limpiar cache
        client.tempCache.delete(key);
        
      } else {
        // Actualizar cache
        client.tempCache.set(key, userData);
        
        // Limpiar cache después de la ventana de tiempo
        setTimeout(() => {
          client.tempCache.delete(key);
        }, timeWindow + 1000);
      }
      
    } catch (error) {
      console.error('Error en antiFlood:', error);
    }
  }
};