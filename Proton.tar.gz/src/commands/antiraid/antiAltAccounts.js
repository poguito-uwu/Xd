module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const guild = member.guild;
    const guildId = guild.id;
    const userId = member.id;
    
    try {
      // Verificar si anti-alts está activado (función premium)
      const canUse = await client.premium.canUseFeature(guildId, 'anti-alts');
      if (!canUse) return;
      
      // Obtener configuración avanzada
      const [advancedConfig] = await client.db.query(
        'SELECT * FROM advanced_config WHERE guild_id = ? AND config_type = ?',
        [guildId, 'anti-alts']
      );
      
      if (!advancedConfig) return;
      
      const config = JSON.parse(advancedConfig.settings);
      const minAccountAge = config.min_account_age || 7; // días
      const action = config.action || 'kick';
      const requireVerification = config.require_verification || false;
      
      // Calcular edad de la cuenta
      const accountAge = Date.now() - member.user.createdTimestamp;
      const accountAgeDays = Math.floor(accountAge / (1000 * 60 * 60 * 24));
      
      // Verificar si la cuenta es muy nueva
      if (accountAgeDays < minAccountAge) {
        // Verificar whitelist
        const [whitelist] = await client.db.query(
          'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
          [guildId, userId]
        );
        
        if (whitelist) return;
        
        // Verificar si requiere verificación del servidor
        if (requireVerification && guild.verificationLevel >= 2) {
          // Si el servidor tiene verificación media o alta, no hacer nada
          return;
        }
        
        const raison = `Anti-Alts | Cuenta de ${accountAgeDays} días (mínimo requerido: ${minAccountAge} días)`;
        
        // Aplicar acción
        try {
          switch (action) {
            case 'kick':
              await member.kick(raison);
              break;
            case 'ban':
              await member.ban({ reason: raison });
              break;
            case 'timeout':
              await member.timeout(24 * 60 * 60 * 1000, raison); // 24 horas
              break;
          }
          
          // Enviar log
          const serverConfig = await client.db.getServer(guildId);
          
          if (serverConfig?.logs_channel) {
            const logChannel = guild.channels.cache.get(serverConfig.logs_channel);
            
            if (logChannel) {
              const embed = client.embeds.warning(
                'Cuenta alternativa detectada',
                `
**Usuario:** <@${userId}> (\`${member.user.tag}\`)
**Edad de cuenta:** ${accountAgeDays} días
**Mínimo requerido:** ${minAccountAge} días
**Acción:** ${action}
**Razón:** ${raison}
                                `
              );
              
              await logChannel.send({ embeds: [embed] }).catch(() => {});
            }
          }
          
          // Registrar en base de datos
          await client.db.createLog(interaction.guild?.id, interaction.user?.id, guildId, null, userId, 'antialt_trigger', null, {
            account_age_days: accountAgeDays,
            min_required_days: minAccountAge,
            action: action
          });
          
        } catch (error) {
          console.error('Error aplicando anti-alts:', error);
        }
      }
      
    } catch (error) {
      console.error('Error en antiAltAccounts:', error);
    }
  }
};