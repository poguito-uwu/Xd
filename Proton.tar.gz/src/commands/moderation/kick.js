const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Expulsa a un usuario del servidor')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption(option =>
      option.setName('usuario')
      .setDescription('Usuario a expulsar')
      .setRequired(true))
    .addStringOption(option =>
      option.setName('razon')
      .setDescription('Razón del kick')
      .setRequired(false)),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    const user = interaction.options.getUser('usuario');
    const reason = interaction.options.getString('razon') || 'Sin razón especificada';
    const embeds = new RB3Embeds();
    
    try {
      const member = await interaction.guild.members.fetch(user.id);
      
      if (!member.kickable) {
        return interaction.editReply({
          embeds: [embeds.error(
            'No se puede expulsar',
            'No tengo permisos para expulsar a este usuario o tiene un rol más alto.'
          )]
        });
      }
      
      // Expulsar miembro
      await member.kick(`${reason} | Moderador: ${interaction.user.tag}`);
      
      const embed = embeds.success(
        'Usuario expulsado',
        `
✅ **Usuario expulsado exitosamente**
                
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Razón:** ${reason}
**Moderador:** <@${interaction.user.id}>
                `
      );
      
      await interaction.editReply({ embeds: [embed] });
      
      // Enviar DM al usuario
      try {
        const dmEmbed = embeds.warning(
          'Has sido expulsado',
          `
Has sido expulsado de **${interaction.guild.name}**.
                    
**Razón:** ${reason}
**Moderador:** ${interaction.user.tag}
                    
Puedes volver a unirte si tienes una invitación válida.
                    `
        );
        
        await user.send({ embeds: [dmEmbed] }).catch(() => {});
      } catch (dmError) {
        // Ignorar errores de DM
      }
      
      // Registrar en logs
      await client.db.createLog(interaction.guild?.id, interaction.user?.id, interaction.guildId, null, interaction.user.id, 'kick', user.id, {
        user_tag: user.tag,
        reason: reason
      });
      
      // Enviar a canal de logs si existe
      const serverConfig = await client.db.getServer(interaction.guildId);
      
      if (serverConfig?.logs_channel) {
        const logChannel = interaction.guild.channels.cache.get(serverConfig.logs_channel);
        
        if (logChannel) {
          const logEmbed = embeds.info(
            'Usuario expulsado',
            `
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Moderador:** <@${interaction.user.id}>
**Razón:** ${reason}
**Fecha:** <t:${Math.floor(Date.now() / 1000)}:F>
                        `
          );
          
          await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
      }
      
    } catch (error) {
      console.error('Error en kick:', error);
      
      await interaction.editReply({
        embeds: [embeds.error(
          'Error',
          'Ocurrió un error al expulsar al usuario. Verifica que el usuario exista y que tenga permisos.'
        )]
      });
    }
  }
};