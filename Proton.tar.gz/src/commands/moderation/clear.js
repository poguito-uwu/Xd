const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Elimina mensajes del canal')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addIntegerOption(option =>
      option.setName('cantidad')
      .setDescription('Número de mensajes a eliminar (1-100)')
      .setRequired(true)
      .setMinValue(1)
      .setMaxValue(100))
    .addUserOption(option =>
      option.setName('usuario')
      .setDescription('Eliminar solo mensajes de este usuario')
      .setRequired(false)),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    const amount = interaction.options.getInteger('cantidad');
    const user = interaction.options.getUser('usuario');
    const channel = interaction.channel;
    const embeds = new RB3Embeds();
    
    try {
      let messages;
      
      if (user) {
        // Obtener mensajes del usuario específico
        messages = await channel.messages.fetch({ limit: 100 });
        const userMessages = messages.filter(msg => msg.author.id === user.id).first(amount);
        
        if (userMessages.length === 0) {
          return interaction.editReply({
            embeds: [embeds.error(
              'No hay mensajes',
              `No se encontraron mensajes de <@${user.id}> en los últimos 100 mensajes.`
            )]
          });
        }
        
        // Eliminar mensajes
        await channel.bulkDelete(userMessages, true);
        
        await interaction.editReply({
          embeds: [embeds.success(
            'Mensajes eliminados',
            `Se eliminaron **${userMessages.length}** mensajes de <@${user.id}>.`
          )]
        });
        
      } else {
        // Eliminar cantidad general de mensajes
        messages = await channel.bulkDelete(amount, true);
        
        await interaction.editReply({
          embeds: [embeds.success(
            'Mensajes eliminados',
            `Se eliminaron **${messages.size}** mensajes del canal.`
          )]
        });
      }
      
      // Registrar en logs
      const serverConfig = await client.getServerConfig(interaction.guildId);
      
      if (serverConfig?.logs_channel) {
        const logChannel = interaction.guild.channels.cache.get(serverConfig.logs_channel);
        
        if (logChannel) {
          const logEmbed = embeds.info(
            'Mensajes eliminados',
            `
**Moderador:** <@${interaction.user.id}>
**Canal:** <#${channel.id}>
**Cantidad:** ${user ? `${messages.size} de ${user.tag}` : messages.size}
                        `
          );
          
          await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
      }
      
    } catch (error) {
      console.error('Error en clear:', error);
      
      await interaction.editReply({
        embeds: [embeds.error(
          'Error',
          'No se pudieron eliminar los mensajes. Los mensajes pueden tener más de 14 días.'
        )]
      });
    }
  }
};