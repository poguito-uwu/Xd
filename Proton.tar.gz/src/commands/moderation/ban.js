const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Banea a un usuario del servidor')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption(option =>
      option.setName('usuario')
      .setDescription('Usuario a banear')
      .setRequired(true))
    .addStringOption(option =>
      option.setName('razon')
      .setDescription('Razón del ban')
      .setRequired(false))
    .addIntegerOption(option =>
      option.setName('dias')
      .setDescription('Días de mensajes a eliminar (0-7)')
      .setRequired(false)
      .setMinValue(0)
      .setMaxValue(7)),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    const user = interaction.options.getUser('usuario');
    const reason = interaction.options.getString('razon') || 'Sin razón especificada';
    const days = interaction.options.getInteger('dias') || 0;
    const embeds = new RB3Embeds();
    
    try {
      const member = await interaction.guild.members.fetch(user.id).catch(() => null);
      
      if (!member) {
        // Banear usuario que no está en el servidor
        await interaction.guild.members.ban(user.id, {
          reason: `${reason} | Moderador: ${interaction.user.tag}`,
          deleteMessageSeconds: days * 24 * 60 * 60
        });
        
        const embed = embeds.success(
          'Usuario baneado',
          `
✅ **Usuario baneado exitosamente**
                    
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Razón:** ${reason}
**Mensajes eliminados:** ${days} días
**Moderador:** <@${interaction.user.id}>
                    
**Nota:** El usuario no estaba en el servidor, pero ha sido baneado para prevenir su ingreso.
                    `
        );
        
        await interaction.editReply({ embeds: [embed] });
        
      } else {
        // Verificar si se puede banear
        if (!member.bannable) {
          return interaction.editReply({
            embeds: [embeds.error(
              'No se puede banear',
              'No tengo permisos para banear a este usuario o tiene un rol más alto.'
            )]
          });
        }
        
        // Banear miembro
        await member.ban({
          reason: `${reason} | Moderador: ${interaction.user.tag}`,
          deleteMessageSeconds: days * 24 * 60 * 60
        });
        
        const embed = embeds.success(
          'Usuario baneado',
          `
✅ **Usuario baneado exitosamente**
                    
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Razón:** ${reason}
**Mensajes eliminados:** ${days} días
**Moderador:** <@${interaction.user.id}>
                    `
        );
        
        await interaction.editReply({ embeds: [embed] });
        
        // Enviar DM al usuario
        try {
          const dmEmbed = embeds.error(
            'Has sido baneado',
            `
Has sido baneado de **${interaction.guild.name}**.
                        
**Razón:** ${reason}
**Moderador:** ${interaction.user.tag}
**Mensajes eliminados:** ${days} días
                        
Si crees que es un error, contacta con la moderación del servidor.
                        `
          );
          
          await user.send({ embeds: [dmEmbed] }).catch(() => {});
        } catch (dmError) {
          // Ignorar errores de DM
        }
      }
      
      // Registrar en logs
      await client.db.createLog(interaction.guild?.id, interaction.user?.id, interaction.guildId, null, interaction.user.id, 'ban', user.id, {
        user_tag: user.tag,
        reason: reason,
        days: days
      });
      
      // Enviar a canal de logs si existe
      const serverConfig = await client.db.getServer(interaction.guildId);
      
      if (serverConfig?.logs_channel) {
        const logChannel = interaction.guild.channels.cache.get(serverConfig.logs_channel);
        
        if (logChannel) {
          const logEmbed = embeds.info(
            'Usuario baneado',
            `
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Moderador:** <@${interaction.user.id}>
**Razón:** ${reason}
**Mensajes eliminados:** ${days} días
**Fecha:** <t:${Math.floor(Date.now() / 1000)}:F>
                        `
          );
          
          await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
      }
      
    } catch (error) {
      console.error('Error en ban:', error);
      
      await interaction.editReply({
        embeds: [embeds.error(
          'Error',
          'Ocurrió un error al banear al usuario. Verifica mis permisos.'
        )]
      });
    }
  }
};