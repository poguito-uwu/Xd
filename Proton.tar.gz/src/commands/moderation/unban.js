const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Desbanea a un usuario del servidor')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addStringOption(option =>
      option.setName('usuario')
      .setDescription('ID o mención del usuario a desbanear')
      .setRequired(true))
    .addStringOption(option =>
      option.setName('razon')
      .setDescription('Razón del unban')
      .setRequired(false)),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    const userInput = interaction.options.getString('usuario');
    const reason = interaction.options.getString('razon') || 'Sin razón especificada';
    const embeds = new RB3Embeds();
    
    try {
      // Extraer ID del usuario
      let userId = userInput;
      
      // Si es una mención
      if (userInput.startsWith('<@') && userInput.endsWith('>')) {
        userId = userInput.replace(/[<@!>]/g, '');
      }
      
      // Verificar si es un ID válido
      if (!/^\d+$/.test(userId)) {
        return interaction.editReply({
          embeds: [embeds.error(
            'ID inválido',
            'Por favor proporciona una ID de usuario válida o una mención.'
          )]
        });
      }
      
      // Obtener baneos
      const bans = await interaction.guild.bans.fetch();
      const ban = bans.get(userId);
      
      if (!ban) {
        return interaction.editReply({
          embeds: [embeds.error(
            'Usuario no baneado',
            `El usuario con ID \`${userId}\` no está baneado de este servidor.`
          )]
        });
      }
      
      // Desbanear
      await interaction.guild.members.unban(userId, `${reason} | Moderador: ${interaction.user.tag}`);
      
      const embed = embeds.success(
        'Usuario desbaneado',
        `
✅ **Usuario desbaneado exitosamente**
                
**Usuario:** <@${userId}> (\`${ban.user.tag}\`)
**Razón del ban original:** ${ban.reason || 'No especificada'}
**Razón del unban:** ${reason}
**Moderador:** <@${interaction.user.id}>
                `
      );
      
      await interaction.editReply({ embeds: [embed] });
      
      // Registrar en logs
      await client.db.createLog(interaction.guild?.id, interaction.user?.id, interaction.guildId, null, interaction.user.id, 'unban', userId, {
        user_tag: ban.user.tag,
        reason: reason,
        original_ban_reason: ban.reason
      });
      
      // Enviar a canal de logs si existe
      const serverConfig = await client.db.getServer(interaction.guildId);
      
      if (serverConfig?.logs_channel) {
        const logChannel = interaction.guild.channels.cache.get(serverConfig.logs_channel);
        
        if (logChannel) {
          const logEmbed = embeds.info(
            'Usuario desbaneado',
            `
**Usuario:** <@${userId}> (\`${ban.user.tag}\`)
**Moderador:** <@${interaction.user.id}>
**Razón:** ${reason}
**Ban original:** ${ban.reason || 'No especificada'}
**Fecha:** <t:${Math.floor(Date.now() / 1000)}:F>
                        `
          );
          
          await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
        }
      }
      
    } catch (error) {
      console.error('Error en unban:', error);
      
      await interaction.editReply({
        embeds: [embeds.error(
          'Error',
          'Ocurrió un error al desbanear al usuario. Verifica mis permisos.'
        )]
      });
    }
  }
};