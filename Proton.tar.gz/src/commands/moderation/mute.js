const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('Silencia a un usuario')
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .addUserOption(option =>
            option.setName('usuario')
                .setDescription('Usuario a silenciar')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('tiempo')
                .setDescription('Duración del mute (ej: 1h, 30m, 2d)')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('razon')
                .setDescription('Razón del mute')
                .setRequired(false)),
    
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        
        const user = interaction.options.getUser('usuario');
        const time = interaction.options.getString('tiempo');
        const reason = interaction.options.getString('razon') || 'Sin razón especificada';
        const embeds = new RB3Embeds();
        
        try {
            const member = await interaction.guild.members.fetch(user.id);
            
            if (!member.moderatable) {
                return interaction.editReply({
                    embeds: [embeds.error(
                        'No se puede mutear',
                        'No tengo permisos para mutear a este usuario o tiene un rol más alto.'
                    )]
                });
            }
            
            // Convertir tiempo a milisegundos
            let ms = 0;
            const timeMatch = time.match(/(\d+)([hmd])/i);
            
            if (timeMatch) {
                const amount = parseInt(timeMatch[1]);
                const unit = timeMatch[2].toLowerCase();
                
                switch (unit) {
                    case 'm': ms = amount * 60 * 1000; break;
                    case 'h': ms = amount * 60 * 60 * 1000; break;
                    case 'd': ms = amount * 24 * 60 * 60 * 1000; break;
                    default: ms = amount * 60 * 1000;
                }
                
                // Limitar a 28 días máximo (límite de Discord)
                if (ms > 28 * 24 * 60 * 60 * 1000) {
                    ms = 28 * 24 * 60 * 60 * 1000;
                }
            } else {
                // Si no se especifica formato, usar 1 hora por defecto
                ms = 60 * 60 * 1000;
            }
            
            // Aplicar timeout
            await member.timeout(ms, `${reason} | Moderador: ${interaction.user.tag}`);
            
            const timeText = this.formatTime(ms);
            
            await interaction.editReply({
                embeds: [embeds.success(
                    'Usuario muteado',
                    `<@${user.id}> ha sido muteado por **${timeText}**.\n**Razón:** ${reason}`
                )]
            });
            
            // Enviar DM al usuario
            try {
                const dmEmbed = embeds.warning(
                    'Has sido muteado',
                    `
Has sido muteado en **${interaction.guild.name}**.
                    
**Duración:** ${timeText}
**Razón:** ${reason}
**Moderador:** ${interaction.user.tag}
                    
El mute expirará automáticamente. Si crees que es un error, contacta con la moderación.
                    `
                );
                
                await user.send({ embeds: [dmEmbed] }).catch(() => {});
            } catch (dmError) {
                // Ignorar errores de DM
            }
            
            // Registrar en logs
            const serverConfig = await client.getServerConfig(interaction.guildId);
            
            if (serverConfig?.logs_channel) {
                const logChannel = interaction.guild.channels.cache.get(serverConfig.logs_channel);
                
                if (logChannel) {
                    const logEmbed = embeds.info(
                        'Usuario muteado',
                        `
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Moderador:** <@${interaction.user.id}>
**Duración:** ${timeText}
**Razón:** ${reason}
**Expira:** <t:${Math.floor((Date.now() + ms) / 1000)}:R>
                        `
                    );
                    
                    await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
                }
            }
            
        } catch (error) {
            console.error('Error en mute:', error);
            
            await interaction.editReply({
                embeds: [embeds.error(
                    'Error',
                    'No se pudo mutear al usuario. Verifica que tengo permisos y que el usuario existe.'
                )]
            });
        }
    },
    
    formatTime(ms) {
        const days = Math.floor(ms / (24 * 60 * 60 * 1000));
        const hours = Math.floor((ms % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
        const minutes = Math.floor((ms % (60 * 60 * 1000)) / (60 * 1000));
        
        const parts = [];
        if (days > 0) parts.push(`${days}d`);
        if (hours > 0) parts.push(`${hours}h`);
        if (minutes > 0) parts.push(`${minutes}m`);
        
        return parts.join(' ') || '1m';
    }
};

// Comando unmute.js
const unmuteCommand = {
    data: new SlashCommandBuilder()
        .setName('unmute')
        .setDescription('Remueve el mute de un usuario')
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
        .addUserOption(option =>
            option.setName('usuario')
                .setDescription('Usuario a desmutear')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('razon')
                .setDescription('Razón del unmute')
                .setRequired(false)),
    
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: true });
        
        const user = interaction.options.getUser('usuario');
        const reason = interaction.options.getString('razon') || 'Sin razón especificada';
        const embeds = new RB3Embeds();
        
        try {
            const member = await interaction.guild.members.fetch(user.id);
            
            if (!member.moderatable) {
                return interaction.editReply({
                    embeds: [embeds.error(
                        'No se puede desmutear',
                        'No tengo permisos para desmutear a este usuario.'
                    )]
                });
            }
            
            // Remover timeout
            await member.timeout(null, `${reason} | Moderador: ${interaction.user.tag}`);
            
            await interaction.editReply({
                embeds: [embeds.success(
                    'Usuario desmuteado',
                    `<@${user.id}> ha sido desmuteado.\n**Razón:** ${reason}`
                )]
            });
            
            // Registrar en logs
            const serverConfig = await client.getServerConfig(interaction.guildId);
            
            if (serverConfig?.logs_channel) {
                const logChannel = interaction.guild.channels.cache.get(serverConfig.logs_channel);
                
                if (logChannel) {
                    const logEmbed = embeds.info(
                        'Usuario desmuteado',
                        `
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Moderador:** <@${interaction.user.id}>
**Razón:** ${reason}
                        `
                    );
                    
                    await logChannel.send({ embeds: [logEmbed] }).catch(() => {});
                }
            }
            
        } catch (error) {
            console.error('Error en unmute:', error);
            
            await interaction.editReply({
                embeds: [embeds.error(
                    'Error',
                    'No se pudo desmutear al usuario. Verifica que el usuario esté muteado.'
                )]
            });
        }
    }
};