const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('userinfo')
        .setDescription('Muestra información de un usuario')
        .addUserOption(option =>
            option.setName('usuario')
                .setDescription('Usuario a consultar')
                .setRequired(false)),
    
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: false });
        
        const targetUser = interaction.options.getUser('usuario') || interaction.user;
        const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
        const embeds = new RB3Embeds();
        
        if (!targetMember) {
            return interaction.editReply({
                embeds: [embeds.error(
                    'Usuario no encontrado',
                    'El usuario no está en este servidor.'
                )]
            });
        }
        
        // Obtener información de la blacklist global
        const [blacklist] = await client.db.query(
            'SELECT * FROM blacklist WHERE user_id = ?',
            [targetUser.id]
        );
        
        // Obtener información de whitelist
        const [whitelist] = await client.db.query(
            'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
            [interaction.guildId, targetUser.id]
        );
        
        // Formatear badges
        const badges = [];
        const flags = targetUser.flags?.toArray() || [];
        
        flags.forEach(flag => {
            switch (flag) {
                case 'Staff': badges.push('<:discordstaff:947090506289119272>'); break;
                case 'Partner': badges.push('<:partner:947090506289119272>'); break;
                case 'Hypesquad': badges.push('<:hypesquad:947090506289119272>'); break;
                case 'BugHunterLevel1': badges.push('<:bughunter1:947090506289119272>'); break;
                case 'BugHunterLevel2': badges.push('<:bughunter2:947090506289119272>'); break;
                case 'HypeSquadOnlineHouse1': badges.push('<:bravery:947090506289119272>'); break;
                case 'HypeSquadOnlineHouse2': badges.push('<:brilliance:947090506289119272>'); break;
                case 'HypeSquadOnlineHouse3': badges.push('<:balance:947090506289119272>'); break;
                case 'PremiumEarlySupporter': badges.push('<:earlysupporter:947090506289119272>'); break;
                case 'VerifiedDeveloper': badges.push('<:verifieddev:947090506289119272>'); break;
                case 'CertifiedModerator': badges.push('<:certifiedmod:947090506289119272>'); break;
                case 'ActiveDeveloper': badges.push('<:activedev:947090506289119272>'); break;
            }
        });
        
        // Obtener roles (excluyendo @everyone)
        const roles = targetMember.roles.cache
            .filter(role => role.id !== interaction.guild.id)
            .sort((a, b) => b.position - a.position)
            .map(role => role.toString());
        
        // Estado del usuario
        const statusEmojis = {
            online: '<:online:947090506289119272>',
            idle: '<:idle:947090506289119272>',
            dnd: '<:dnd:947090506289119272>',
            offline: '<:offline:947090506289119272>'
        };
        
        const status = statusEmojis[targetMember.presence?.status || 'offline'];
        
        // Actividades
        const activities = targetMember.presence?.activities || [];
        const activityText = activities.map(activity => {
            if (activity.type === 0) return `Jugando a **${activity.name}**`;
            if (activity.type === 1) return `Transmitiendo **${activity.name}**`;
            if (activity.type === 2) return `Escuchando **${activity.name}**`;
            if (activity.type === 3) return `Viendo **${activity.name}**`;
            if (activity.type === 4) return `**${activity.state || activity.name}**`;
            if (activity.type === 5) return `Participando en **${activity.name}**`;
            return activity.name;
        }).join('\n') || 'Sin actividad';
        
        const embed = new EmbedBuilder()
            .setTitle(`${status} ${targetUser.tag}`)
            .setColor(targetMember.displayHexColor || '#2c2f33')
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 512 }))
            .addFields(
                {
                    name: '👤 Información',
                    value: `
**ID:** \`${targetUser.id}\`
**Cuenta creada:** <t:${Math.floor(targetUser.createdTimestamp / 1000)}:F>
**Se unió:** <t:${Math.floor(targetMember.joinedTimestamp / 1000)}:F>
**Badges:** ${badges.join(' ') || 'Ninguno'}
**Bot:** ${targetUser.bot ? 'Sí 🤖' : 'No 👤'}
                    `,
                    inline: false
                },
                {
                    name: '🎭 Roles',
                    value: roles.length > 0 
                        ? `${roles.slice(0, 10).join(', ')}${roles.length > 10 ? `... (+${roles.length - 10})` : ''}`
                        : 'Sin roles',
                    inline: false
                },
                {
                    name: '🎮 Actividad',
                    value: activityText.substring(0, 1024) || 'Sin actividad',
                    inline: false
                },
                {
                    name: '🛡️ Estado Proton',
                    value: `
${blacklist ? '🔴 **EN BLACKLIST GLOBAL**' : '🟢 Limpio'}
${whitelist ? '🟢 **En Whitelist**' : '⚪ No en whitelist'}
**Permisos:** ${targetMember.permissions.has('Administrator') ? 'Administrador 👑' : 'Miembro'}
                    `,
                    inline: false
                }
            )
            .setFooter({ 
                text: `Usuario ID: ${targetUser.id} • Solicitado por ${interaction.user.tag}`,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true })
            })
            .setTimestamp();
        
        if (blacklist) {
            embed.addFields({
                name: '🚨 Blacklist Global',
                value: `
**Razón:** ${blacklist.reason}
**Severidad:** ${blacklist.severity}
**Fecha:** <t:${Math.floor(new Date(blacklist.created_at).getTime() / 1000)}:F>
                `,
                inline: false
            });
        }
        
        await interaction.editReply({ embeds: [embed] });
    }
};