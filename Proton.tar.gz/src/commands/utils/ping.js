const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Muestra la latencia del bot'),
    
    async execute(interaction, client) {
        await interaction.deferReply({ ephemeral: false });
        
        const sent = await interaction.editReply({ 
            content: '🏓 Pinging...', 
            fetchReply: true 
        });
        
        const roundtrip = sent.createdTimestamp - interaction.createdTimestamp;
        const wsPing = client.ws.ping;
        const uptime = this.formatUptime(client.uptime);
        
        const embed = new EmbedBuilder()
            .setTitle('🏓 Pong!')
            .setColor(this.getPingColor(roundtrip))
            .addFields(
                {
                    name: '📡 Latencia del bot',
                    value: `\`${roundtrip}ms\``,
                    inline: true
                },
                {
                    name: '🌐 WebSocket',
                    value: `\`${wsPing}ms\``,
                    inline: true
                },
                {
                    name: '⏱️ Uptime',
                    value: uptime,
                    inline: true
                }
            )
            .setFooter({ 
                text: `Proton • ${client.guilds.cache.size} servidores`,
                iconURL: client.user.displayAvatarURL({ dynamic: true })
            })
            .setTimestamp();
        
        await interaction.editReply({ 
            content: null,
            embeds: [embed] 
        });
    },
    
    formatUptime(ms) {
        const days = Math.floor(ms / (24 * 60 * 60 * 1000));
        const daysMs = ms % (24 * 60 * 60 * 1000);
        const hours = Math.floor(daysMs / (60 * 60 * 1000));
        const hoursMs = ms % (60 * 60 * 1000);
        const minutes = Math.floor(hoursMs / (60 * 1000));
        const minutesMs = ms % (60 * 1000);
        const seconds = Math.floor(minutesMs / 1000);
        
        return `${days}d ${hours}h ${minutes}m ${seconds}s`;
    },
    
    getPingColor(ping) {
        if (ping < 100) return '#43b581'; // Verde
        if (ping < 200) return '#faa61a'; // Amarillo
        if (ping < 300) return '#f57731'; // Naranja
        return '#f04747'; // Rojo
    }
};