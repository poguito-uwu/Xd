const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('check')
    .setDescription('Verifica la configuración de seguridad del servidor')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: true });
    
    const guild = interaction.guild;
    const embeds = new RB3Embeds();
    
    // Arrays para almacenar resultados
    const issues = [];
    const warnings = [];
    const success = [];
    
    // 1. Verificar canal de logs
    const logsChannel = await client.db.query(
      'SELECT logs_channel FROM servers WHERE id = ?',
      [guild.id]
    );
    
    if (!logsChannel[0]?.logs_channel) {
      issues.push('> <a:_:1455009802810822818> Canal de Logs no configurado.');
      issues.push('> <:more:1455002688096833758> Para configurar el canal de logs usa el comando </logs:0>');
    } else {
      success.push('> <a:_:1455002621260599499> Canal de logs configurado correctamente');
    }
    
    // 2. Verificar posición del rol del bot
    const botMember = guild.members.cache.get(client.user.id);
    const botRole = botMember.roles.highest;
    const botPosition = botRole.position;
    const highestPosition = Math.max(...guild.roles.cache.map(r => r.position));
    
    if (botPosition !== highestPosition) {
      issues.push('> <a:_:1455009802810822818> Mi rol no está el primero y no podré proteger correctamente el servidor');
      issues.push('> <:more:1455002688096833758> **Aviso Grave:** El rol de PROTON y Proton Guard deben estar en la primera posición');
    } else {
      success.push('> <a:_:1455002621260599499> Rol de Proton en posición correcta');
    }
    
    // 3. Verificar permisos de administrador
    if (!botMember.permissions.has(PermissionFlagsBits.Administrator)) {
      warnings.push('> <a:_:1455009802810822818> Falta permiso de Administrador');
      warnings.push('> <:more:1455002688096833758> El bot necesita permisos de administrador para funcionar correctamente');
    } else {
      success.push('> <a:_:1455002621260599499> Permiso de Administrador concedido');
    }
    
    // 4. Verificar permisos peligrosos en @everyone
    const everyoneRole = guild.roles.everyone;
    const dangerousEveryonePerms = [];
    
    if (everyoneRole.permissions.has(PermissionFlagsBits.UseExternalEmojis)) {
      dangerousEveryonePerms.push('`Usar emojis externos`');
    }
    
    if (everyoneRole.permissions.has(PermissionFlagsBits.UseApplicationCommands)) {
      dangerousEveryonePerms.push('`Usar aplicaciones externas`');
    }
    
    if (everyoneRole.permissions.has(PermissionFlagsBits.CreateInstantInvite)) {
      dangerousEveryonePerms.push('`Crear invitaciones`');
    }
    
    if (dangerousEveryonePerms.length > 0) {
      issues.push(`> **<a:atencion:1455009802810822818> RIESGO CRÍTICO:** el rol **@everyone** tiene: ${dangerousEveryonePerms.join(', ')}`);
      issues.push('> <:more:1455002688096833758> Estos permisos en **@everyone** permiten realizar raids. **Desactívalos inmediatamente.**');
    }
    
    // 5. Verificar roles con permisos peligrosos
    const dangerousRoles = [];
    
    guild.roles.cache.forEach(role => {
      if (role.id === guild.id || role.managed) return;
      
      const dangerousPerms = [];
      
      if (role.permissions.has(PermissionFlagsBits.Administrator)) {
        dangerousPerms.push('`Administrador`');
      }
      
      if (role.permissions.has(PermissionFlagsBits.ManageGuild)) {
        dangerousPerms.push('`Administrar servidor`');
      }
      
      if (role.permissions.has(PermissionFlagsBits.ManageRoles)) {
        dangerousPerms.push('`Administrar roles`');
      }
      
      if (role.permissions.has(PermissionFlagsBits.ManageChannels)) {
        dangerousPerms.push('`Administrar canales`');
      }
      
      if (dangerousPerms.length > 0) {
        dangerousRoles.push({
          role: role,
          perms: dangerousPerms
        });
      }
    });
    
    if (dangerousRoles.length > 0) {
      warnings.push('> **<:arrow_right:1361619658305962014> Roles con permisos potencialmente peligrosos:**');
      
      dangerousRoles.slice(0, 5).forEach(dangerous => {
        warnings.push(`> <:more:1455002688096833758> ${dangerous.role} → ${dangerous.perms.join(', ')}`);
      });
      
      if (dangerousRoles.length > 5) {
        warnings.push(`> <:more:1455002688096833758> ...y ${dangerousRoles.length - 5} roles más`);
      }
    }
    
    // 6. Verificar sistema anti-raid básico
    const antiraidConfig = await client.db.query(
      'SELECT COUNT(*) as count FROM antiraid_config WHERE server_id = ? AND enabled = TRUE',
      [guild.id]
    );
    
    if (antiraidConfig[0]?.count > 0) {
      success.push(`> <a:_:1455002621260599499> ${antiraidConfig[0].count} módulos anti-raid activados`);
    } else {
      warnings.push('> <a:_:1455009802810822818> Sistema anti-raid no configurado');
      warnings.push('> <:more:1455002688096833758> Usa </setup:0> para configurar la protección');
    }
    
    // 7. Verificar 2FA requerido para moderación
    if (guild.mfaLevel === 0) {
      warnings.push('> <a:_:1455009802810822818> 2FA no requerido para moderación');
      warnings.push('> <:more:1455002688096833758> Activa la verificación en dos pasos en Configuración del Servidor → Seguridad');
    } else {
      success.push('> <a:_:1455002621260599499> 2FA requerido para moderación');
    }
    
    // Enviar embed de resultados
    const embed = embeds.serverCheck(guild, issues, warnings, success);
    
    await interaction.editReply({ embeds: [embed] });
  }
};