const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const RB3Embeds = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Muestra la ayuda del bot y lista de comandos')
    .addStringOption(option =>
      option.setName('comando')
      .setDescription('Comando específico para ver ayuda detallada')
      .setRequired(false)
      .setAutocomplete(true)),
  
  async execute(interaction, client) {
    await interaction.deferReply({ ephemeral: false });
    
    const commandName = interaction.options.getString('comando');
    const embeds = new RB3Embeds();
    
    if (commandName) {
      // Ayuda específica de un comando
      const command = client.commands.get(commandName);
      
      if (!command) {
        return interaction.editReply({
          embeds: [embeds.error(
            'Comando no encontrado',
            `El comando \`${commandName}\` no existe. Usa \`/help\` para ver la lista de comandos.`
          )]
        });
      }
      
      const embed = embeds.info(
        `Comando: /${command.data.name}`,
        `
**Descripción:** ${command.data.description}
                
**Uso:** \`/${command.data.name}${this.getCommandUsage(command.data)}\`
**Permisos requeridos:** ${this.getPermissions(command.data)}
**Cooldown:** ${command.cooldown || 3} segundos
                `
      );
      
      if (command.data.options && command.data.options.length > 0) {
        const options = command.data.options.map(opt => {
          return `• **${opt.name}:** ${opt.description} ${opt.required ? '*(requerido)*' : ''}`;
        }).join('\n');
        
        embed.addFields({
          name: '📝 Opciones',
          value: options
        });
      }
      
      await interaction.editReply({ embeds: [embed] });
      
    } else {
      // Lista general de comandos
      const categories = {
        'antiraid': {
          name: '🛡️ Anti-Raid',
          commands: ['setup', 'whitelist', 'settings', 'check', 'backup'],
          description: 'Configuración y gestión del sistema anti-raid'
        },
        'moderation': {
          name: '🔨 Moderación',
          commands: ['ban', 'unban', 'kick', 'mute', 'unmute', 'clear'],
          description: 'Herramientas de moderación del servidor'
        },
        'util': {
          name: '🔧 Utilidades',
          commands: ['help', 'ping', 'userinfo'],
          description: 'Comandos útiles e informativos'
        },
        'owner': {
          name: '👑 Owner',
          commands: ['blacklist', 'eval'],
          description: 'Comandos exclusivos para dueños del bot'
        }
      };
      
      const embed = new EmbedBuilder()
        .setTitle('Mi lista de comandos')
        .setDescription(`
¡Hola ${interaction.user.username} <a:_:1455453068039819295>! Soy **PROTON**, un bot de protección avanzada para Discord.
                    
**Características principales:**
• 🛡️ **Sistema anti-raid completo**
• 🔨 **Herramientas de moderación**
• 📊 **Panel de configuración web**
• 💎 **Sistema premium por niveles**
• 🌐 **Blacklist global automática**
                    
Usa \`/help <comando>\` para obtener ayuda detallada de un comando específico.
                `)
        .setColor('#2c2f33')
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: 'PROTON • Protección Profesional' })
        .setTimestamp();
      
      // Añadir categorías
      for (const [categoryId, category] of Object.entries(categories)) {
        const commandsList = category.commands
          .map(cmd => `\`/${cmd}\``)
          .join(', ');
        
        embed.addFields({
          name: `${category.name}`,
          value: `${category.description}\n${commandsList}`,
          inline: false
        });
      }
      
      // Botones
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
          .setLabel('Documentación')
          .setURL('https://docs-proton.pogoos.xyz')
          .setStyle(ButtonStyle.Link)
          .setEmoji('📚'),
          new ButtonBuilder()
          .setLabel('Soporte')
          .setURL(process.env.SUPPORT_SERVER || 'https://discord.gg/fHmcxDWdjQ')
          .setStyle(ButtonStyle.Link)
          .setEmoji('🛠️'),
          new ButtonBuilder()
          .setLabel('Dashboard')
          .setURL(process.env.DASHBOARD_URL || 'https://dash-proton.pogoos.xyz')
          .setStyle(ButtonStyle.Link)
          .setEmoji('🌐')
        );
      
      await interaction.editReply({
        embeds: [embed],
        components: [row]
      });
    }
  },
  
  async autocomplete(interaction) {
    const focusedValue = interaction.options.getFocused();
    const commands = Array.from(interaction.client.commands.keys());
    
    const filtered = commands
      .filter(command => command.toLowerCase().includes(focusedValue.toLowerCase()))
      .slice(0, 25);
    
    await interaction.respond(
      filtered.map(command => ({ name: `/${command}`, value: command }))
    );
  },
  
  getCommandUsage(commandData) {
    if (!commandData.options || commandData.options.length === 0) {
      return '';
    }
    
    const options = commandData.options.map(opt => {
      return opt.required ? `<${opt.name}>` : `[${opt.name}]`;
    }).join(' ');
    
    return ` ${options}`;
  },
  
  getPermissions(commandData) {
    const defaultPerms = commandData.default_member_permissions;
    
    if (!defaultPerms) return 'Ninguno específico';
    
    const permissions = {
      '8': 'Administrador',
      '16': 'Gestionar canales',
      '32': 'Gestionar servidor',
      '64': 'Gestionar roles',
      '128': 'Gestionar webhooks',
      '256': 'Gestionar emojis y stickers',
      '1024': 'Ver registros de auditoría',
      '2048': 'Ver insights del servidor',
      '4096': 'Gestionar servidor',
      '8192': 'Ver canal',
      '16384': 'Enviar mensajes',
      '32768': 'Enviar mensajes en hilos',
      '65536': 'Gestionar mensajes',
      '131072': 'Insertar enlaces',
      '262144': 'Adjuntar archivos',
      '524288': 'Leer historial de mensajes',
      '1048576': 'Mencionar @everyone',
      '2097152': 'Usar emojis externos',
      '4194304': 'Ver insights del servidor',
      '8388608': 'Conectarse',
      '16777216': 'Hablar',
      '33554432': 'Silenciar miembros',
      '67108864': 'Silenciar miembros',
      '134217728': 'Mover miembros',
      '268435456': 'Activar detección de voz',
      '536870912': 'Prioridad de altavoz',
      '1073741824': 'Transmitir',
      '2147483648': 'Usar actividades',
      '4294967296': 'Moderar miembros',
      '8589934592': 'Ver canal',
      '17179869184': 'Enviar mensajes en hilos',
      '34359738368': 'Enviar mensajes en hilos',
      '68719476736': 'Usar comandos de aplicación',
      '137438953472': 'Solicitar para hablar',
      '274877906944': 'Gestionar eventos',
      '549755813888': 'Gestionar hilos',
      '1099511627776': 'Crear hilos públicos',
      '2199023255552': 'Crear hilos privados',
      '4398046511104': 'Usar stickers externos',
      '8796093022208': 'Enviar mensajes en hilos',
      '17592186044416': 'Usar sonidos',
      '35184372088832': 'Usar sonidos'
    };
    
    return permissions[defaultPerms] || 'Permisos especiales';
  }
};