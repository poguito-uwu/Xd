const express = require('express');
const router = express.Router();
const logsController = require('../controllers/logsController');

// GET    /api/servers/:guildId/logs
router.get('/:guildId/logs', logsController.getLogs.bind(logsController));

// GET    /api/servers/:guildId/logs/actions
router.get('/:guildId/logs/actions', logsController.getActions.bind(logsController));

// GET    /api/servers/:guildId/logs/export
router.get('/:guildId/logs/export', logsController.exportLogs.bind(logsController));

// DELETE /api/servers/:guildId/logs
router.delete('/:guildId/logs', logsController.deleteLogs.bind(logsController));

module.exports = router;
