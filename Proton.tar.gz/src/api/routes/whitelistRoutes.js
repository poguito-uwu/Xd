const express = require('express');
const router = express.Router();
const whitelistController = require('../controllers/whitelistController');

// GET    /api/servers/:guildId/whitelist
router.get('/:guildId/whitelist', whitelistController.getWhitelist.bind(whitelistController));

// POST   /api/servers/:guildId/whitelist
router.post('/:guildId/whitelist', whitelistController.addToWhitelist.bind(whitelistController));

// POST   /api/servers/:guildId/whitelist/bulk
router.post('/:guildId/whitelist/bulk', whitelistController.bulkAddWhitelist.bind(whitelistController));

// DELETE /api/servers/:guildId/whitelist/:whitelistId
router.delete('/:guildId/whitelist/:whitelistId', whitelistController.removeFromWhitelist.bind(whitelistController));

// DELETE /api/servers/:guildId/whitelist
router.delete('/:guildId/whitelist', whitelistController.clearWhitelist.bind(whitelistController));

module.exports = router;
