const express = require('express');
const router = express.Router();
const antiraidController = require('../controllers/antiraidController');

// GET    /api/servers/:guildId/antiraid
router.get('/:guildId/antiraid', antiraidController.getConfig.bind(antiraidController));

// PATCH  /api/servers/:guildId/antiraid/:moduleId
router.patch('/:guildId/antiraid/:moduleId', antiraidController.updateModule.bind(antiraidController));

// POST   /api/servers/:guildId/antiraid/bulk
router.post('/:guildId/antiraid/bulk', antiraidController.updateModules.bind(antiraidController));

// POST   /api/servers/:guildId/antiraid/quick-setup
router.post('/:guildId/antiraid/quick-setup', antiraidController.quickSetup.bind(antiraidController));

// DELETE /api/servers/:guildId/antiraid
router.delete('/:guildId/antiraid', antiraidController.resetConfig.bind(antiraidController));

module.exports = router;
