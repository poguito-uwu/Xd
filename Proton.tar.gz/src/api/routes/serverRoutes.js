const express = require('express');
const router = express.Router();
const serverController = require('../controllers/serverController');

// GET  /api/servers/:guildId
router.get('/:guildId', serverController.getServer.bind(serverController));

// PATCH /api/servers/:guildId
router.patch('/:guildId', serverController.updateServer.bind(serverController));

// GET  /api/servers/:guildId/stats
router.get('/:guildId/stats', serverController.getStats.bind(serverController));

// GET  /api/servers/:guildId/channels
router.get('/:guildId/channels', serverController.getChannels.bind(serverController));

// GET  /api/servers/:guildId/roles
router.get('/:guildId/roles', serverController.getRoles.bind(serverController));

module.exports = router;
