const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const PORT = process.env.API_PORT || 3001;

// ==================== MIDDLEWARES ====================

app.use(helmet({ contentSecurityPolicy: false }));

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  message: { success: false, error: 'Demasiadas solicitudes' },
  standardHeaders: true,
  legacyHeaders: false
});
app.use('/api/', limiter);

// ==================== JWT MIDDLEWARE ====================
// El token lo genera el FRONTEND con el mismo JWT_SECRET.
// La API solo lo verifica — ya no hace OAuth2.

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ success: false, error: 'Token no proporcionado' });
  }

  jwt.verify(token, process.env.JWT_SECRET || 'change-this-secret', (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, error: 'Token inválido o expirado' });
    }
    req.user = user;
    next();
  });
}

// ==================== RUTAS PÚBLICAS ====================

app.get('/', (req, res) => {
  res.json({ success: true, message: 'PROTON Guard API', version: '3.0.0' });
});

app.get('/api/status', (req, res) => {
  res.json({ success: true, status: 'online', version: '3.0.0', timestamp: new Date().toISOString() });
});

// IDs de los guilds donde está el bot (para que el frontend marque cuáles tienen el bot)
// No requiere autenticación — es info pública del bot
app.get('/api/bot/guild-ids', (req, res) => {
  try {
    const client = req.app.get('discordClient');
    if (!client) return res.json({ success: true, guildIds: [] });
    const guildIds = Array.from(client.guilds.cache.keys());
    res.json({ success: true, guildIds });
  } catch (err) {
    res.json({ success: true, guildIds: [] });
  }
});

// ==================== RUTAS PROTEGIDAS ====================
// Todas requieren JWT generado por el frontend

app.use('/api/servers', authenticateToken);

const serverRoutes   = require('./routes/serverRoutes');
const antiraidRoutes = require('./routes/antiraidRoutes');
const whitelistRoutes = require('./routes/whitelistRoutes');
const logsRoutes     = require('./routes/logsRoutes');

app.use('/api/servers', serverRoutes);
app.use('/api/servers', antiraidRoutes);
app.use('/api/servers', whitelistRoutes);
app.use('/api/servers', logsRoutes);

// ==================== ERROR HANDLERS ====================

app.use((req, res) => {
  res.status(404).json({ success: false, error: 'Endpoint no encontrado', path: req.path });
});

app.use((err, req, res, next) => {
  console.error('❌ Error en API:', err.message);
  if (err instanceof SyntaxError && err.status === 400) {
    return res.status(400).json({ success: false, error: 'JSON mal formado' });
  }
  res.status(err.status || 500).json({
    success: false,
    error: err.message || 'Error interno del servidor',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
});

// ==================== START ====================

app.listen(PORT, () => {
  console.log(`✅ API corriendo en puerto ${PORT}`);
  console.log(`📡 Health check: http://localhost:${PORT}/api/status`);
});

module.exports = app;
