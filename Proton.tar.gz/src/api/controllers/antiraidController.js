const { query } = require('../../database/mysql');

const AVAILABLE_MODULES = [
  { id: 'channelcreate', name: 'Creación de canales',    category: 'channels' },
  { id: 'channeldelete', name: 'Eliminación de canales', category: 'channels' },
  { id: 'channeledit',   name: 'Edición de canales',     category: 'channels' },
  { id: 'rolecreate',    name: 'Creación de roles',      category: 'roles' },
  { id: 'roledelete',    name: 'Eliminación de roles',   category: 'roles' },
  { id: 'roleedit',      name: 'Edición de roles',       category: 'roles' },
  { id: 'roleadd',       name: 'Añadir roles peligrosos',category: 'roles' },
  { id: 'ban',           name: 'Baneos',                 category: 'moderation' },
  { id: 'kick',          name: 'Expulsiones',            category: 'moderation' },
  { id: 'bot',           name: 'Añadir bots',            category: 'members' },
  { id: 'webhook',       name: 'Webhooks',               category: 'server' },
  { id: 'update',        name: 'Editar servidor',        category: 'server' },
  { id: 'pub',           name: 'Publicidad',             category: 'messages' },
  { id: 'ping',          name: 'Ping masivo',            category: 'messages' },
  { id: 'spam',          name: 'Spam',                   category: 'messages' }
];

async function checkAdmin(client, guildId, userId, res) {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) { res.status(404).json({ success: false, error: 'Servidor no encontrado' }); return null; }
  const member = guild.members.cache.get(userId);
  if (!member || (!member.permissions.has('Administrator') && guild.ownerId !== userId)) {
    res.status(403).json({ success: false, error: 'No tienes permisos' }); return null;
  }
  return guild;
}

class AntiraidController {
  // GET /api/proton/servers/:guildId/antiraid
  // Frontend espera: { success, modules: [...] }
  async getConfig(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      const rows = await query('SELECT * FROM antiraid_config WHERE server_id = ?', [guildId]);

      const modules = AVAILABLE_MODULES.map(mod => {
        const cfg = rows.find(m => m.module === mod.id);
        return {
          ...mod,
          enabled: !!cfg?.enabled,
          sanction: cfg?.sanction || 'kick',
          whitelist_enabled: !!cfg?.whitelist_enabled,
          custom_settings: cfg?.custom_settings ? JSON.parse(cfg.custom_settings) : {}
        };
      });

      res.json({ success: true, modules });
    } catch (error) {
      console.error('Error obteniendo config antiraid:', error);
      res.status(500).json({ success: false, error: 'Error al obtener configuración' });
    }
  }

  // PATCH /api/proton/servers/:guildId/antiraid/:moduleId
  // Frontend proxy: PATCH /api/guild/:id/antiraid/:moduleId
  async updateModule(req, res) {
    try {
      const { guildId, moduleId } = req.params;
      const { enabled, sanction, whitelist_enabled, custom_settings } = req.body;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      const [existing] = await query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ?',
        [guildId, moduleId]
      );

      if (existing) {
        const updates = [];
        const values = [];
        if (enabled !== undefined)           { updates.push('enabled = ?');           values.push(enabled); }
        if (sanction !== undefined)          { updates.push('sanction = ?');          values.push(sanction); }
        if (whitelist_enabled !== undefined) { updates.push('whitelist_enabled = ?'); values.push(whitelist_enabled); }
        if (custom_settings !== undefined)   { updates.push('custom_settings = ?');   values.push(JSON.stringify(custom_settings)); }

        if (updates.length > 0) {
          values.push(guildId, moduleId);
          await query(`UPDATE antiraid_config SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE server_id = ? AND module = ?`, values);
        }
      } else {
        await query(
          `INSERT INTO antiraid_config (server_id, module, enabled, sanction, whitelist_enabled, custom_settings) VALUES (?, ?, ?, ?, ?, ?)`,
          [guildId, moduleId, enabled ?? false, sanction || 'kick', whitelist_enabled ?? false, custom_settings ? JSON.stringify(custom_settings) : null]
        );
      }

      await query('INSERT INTO logs (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)',
        [guildId, req.user.id, 'antiraid_module_updated', JSON.stringify({ module: moduleId, enabled, sanction, whitelist_enabled })]);

      res.json({ success: true, message: 'Módulo actualizado correctamente' });
    } catch (error) {
      console.error('Error actualizando módulo:', error);
      res.status(500).json({ success: false, error: 'Error al actualizar módulo' });
    }
  }

  // POST /api/proton/servers/:guildId/antiraid/bulk
  // Frontend proxy: POST /api/guild/:id/antiraid/bulk
  async updateModules(req, res) {
    try {
      const { guildId } = req.params;
      const { modules } = req.body;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      if (!Array.isArray(modules)) {
        return res.status(400).json({ success: false, error: 'Se requiere un array de módulos' });
      }

      for (const mod of modules) {
        const { moduleId, enabled, sanction, whitelist_enabled, custom_settings } = mod;
        const [existing] = await query('SELECT * FROM antiraid_config WHERE server_id = ? AND module = ?', [guildId, moduleId]);

        if (existing) {
          await query(
            `UPDATE antiraid_config SET enabled = ?, sanction = ?, whitelist_enabled = ?, custom_settings = ?, updated_at = CURRENT_TIMESTAMP WHERE server_id = ? AND module = ?`,
            [enabled ?? existing.enabled, sanction || existing.sanction, whitelist_enabled ?? existing.whitelist_enabled,
             custom_settings ? JSON.stringify(custom_settings) : existing.custom_settings, guildId, moduleId]
          );
        } else {
          await query(
            `INSERT INTO antiraid_config (server_id, module, enabled, sanction, whitelist_enabled, custom_settings) VALUES (?, ?, ?, ?, ?, ?)`,
            [guildId, moduleId, enabled ?? false, sanction || 'kick', whitelist_enabled ?? false, custom_settings ? JSON.stringify(custom_settings) : null]
          );
        }
      }

      await query('INSERT INTO logs (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)',
        [guildId, req.user.id, 'antiraid_bulk_updated', JSON.stringify({ count: modules.length })]);

      res.json({ success: true, message: `${modules.length} módulo(s) actualizado(s)` });
    } catch (error) {
      console.error('Error en bulk update:', error);
      res.status(500).json({ success: false, error: 'Error al actualizar módulos' });
    }
  }

  // POST /api/proton/servers/:guildId/antiraid/quick-setup
  // Frontend proxy: POST /api/guild/:id/antiraid/quick-setup
  async quickSetup(req, res) {
    try {
      const { guildId } = req.params;
      const { level } = req.body;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      const configs = {
        basic:  { modules: ['channelcreate', 'channeldelete', 'rolecreate', 'roledelete', 'ban'], sanction: 'kick',   whitelist: false },
        medium: { modules: ['channelcreate', 'channeldelete', 'channeledit', 'rolecreate', 'roledelete', 'roleedit', 'ban', 'kick', 'bot'], sanction: 'derank', whitelist: true },
        high:   { modules: ['channelcreate', 'channeldelete', 'channeledit', 'rolecreate', 'roledelete', 'roleedit', 'ban', 'kick', 'bot', 'webhook', 'update', 'roleadd'], sanction: 'ban', whitelist: true },
        max:    { modules: AVAILABLE_MODULES.map(m => m.id), sanction: 'ban', whitelist: true }
      };

      const config = configs[level];
      if (!config) return res.status(400).json({ success: false, error: 'Nivel inválido. Usa: basic, medium, high, max' });

      await query('DELETE FROM antiraid_config WHERE server_id = ?', [guildId]);

      for (const module of config.modules) {
        await query(
          `INSERT INTO antiraid_config (server_id, module, enabled, sanction, whitelist_enabled) VALUES (?, ?, TRUE, ?, ?)`,
          [guildId, module, config.sanction, config.whitelist]
        );
      }

      await query('INSERT INTO logs (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)',
        [guildId, req.user.id, 'antiraid_quick_setup', JSON.stringify({ level, modules: config.modules })]);

      res.json({ success: true, message: 'Configuración rápida aplicada', config: { level, modulesCount: config.modules.length, sanction: config.sanction } });
    } catch (error) {
      console.error('Error en quick-setup:', error);
      res.status(500).json({ success: false, error: 'Error al aplicar configuración rápida' });
    }
  }

  // DELETE /api/proton/servers/:guildId/antiraid
  // Frontend proxy: DELETE /api/guild/:id/antiraid
  async resetConfig(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      await query('DELETE FROM antiraid_config WHERE server_id = ?', [guildId]);
      await query('INSERT INTO logs (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)',
        [guildId, req.user.id, 'antiraid_config_reset', null]);

      res.json({ success: true, message: 'Configuración reseteada' });
    } catch (error) {
      console.error('Error reseteando antiraid:', error);
      res.status(500).json({ success: false, error: 'Error al resetear configuración' });
    }
  }
}

module.exports = new AntiraidController();
