const { query } = require('../../database/mysql');

// Verifica que el usuario autenticado sea admin en el guild
async function checkAdmin(client, guildId, userId, res) {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) {
    res.status(404).json({ success: false, error: 'El bot no está en este servidor' });
    return null;
  }
  const member = guild.members.cache.get(userId);
  if (!member || (!member.permissions.has('Administrator') && guild.ownerId !== userId)) {
    res.status(403).json({ success: false, error: 'No tienes permisos de administrador' });
    return null;
  }
  return guild;
}

class ServerController {
  // GET /api/servers/:guildId
  async getServer(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      const guild = await checkAdmin(client, guildId, req.user.id, res);
      if (!guild) return;

      const [serverData] = await query('SELECT * FROM servers WHERE id = ?', [guildId]);

      res.json({
        success: true,
        server: {
          id:          guild.id,
          name:        guild.name,
          icon:        guild.iconURL() || null,
          memberCount: guild.memberCount,
          ownerId:     guild.ownerId,
          config:      serverData || {}
        }
      });
    } catch (err) {
      console.error('Error getServer:', err);
      res.status(500).json({ success: false, error: 'Error al obtener servidor' });
    }
  }

  // PATCH /api/servers/:guildId
  async updateServer(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      const guild = await checkAdmin(client, guildId, req.user.id, res);
      if (!guild) return;

      const allowedFields = ['prefix', 'logs_channel', 'locale'];
      const updateFields = {};
      for (const field of allowedFields) {
        if (req.body[field] !== undefined) updateFields[field] = req.body[field];
      }

      if (!Object.keys(updateFields).length) {
        return res.status(400).json({ success: false, error: 'No hay campos válidos para actualizar' });
      }

      const [existing] = await query('SELECT id FROM servers WHERE id = ?', [guildId]);
      if (!existing) {
        await query('INSERT INTO servers (id, name, owner_id) VALUES (?, ?, ?)', [guildId, guild.name, guild.ownerId]);
      }

      const fields = Object.keys(updateFields).map(k => `${k} = ?`).join(', ');
      await query(`UPDATE servers SET ${fields}, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [...Object.values(updateFields), guildId]);

      await query('INSERT INTO logs (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)',
        [guildId, req.user.id, 'server_config_updated', JSON.stringify(updateFields)]);

      res.json({ success: true, message: 'Configuración actualizada', updates: updateFields });
    } catch (err) {
      console.error('Error updateServer:', err);
      res.status(500).json({ success: false, error: 'Error al actualizar servidor' });
    }
  }

  // GET /api/servers/:guildId/stats
  async getStats(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      const guild = await checkAdmin(client, guildId, req.user.id, res);
      if (!guild) return;

      const [logsCount] = await query(
        `SELECT COUNT(*) as total,
          COUNT(CASE WHEN action LIKE '%ban%' THEN 1 END) as bans,
          COUNT(CASE WHEN action LIKE '%kick%' THEN 1 END) as kicks,
          COUNT(CASE WHEN action LIKE '%antiraid%' THEN 1 END) as antiraid_triggers
         FROM logs WHERE guild_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)`,
        [guildId]
      );
      const [modulesCount]   = await query('SELECT COUNT(*) as count FROM antiraid_config WHERE server_id = ? AND enabled = TRUE', [guildId]);
      const [whitelistCount] = await query('SELECT COUNT(*) as count FROM whitelist WHERE server_id = ?', [guildId]);
      const activity = await query(
        `SELECT DATE(created_at) as date, COUNT(*) as count,
          COUNT(CASE WHEN action LIKE '%antiraid%' THEN 1 END) as antiraid_count
         FROM logs WHERE guild_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 7 DAY)
         GROUP BY DATE(created_at) ORDER BY date ASC`,
        [guildId]
      );

      res.json({
        success: true,
        stats: {
          members:  { total: guild.memberCount, bots: guild.members.cache.filter(m => m.user.bot).size },
          channels: { total: guild.channels.cache.size, text: guild.channels.cache.filter(c => c.type === 0).size, voice: guild.channels.cache.filter(c => c.type === 2).size },
          roles:    guild.roles.cache.size,
          logs:     logsCount || { total: 0, bans: 0, kicks: 0, antiraid_triggers: 0 },
          antiraid: { modulesActive: modulesCount?.count || 0, whitelistUsers: whitelistCount?.count || 0 },
          activity: activity || []
        }
      });
    } catch (err) {
      console.error('Error getStats:', err);
      res.status(500).json({ success: false, error: 'Error al obtener estadísticas' });
    }
  }

  // GET /api/servers/:guildId/channels
  async getChannels(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      const guild = await checkAdmin(client, guildId, req.user.id, res);
      if (!guild) return;

      const channels = guild.channels.cache
        .filter(c => c.type === 0)
        .map(c => ({ id: c.id, name: c.name, position: c.position, parentId: c.parentId }))
        .sort((a, b) => a.position - b.position);

      res.json({ success: true, channels });
    } catch (err) {
      console.error('Error getChannels:', err);
      res.status(500).json({ success: false, error: 'Error al obtener canales' });
    }
  }

  // GET /api/servers/:guildId/roles
  async getRoles(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      const guild = await checkAdmin(client, guildId, req.user.id, res);
      if (!guild) return;

      const roles = guild.roles.cache
        .filter(r => r.id !== guild.id)
        .map(r => ({ id: r.id, name: r.name, color: r.hexColor, position: r.position, mentionable: r.mentionable }))
        .sort((a, b) => b.position - a.position);

      res.json({ success: true, roles });
    } catch (err) {
      console.error('Error getRoles:', err);
      res.status(500).json({ success: false, error: 'Error al obtener roles' });
    }
  }
}

module.exports = new ServerController();
