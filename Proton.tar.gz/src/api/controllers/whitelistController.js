const { query } = require('../../database/mysql');

async function checkAdmin(client, guildId, userId, res) {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) { res.status(404).json({ success: false, error: 'Servidor no encontrado' }); return null; }
  const member = guild.members.cache.get(userId);
  if (!member || (!member.permissions.has('Administrator') && guild.ownerId !== userId)) {
    res.status(403).json({ success: false, error: 'No tienes permisos' }); return null;
  }
  return guild;
}

class WhitelistController {
  // GET /api/proton/servers/:guildId/whitelist
  // Frontend espera: { success, whitelist: [...], pagination: { total } }
  async getWhitelist(req, res) {
    try {
      const { guildId } = req.params;
      const { page = 1, limit = 50 } = req.query;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      const offset = (page - 1) * limit;
      const whitelist = await query(
        'SELECT * FROM whitelist WHERE server_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?',
        [guildId, parseInt(limit), offset]
      );

      const [countRow] = await query('SELECT COUNT(*) as total FROM whitelist WHERE server_id = ?', [guildId]);

      res.json({
        success: true,
        whitelist,
        pagination: {
          total: countRow?.total || 0,
          page: parseInt(page),
          limit: parseInt(limit),
          pages: Math.ceil((countRow?.total || 0) / limit)
        }
      });
    } catch (error) {
      console.error('Error obteniendo whitelist:', error);
      res.status(500).json({ success: false, error: 'Error al obtener whitelist' });
    }
  }

  // POST /api/proton/servers/:guildId/whitelist
  // Frontend proxy: POST /api/guild/:id/whitelist → body: { user_id, reason }
  async addToWhitelist(req, res) {
    try {
      const { guildId } = req.params;
      const { user_id, reason } = req.body;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      if (!user_id) return res.status(400).json({ success: false, error: 'user_id es requerido' });

      await query(
        `INSERT INTO whitelist (server_id, user_id, added_by, reason) VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE reason = VALUES(reason), added_by = VALUES(added_by)`,
        [guildId, user_id, req.user.id, reason || 'Sin razón especificada']
      );

      await query('INSERT INTO logs (guild_id, user_id, action, target_id, details) VALUES (?, ?, ?, ?, ?)',
        [guildId, req.user.id, 'whitelist_add', user_id, JSON.stringify({ reason })]);

      res.json({ success: true, message: 'Usuario añadido a la whitelist' });
    } catch (error) {
      console.error('Error añadiendo a whitelist:', error);
      res.status(500).json({ success: false, error: 'Error al añadir a whitelist' });
    }
  }

  // DELETE /api/proton/servers/:guildId/whitelist/:whitelistId
  // Frontend proxy: DELETE /api/guild/:id/whitelist/:whitelistId
  async removeFromWhitelist(req, res) {
    try {
      const { guildId, whitelistId } = req.params;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      await query('DELETE FROM whitelist WHERE server_id = ? AND id = ?', [guildId, whitelistId]);

      await query('INSERT INTO logs (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)',
        [guildId, req.user.id, 'whitelist_remove', JSON.stringify({ whitelistId })]);

      res.json({ success: true, message: 'Usuario removido de la whitelist' });
    } catch (error) {
      console.error('Error removiendo de whitelist:', error);
      res.status(500).json({ success: false, error: 'Error al remover de whitelist' });
    }
  }

  // DELETE /api/proton/servers/:guildId/whitelist
  // Frontend proxy: DELETE /api/guild/:id/whitelist (clear all)
  async clearWhitelist(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      const result = await query('DELETE FROM whitelist WHERE server_id = ?', [guildId]);

      await query('INSERT INTO logs (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)',
        [guildId, req.user.id, 'whitelist_clear', JSON.stringify({ deleted: result.affectedRows })]);

      res.json({ success: true, message: `${result.affectedRows} entradas eliminadas`, deleted: result.affectedRows });
    } catch (error) {
      console.error('Error limpiando whitelist:', error);
      res.status(500).json({ success: false, error: 'Error al limpiar whitelist' });
    }
  }

  // POST /api/proton/servers/:guildId/whitelist/bulk
  // Frontend proxy: POST /api/guild/:id/whitelist/bulk
  async bulkAddWhitelist(req, res) {
    try {
      const { guildId } = req.params;
      const { users } = req.body; // [{ user_id, reason }]
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      if (!Array.isArray(users) || users.length === 0) {
        return res.status(400).json({ success: false, error: 'Se requiere un array de usuarios' });
      }

      for (const u of users) {
        if (!u.user_id) continue;
        await query(
          `INSERT INTO whitelist (server_id, user_id, added_by, reason) VALUES (?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE reason = VALUES(reason)`,
          [guildId, u.user_id, req.user.id, u.reason || 'Bulk add']
        );
      }

      await query('INSERT INTO logs (guild_id, user_id, action, details) VALUES (?, ?, ?, ?)',
        [guildId, req.user.id, 'whitelist_bulk_add', JSON.stringify({ count: users.length })]);

      res.json({ success: true, message: `${users.length} usuario(s) añadidos a la whitelist` });
    } catch (error) {
      console.error('Error en bulk whitelist:', error);
      res.status(500).json({ success: false, error: 'Error al añadir usuarios en bulk' });
    }
  }
}

module.exports = new WhitelistController();
