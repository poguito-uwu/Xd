const { query } = require('../../database/mysql');

async function checkAdmin(client, guildId, userId, res) {
  const guild = client.guilds.cache.get(guildId);
  if (!guild) { res.status(404).json({ success: false, error: 'Servidor no encontrado' }); return null; }
  const member = guild.members.cache.get(userId);
  if (!member || (!member.permissions.has('Administrator') && guild.ownerId !== userId)) {
    res.status(403).json({ success: false, error: 'No tienes permisos' }); return null;
  }
  return guild;
}

async function enrichLog(log, client) {
  let user = null;
  let target = null;

  if (log.user_id) {
    try {
      const u = await client.users.fetch(log.user_id);
      user = { id: u.id, username: u.username, discriminator: u.discriminator, avatar: u.avatarURL() };
    } catch (_) { user = { id: log.user_id, username: 'Usuario desconocido' }; }
  }

  if (log.target_id) {
    try {
      const t = await client.users.fetch(log.target_id);
      target = { id: t.id, username: t.username, discriminator: t.discriminator, avatar: t.avatarURL() };
    } catch (_) { target = { id: log.target_id, username: 'Usuario desconocido' }; }
  }

  return {
    id: log.id,
    action: log.action,
    user,
    target,
    details: log.details ? JSON.parse(log.details) : null,
    createdAt: log.created_at
  };
}

class LogsController {
  // GET /api/proton/servers/:guildId/logs
  // Frontend proxy: GET /api/guild/:id/logs
  // Frontend espera: { success, logs: [...], pagination: { total, limit, offset, pages } }
  async getLogs(req, res) {
    try {
      const { guildId } = req.params;
      const { page = 1, limit = 50, action = '', userId = '', startDate = '', endDate = '', sortBy = 'created_at', sortOrder = 'DESC' } = req.query;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      let sql = 'SELECT * FROM logs WHERE guild_id = ?';
      const params = [guildId];

      if (action)    { sql += ' AND action LIKE ?';                    params.push(`%${action}%`); }
      if (userId)    { sql += ' AND (user_id = ? OR target_id = ?)';   params.push(userId, userId); }
      if (startDate) { sql += ' AND created_at >= ?';                  params.push(startDate); }
      if (endDate)   { sql += ' AND created_at <= ?';                  params.push(endDate); }

      const [countResult] = await query(sql.replace('SELECT *', 'SELECT COUNT(*) as total'), params);
      const total = countResult?.total || 0;

      const validSortBy    = ['created_at', 'action', 'user_id'];
      const validSortOrder = ['ASC', 'DESC'];
      const finalSort      = validSortBy.includes(sortBy) ? sortBy : 'created_at';
      const finalOrder     = validSortOrder.includes(sortOrder.toUpperCase()) ? sortOrder.toUpperCase() : 'DESC';

      sql += ` ORDER BY ${finalSort} ${finalOrder} LIMIT ? OFFSET ?`;
      params.push(parseInt(limit), (page - 1) * parseInt(limit));

      const logs = await query(sql, params);
      const enrichedLogs = await Promise.all(logs.map(l => enrichLog(l, client)));

      res.json({
        success: true,
        logs: enrichedLogs,
        pagination: { total, limit: parseInt(limit), offset: (page - 1) * parseInt(limit), pages: Math.ceil(total / limit) }
      });
    } catch (error) {
      console.error('Error obteniendo logs:', error);
      res.status(500).json({ success: false, error: 'Error al obtener logs' });
    }
  }

  // GET /api/proton/servers/:guildId/logs/actions
  // Frontend proxy: GET /api/guild/:id/logs/actions
  async getActions(req, res) {
    try {
      const { guildId } = req.params;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      const actions = await query('SELECT DISTINCT action FROM logs WHERE guild_id = ? ORDER BY action', [guildId]);
      res.json({ success: true, actions: actions.map(a => a.action) });
    } catch (error) {
      console.error('Error obteniendo acciones:', error);
      res.status(500).json({ success: false, error: 'Error al obtener acciones' });
    }
  }

  // DELETE /api/proton/servers/:guildId/logs
  // Frontend proxy: DELETE /api/guild/:id/logs → body: { days }
  async deleteLogs(req, res) {
    try {
      const { guildId } = req.params;
      const { days = 30 } = req.body;
      const client = req.app.get('discordClient');
      if (!await checkAdmin(client, guildId, req.user.id, res)) return;

      const result = await query(
        'DELETE FROM logs WHERE guild_id = ? AND created_at < DATE_SUB(NOW(), INTERVAL ? DAY)',
        [guildId, parseInt(days)]
      );

      res.json({ success: true, message: `${result.affectedRows} logs eliminados`, deleted: result.affectedRows });
    } catch (error) {
      console.error('Error eliminando logs:', error);
      res.status(500).json({ success: false, error: 'Error al eliminar logs' });
    }
  }

  // GET /api/proton/servers/:guildId/logs/export
  // Frontend proxy: GET /api/guild/:id/logs/export
  async exportLogs(req, res) {
    try {
      const { guildId } = req.params;
      const { startDate = '', endDate = '', format = 'json' } = req.query;
      const client = req.app.get('discordClient');
      const guild = await checkAdmin(client, guildId, req.user.id, res);
      if (!guild) return;

      let sql = 'SELECT * FROM logs WHERE guild_id = ?';
      const params = [guildId];
      if (startDate) { sql += ' AND created_at >= ?'; params.push(startDate); }
      if (endDate)   { sql += ' AND created_at <= ?'; params.push(endDate); }
      sql += ' ORDER BY created_at DESC';

      const logs = await query(sql, params);
      const enrichedLogs = await Promise.all(logs.map(l => enrichLog(l, client)));

      if (format === 'csv') {
        const csv = [
          'ID,Acción,Usuario ID,Usuario,Target ID,Target,Fecha',
          ...enrichedLogs.map(l =>
            `${l.id},"${l.action}","${l.user?.id || ''}","${l.user?.username || ''}","${l.target?.id || ''}","${l.target?.username || ''}","${l.createdAt}"`
          )
        ].join('\n');
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="logs-${guildId}-${Date.now()}.csv"`);
        return res.send(csv);
      }

      res.setHeader('Content-Type', 'application/json');
      res.setHeader('Content-Disposition', `attachment; filename="logs-${guildId}-${Date.now()}.json"`);
      res.json({ server: { id: guild.id, name: guild.name }, exportedAt: new Date().toISOString(), totalLogs: enrichedLogs.length, logs: enrichedLogs });
    } catch (error) {
      console.error('Error exportando logs:', error);
      res.status(500).json({ success: false, error: 'Error al exportar logs' });
    }
  }
}

module.exports = new LogsController();
