const { query } = require('../database/mysql');

class PremiumManager {
  // Verificar si un servidor tiene premium
  async hasPremium(guildId) {
    try {
      const [premium] = await query(
        'SELECT * FROM premium_users WHERE guild_id = ? AND expires_at > NOW()',
        [guildId]
      );
      
      return premium || null;
    } catch (error) {
      console.error('Error verificando premium:', error);
      return null;
    }
  }
  
  // Verificar tier premium
  async getTier(guildId) {
    const premium = await this.hasPremium(guildId);
    return premium ? premium.tier : 0;
  }
  
  // Obtener límites según tier
  getLimits(tier) {
    const limits = {
      0: { // Free
        maxModules: 5,
        maxWhitelist: 10,
        maxBackups: 1,
        customSanctions: false,
        advancedFeatures: false
      },
      1: { // Basic
        maxModules: 10,
        maxWhitelist: 25,
        maxBackups: 3,
        customSanctions: true,
        advancedFeatures: false
      },
      2: { // Pro
        maxModules: 20,
        maxWhitelist: 50,
        maxBackups: 10,
        customSanctions: true,
        advancedFeatures: true
      },
      3: { // Enterprise
        maxModules: 999,
        maxWhitelist: 999,
        maxBackups: 999,
        customSanctions: true,
        advancedFeatures: true
      }
    };
    
    return limits[tier] || limits[0];
  }
  
  // Verificar si una función está disponible
  async canUseFeature(guildId, feature) {
    const tier = await this.getTier(guildId);
    const limits = this.getLimits(tier);
    
    const featureMap = {
      'anti-flood': tier >= 1,
      'anti-alts': tier >= 1,
      'anti-links': tier >= 1,
      'anti-mass-mute': tier >= 2,
      'anti-webhook-spam': tier >= 2,
      'anti-everyone-permission': tier >= 1,
      'custom-sanctions': limits.customSanctions,
      'advanced-logs': tier >= 1,
      'auto-backup': tier >= 1
    };
    
    return featureMap[feature] || false;
  }
  
  // Añadir premium a un servidor
  async addPremium(guildId, userId, tier = 1, months = 1) {
    try {
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + months);
      
      await query(
        `INSERT INTO premium_users (guild_id, user_id, tier, expires_at) 
                 VALUES (?, ?, ?, ?) 
                 ON DUPLICATE KEY UPDATE tier = ?, expires_at = ?`,
        [guildId, userId, tier, expiresAt, tier, expiresAt]
      );
      
      return true;
    } catch (error) {
      console.error('Error añadiendo premium:', error);
      return false;
    }
  }
  
  // Remover premium
  async removePremium(guildId) {
    try {
      await query(
        'DELETE FROM premium_users WHERE guild_id = ?',
        [guildId]
      );
      
      return true;
    } catch (error) {
      console.error('Error removiendo premium:', error);
      return false;
    }
  }
  
  // Obtener estadísticas premium
  async getStats() {
    try {
      const [totalPremium] = await query(
        'SELECT COUNT(*) as count FROM premium_users WHERE expires_at > NOW()'
      );
      
      const [revenue] = await query(
        'SELECT SUM(tier * 4.99) as revenue FROM premium_users WHERE expires_at > NOW()'
      );
      
      return {
        total: totalPremium.count,
        revenue: revenue.revenue || 0
      };
    } catch (error) {
      console.error('Error obteniendo stats premium:', error);
      return { total: 0, revenue: 0 };
    }
  }
}

module.exports = new PremiumManager();