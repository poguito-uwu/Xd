const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'guildUpdate',
  async execute(oldGuild, newGuild, client) {
    const guildId = newGuild.id;
    
    // Prevenir procesamiento duplicado
    if (antiraidHelper.isEventProcessed(guildId, 'guildUpdate', guildId)) {
      return;
    }
    
    try {
      // Obtener configuración del módulo update
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'update']
      );
      
      if (!config) return;
      
      // Detectar cambios significativos
      const changes = [];
      
      if (oldGuild.name !== newGuild.name) {
        changes.push(`Nombre: ${oldGuild.name} → ${newGuild.name}`);
      }
      
      if (oldGuild.vanityURLCode !== newGuild.vanityURLCode) {
        changes.push(`URL personalizada: ${oldGuild.vanityURLCode || 'ninguna'} → ${newGuild.vanityURLCode || 'ninguna'}`);
      }
      
      if (oldGuild.verificationLevel !== newGuild.verificationLevel) {
        changes.push(`Verificación: ${oldGuild.verificationLevel} → ${newGuild.verificationLevel}`);
      }
      
      if (oldGuild.explicitContentFilter !== newGuild.explicitContentFilter) {
        changes.push(`Filtro contenido: ${oldGuild.explicitContentFilter} → ${newGuild.explicitContentFilter}`);
      }
      
      if (oldGuild.afkChannelId !== newGuild.afkChannelId) {
        changes.push('Canal AFK modificado');
      }
      
      if (oldGuild.systemChannelId !== newGuild.systemChannelId) {
        changes.push('Canal sistema modificado');
      }
      
      // Solo actuar si hubo cambios
      if (changes.length === 0) return;
      
      // Obtener audit log con el helper
      const auditEntry = await antiraidHelper.getAuditLog(newGuild, {
        type: AuditLogEvent.GuildUpdate
      });
      
      if (!auditEntry) {
        console.warn(`[AntiRaid] No se encontró audit log para edición de servidor`);
        return;
      }
      
      const executor = await newGuild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) return;
      
      // Verificar permisos con el helper
      const permCheck = await antiraidHelper.checkPermissions(client, newGuild, executor, config);
      
      if (permCheck.allowed) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Edición no autorizada del servidor`;
      
      // Intentar revertir cambios críticos
      let reverted = false;
      try {
        await newGuild.edit({
          name: oldGuild.name,
          verificationLevel: oldGuild.verificationLevel,
          explicitContentFilter: oldGuild.explicitContentFilter,
          afkChannel: oldGuild.afkChannelId,
          systemChannel: oldGuild.systemChannelId,
          reason: raison
        });
        reverted = true;
      } catch (error) {
        console.error(`[AntiRaid] Error revirtiendo cambios del servidor:`, error.message);
      }
      
      // Aplicar sanción con el helper
      const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
      
      // Enviar log con el helper (previene spam)
      await antiraidHelper.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'guild_update_blocked',
        details: {
          guild_name: newGuild.name,
          changes: changes.join(' | '),
          reverted: reverted,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en BD con el helper
      await antiraidHelper.createDatabaseLog(
        client,
        guildId,
        executor.id,
        'guild_update_blocked',
        guildId,
        {
          guild_name: newGuild.name,
          changes: changes,
          reverted: reverted,
          sanction: config.sanction,
          sanction_success: sanctionResult.success
        }
      );
      
    } catch (error) {
      console.error('[AntiRaid] Error en guildUpdate:', error);
    }
  }
};