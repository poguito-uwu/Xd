const { AuditLogEvent } = require('discord.js');

// Cache para prevenir spam de logs
const eventCache = new Map();
const CACHE_DURATION = 2000; // 2 segundos

module.exports = {
  name: 'channelCreate',
  async execute(channel, client) {
    if (!channel.guild) return;
    
    const guild = channel.guild;
    const guildId = guild.id;
    
    // CACHE KEY: prevenir procesamiento duplicado del mismo evento
    const cacheKey = `${guildId}-channelCreate-${channel.id}`;
    
    // Si ya procesamos este evento recientemente, ignorar
    if (eventCache.has(cacheKey)) {
      return;
    }
    
    // Marcar evento como procesado
    eventCache.set(cacheKey, true);
    setTimeout(() => eventCache.delete(cacheKey), CACHE_DURATION);
    
    try {
      // Verificar que el bot tenga permisos para ver audit logs
      const botMember = guild.members.cache.get(client.user.id);
      if (!botMember || !botMember.permissions.has('ViewAuditLog')) {
        console.warn(`[AntiRaid] Sin permisos de AuditLog en ${guild.name}`);
        return;
      }
      
      // Obtener configuración del módulo
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'channelcreate']
      );
      
      if (!config) return;
      
      // Esperar un poco para que los audit logs se actualicen
      await new Promise(resolve => setTimeout(resolve, 500));
      
      // Obtener audit logs
      const auditLogs = await guild.fetchAuditLogs({
        limit: 5, // Aumentado a 5 para mayor precisión
        type: AuditLogEvent.ChannelCreate
      });
      
      // Buscar el audit log específico para este canal
      const auditEntry = auditLogs.entries.find(entry => 
        entry.target?.id === channel.id && 
        Date.now() - entry.createdTimestamp < 5000 // Últimos 5 segundos
      );
      
      if (!auditEntry) {
        console.warn(`[AntiRaid] No se encontró audit log para canal ${channel.name} en ${guild.name}`);
        return;
      }
      
      const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) {
        console.warn(`[AntiRaid] Ejecutor no encontrado para canal ${channel.name}`);
        return;
      }
      
      // Verificar que el ejecutor no es el bot mismo
      if (executor.id === client.user.id) return;
      
      // Verificar permisos/whitelist
      const isAllowed = await this.checkPermissions(client, guild, executor, config);
      
      if (isAllowed) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Creación no autorizada de canal: ${channel.name}`;
      
      // Eliminar canal creado
      let channelDeleted = false;
      try {
        await channel.delete(raison);
        channelDeleted = true;
      } catch (error) {
        console.error(`[AntiRaid] Error eliminando canal en ${guild.name}:`, error.message);
      }
      
      // Aplicar sanción al ejecutor
      const sanctionResult = await this.applySanction(executor, config.sanction, raison);
      
      // Enviar log SOLO UNA VEZ
      await this.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'channel_create_blocked',
        details: {
          channel_name: channel.name,
          channel_type: channel.type,
          channel_deleted: channelDeleted,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en base de datos UNA SOLA VEZ
      if (client.db.createLog) {
        await client.db.createLog(guildId, executor.id, 'channel_create_blocked', channel.id, {
          channel_name: channel.name,
          channel_type: channel.type,
          channel_deleted: channelDeleted,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error,
          timestamp: Date.now()
        });
      }
      
    } catch (error) {
      console.error('[AntiRaid] Error en channelCreate:', error);
    }
  },
  
  // Verificar permisos y whitelist
  async checkPermissions(client, guild, executor, config) {
    try {
      // 1. Owner del bot
      const owners = process.env.OWNER_IDS?.split(',').map(id => id.trim()) || [];
      if (owners.includes(executor.id)) return true;
      
      // 2. Owner del servidor
      if (guild.ownerId === executor.id) return true;
      
      // 3. Bot mismo
      if (executor.id === client.user.id) return true;
      
      // 4. Verificar rol de administrador si está permitido
      if (executor.permissions.has('Administrator')) {
        // Algunos servidores quieren proteger incluso admins
        // Esto es configurable
        const protectAdmins = config.custom_settings?.protect_admins !== false;
        if (!protectAdmins) return true;
      }
      
      // 5. Whitelist
      if (config.whitelist_enabled) {
        const [whitelisted] = await client.db.query(
          'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
          [guild.id, executor.id]
        );
        
        if (whitelisted) return true;
      }
      
      return false;
    } catch (error) {
      console.error('[AntiRaid] Error verificando permisos:', error);
      return false;
    }
  },
  
  // Aplicar sanción
  async applySanction(member, sanctionType, reason) {
    const result = { success: false, error: null };
    
    try {
      // Verificar que el bot puede sancionar a este usuario
      const botMember = member.guild.members.cache.get(member.client.user.id);
      
      if (!botMember) {
        result.error = 'Bot no encontrado en el servidor';
        return result;
      }
      
      // Verificar jerarquía de roles
      if (member.roles.highest.position >= botMember.roles.highest.position) {
        result.error = 'Jerarquía de roles insuficiente';
        return result;
      }
      
      // Aplicar sanción
      switch (sanctionType) {
        case 'ban':
          if (!botMember.permissions.has('BanMembers')) {
            result.error = 'Sin permiso para banear';
            return result;
          }
          await member.ban({ reason, deleteMessageSeconds: 0 });
          result.success = true;
          break;
          
        case 'kick':
          if (!botMember.permissions.has('KickMembers')) {
            result.error = 'Sin permiso para expulsar';
            return result;
          }
          await member.kick(reason);
          result.success = true;
          break;
          
        case 'derank':
          if (!botMember.permissions.has('ManageRoles')) {
            result.error = 'Sin permiso para gestionar roles';
            return result;
          }
          await member.roles.set([], reason);
          result.success = true;
          break;
          
        default:
          result.error = 'Tipo de sanción desconocido';
      }
      
    } catch (error) {
      result.error = error.message;
      console.error(`[AntiRaid] Error aplicando sanción ${sanctionType}:`, error.message);
    }
    
    return result;
  },
  
  // Enviar log AL CANAL (SOLO UNA VEZ)
  async sendLog(client, guildId, data) {
    // Cache para prevenir envío duplicado de logs
    const logCacheKey = `log-${guildId}-${data.action}-${data.user.id}-${Date.now()}`;
    
    if (eventCache.has(logCacheKey)) {
      return; // Ya enviamos este log
    }
    
    eventCache.set(logCacheKey, true);
    setTimeout(() => eventCache.delete(logCacheKey), 5000);
    
    try {
      const server = await client.db.getServer(guildId);
      if (!server?.logs_channel) return;
      
      const guild = client.guilds.cache.get(guildId);
      if (!guild) return;
      
      const logChannel = guild.channels.cache.get(server.logs_channel);
      if (!logChannel) return;
      
      // Verificar permisos del bot
      const permissions = logChannel.permissionsFor(client.user);
      if (!permissions || !permissions.has(['SendMessages', 'EmbedLinks'])) {
        console.warn(`[AntiRaid] Sin permisos para enviar logs en ${guild.name}`);
        return;
      }
      
      const statusIcon = data.details.sanction_success ? '✅' : '❌';
      const channelDeletedIcon = data.details.channel_deleted ? '✅' : '❌';
      
      const embed = client.embeds.warning(
        '🛡️ Creación de Canal Bloqueada',
        `**Usuario:** <@${data.user.id}> (\`${data.user.tag}\`)
**ID Usuario:** \`${data.user.id}\`

**Canal:** \`${data.details.channel_name}\`
**Tipo:** ${data.details.channel_type}
**Canal eliminado:** ${channelDeletedIcon}

**Sanción:** ${data.details.sanction}
**Sanción aplicada:** ${statusIcon}
${data.details.sanction_error ? `**Error:** \`${data.details.sanction_error}\`` : ''}

**Razón:** Anti-Raid protección automática
**Timestamp:** <t:${Math.floor(Date.now() / 1000)}:F>`
      );
      
      await logChannel.send({ embeds: [embed] }).catch(err => {
        console.error(`[AntiRaid] Error enviando log a canal:`, err.message);
      });
      
    } catch (error) {
      console.error('[AntiRaid] Error en sendLog:', error);
    }
  }
};
