const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'channelUpdate',
  async execute(oldChannel, newChannel, client) {
    if (!newChannel.guild) return;
    
    const guild = newChannel.guild;
    const guildId = guild.id;
    
    // Prevenir procesamiento duplicado
    if (antiraidHelper.isEventProcessed(guildId, 'channelUpdate', newChannel.id)) {
      return;
    }
    
    try {
      // Obtener configuración del módulo
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'channeledit']
      );
      
      if (!config) return;
      
      // Obtener audit log con el helper
      const auditEntry = await antiraidHelper.getAuditLog(guild, {
        type: AuditLogEvent.ChannelUpdate,
        targetId: newChannel.id
      });
      
      if (!auditEntry) {
        console.warn(`[AntiRaid] No se encontró audit log para edición de canal ${newChannel.name}`);
        return;
      }
      
      const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) return;
      
      // Verificar permisos con el helper
      const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, config);
      
      if (permCheck.allowed) return;
      
      // Detectar cambios importantes
      const changes = [];
      
      if (oldChannel.name !== newChannel.name) {
        changes.push(`Nombre: ${oldChannel.name} → ${newChannel.name}`);
      }
      
      if (oldChannel.topic !== newChannel.topic) {
        changes.push('Tema modificado');
      }
      
      if (oldChannel.nsfw !== newChannel.nsfw) {
        changes.push(`NSFW: ${oldChannel.nsfw} → ${newChannel.nsfw}`);
      }
      
      if (oldChannel.parentId !== newChannel.parentId) {
        changes.push('Categoría cambiada');
      }
      
      // Solo actuar si hubo cambios significativos
      if (changes.length === 0) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Edición no autorizada de canal: ${newChannel.name}`;
      
      // Intentar revertir cambios
      let reverted = false;
      try {
        await newChannel.edit({
          name: oldChannel.name,
          topic: oldChannel.topic,
          nsfw: oldChannel.nsfw,
          parentId: oldChannel.parentId,
          rateLimitPerUser: oldChannel.rateLimitPerUser,
          reason: raison
        });
        reverted = true;
      } catch (error) {
        console.error(`[AntiRaid] Error revirtiendo cambios:`, error.message);
      }
      
      // Aplicar sanción con el helper
      const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
      
      // Enviar log con el helper (previene spam)
      await antiraidHelper.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'channel_update_blocked',
        details: {
          channel_name: newChannel.name,
          channel_type: newChannel.type,
          changes: changes.join(', '),
          reverted: reverted,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en BD con el helper
      await antiraidHelper.createDatabaseLog(
        client,
        guildId,
        executor.id,
        'channel_update_blocked',
        newChannel.id,
        {
          channel_name: newChannel.name,
          changes: changes,
          reverted: reverted,
          sanction: config.sanction,
          sanction_success: sanctionResult.success
        }
      );
      
    } catch (error) {
      console.error('[AntiRaid] Error en channelUpdate:', error);
    }
  }
};