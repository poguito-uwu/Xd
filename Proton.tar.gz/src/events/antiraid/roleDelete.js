const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'roleDelete',
  async execute(role, client) {
    if (!role.guild) return;
    
    const guild = role.guild;
    const guildId = guild.id;
    
    // Prevenir procesamiento duplicado
    if (antiraidHelper.isEventProcessed(guildId, 'roleDelete', role.id)) {
      return;
    }
    
    try {
      // Obtener configuración del módulo
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'roledelete']
      );
      
      if (!config) return;
      
      // Obtener audit log con el helper
      const auditEntry = await antiraidHelper.getAuditLog(guild, {
        type: AuditLogEvent.RoleDelete,
        targetId: role.id
      });
      
      if (!auditEntry) {
        console.warn(`[AntiRaid] No se encontró audit log para eliminación de rol ${role.name}`);
        return;
      }
      
      const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) return;
      
      // Verificar permisos con el helper
      const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, config);
      
      if (permCheck.allowed) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Eliminación no autorizada de rol: ${role.name}`;
      
      // Aplicar sanción con el helper
      const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
      
      // Enviar log con el helper (previene spam)
      await antiraidHelper.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'role_delete_blocked',
        details: {
          role_name: role.name,
          role_color: role.hexColor,
          role_position: role.position,
          role_id: role.id,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en BD con el helper
      await antiraidHelper.createDatabaseLog(
        client,
        guildId,
        executor.id,
        'role_delete_blocked',
        role.id,
        {
          role_name: role.name,
          role_color: role.hexColor,
          role_position: role.position,
          sanction: config.sanction,
          sanction_success: sanctionResult.success
        }
      );
      
    } catch (error) {
      console.error('[AntiRaid] Error en roleDelete:', error);
    }
  }
};