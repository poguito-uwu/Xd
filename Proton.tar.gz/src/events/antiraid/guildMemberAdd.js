const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    if (!member.guild) return;
    
    const guild = member.guild;
    const guildId = guild.id;
    const user = member.user;
    
    try {
      // ==================== PROTECCIÓN ANTI-BOTS ====================
      
      if (user.bot) {
        // Obtener configuración del módulo anti-bots
        const [botConfig] = await client.db.query(
          'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
          [guildId, 'bot']
        );
        
        if (botConfig) {
          // Prevenir procesamiento duplicado
          if (antiraidHelper.isEventProcessed(guildId, 'botAdd', user.id)) {
            return;
          }
          
          // Obtener quien añadió el bot
          const auditEntry = await antiraidHelper.getAuditLog(guild, {
            type: AuditLogEvent.BotAdd,
            targetId: user.id
          });
          
          if (auditEntry) {
            const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
            
            if (executor) {
              // Verificar permisos
              const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, botConfig);
              
              if (!permCheck.allowed) {
                const raison = `Anti-Raid | Bot añadido sin autorización: ${user.tag}`;
                
                // Expulsar el bot
                let botKicked = false;
                try {
                  await member.kick(raison);
                  botKicked = true;
                } catch (error) {
                  console.error(`[AntiRaid] Error expulsando bot:`, error.message);
                }
                
                // Aplicar sanción al que lo añadió
                const sanctionResult = await antiraidHelper.applySanction(executor, botConfig.sanction, raison);
                
                // Enviar log
                await antiraidHelper.sendLog(client, guildId, {
                  type: 'antiraid',
                  user: executor.user,
                  action: 'bot_add_blocked',
                  details: {
                    bot_name: user.tag,
                    bot_id: user.id,
                    bot_kicked: botKicked,
                    sanction: botConfig.sanction,
                    sanction_success: sanctionResult.success,
                    sanction_error: sanctionResult.error
                  }
                });
                
                // Registrar en BD
                await antiraidHelper.createDatabaseLog(
                  client,
                  guildId,
                  executor.id,
                  'bot_add_blocked',
                  user.id,
                  {
                    bot_name: user.tag,
                    bot_kicked: botKicked,
                    sanction: botConfig.sanction,
                    sanction_success: sanctionResult.success
                  }
                );
                
                return; // Ya procesamos, no continuar
              }
            }
          }
        }
      }
      
      // ==================== PROTECCIÓN ANTI-ALT ACCOUNTS ====================
      
      if (!user.bot) {
        // Obtener configuración de anti-alts (si existe)
        const [altConfig] = await client.db.query(
          'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
          [guildId, 'antialt']
        );
        
        if (altConfig) {
          // Prevenir procesamiento duplicado
          if (antiraidHelper.isEventProcessed(guildId, 'altCheck', user.id)) {
            return;
          }
          
          // Verificar edad de la cuenta
          const accountAge = Date.now() - user.createdTimestamp;
          const minAge = altConfig.custom_settings?.min_account_age || 7 * 24 * 60 * 60 * 1000; // 7 días por defecto
          
          if (accountAge < minAge) {
            const raison = `Anti-Raid | Cuenta muy nueva (${Math.floor(accountAge / (24 * 60 * 60 * 1000))} días)`;
            
            // Expulsar cuenta nueva
            let kicked = false;
            try {
              await member.kick(raison);
              kicked = true;
            } catch (error) {
              console.error(`[AntiRaid] Error expulsando cuenta nueva:`, error.message);
            }
            
            // Enviar log
            await antiraidHelper.sendLog(client, guildId, {
              type: 'antiraid',
              user: user,
              action: 'alt_account_blocked',
              details: {
                user_name: user.tag,
                user_id: user.id,
                account_age_days: Math.floor(accountAge / (24 * 60 * 60 * 1000)),
                min_age_days: Math.floor(minAge / (24 * 60 * 60 * 1000)),
                kicked: kicked,
                sanction: 'kick',
                sanction_success: kicked
              }
            });
            
            // Registrar en BD
            await antiraidHelper.createDatabaseLog(
              client,
              guildId,
              user.id,
              'alt_account_blocked',
              user.id,
              {
                user_name: user.tag,
                account_age_days: Math.floor(accountAge / (24 * 60 * 60 * 1000)),
                kicked: kicked
              }
            );
          }
        }
      }
      
    } catch (error) {
      console.error('[AntiRaid] Error en guildMemberAdd:', error);
    }
  }
};