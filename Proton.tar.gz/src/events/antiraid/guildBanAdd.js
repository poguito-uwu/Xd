const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'guildBanAdd',
  async execute(ban, client) {
    if (!ban.guild) return;
    
    const guild = ban.guild;
    const guildId = guild.id;
    const bannedUser = ban.user;
    
    // Prevenir procesamiento duplicado
    if (antiraidHelper.isEventProcessed(guildId, 'guildBanAdd', bannedUser.id)) {
      return;
    }
    
    try {
      // Obtener configuración del módulo
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'ban']
      );
      
      if (!config) return;
      
      // Obtener audit log con el helper
      const auditEntry = await antiraidHelper.getAuditLog(guild, {
        type: AuditLogEvent.MemberBanAdd,
        targetId: bannedUser.id
      });
      
      if (!auditEntry) {
        console.warn(`[AntiRaid] No se encontró audit log para ban de ${bannedUser.tag}`);
        return;
      }
      
      const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) return;
      
      // Verificar permisos con el helper
      const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, config);
      
      if (permCheck.allowed) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Ban no autorizado de usuario: ${bannedUser.tag}`;
      
      // Intentar desbanear al usuario
      let unbanned = false;
      try {
        await guild.bans.remove(bannedUser.id, raison);
        unbanned = true;
      } catch (error) {
        console.error(`[AntiRaid] Error desbaneando usuario:`, error.message);
      }
      
      // Aplicar sanción con el helper
      const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
      
      // Enviar log con el helper (previene spam)
      await antiraidHelper.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'ban_blocked',
        details: {
          banned_user: bannedUser.tag,
          banned_user_id: bannedUser.id,
          unbanned: unbanned,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en BD con el helper
      await antiraidHelper.createDatabaseLog(
        client,
        guildId,
        executor.id,
        'ban_blocked',
        bannedUser.id,
        {
          banned_user: bannedUser.tag,
          unbanned: unbanned,
          sanction: config.sanction,
          sanction_success: sanctionResult.success
        }
      );
      
    } catch (error) {
      console.error('[AntiRaid] Error en guildBanAdd:', error);
    }
  }
};