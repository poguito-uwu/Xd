const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'roleUpdate',
  async execute(oldRole, newRole, client) {
    if (!newRole.guild) return;
    
    const guild = newRole.guild;
    const guildId = guild.id;
    
    // Prevenir procesamiento duplicado
    if (antiraidHelper.isEventProcessed(guildId, 'roleUpdate', newRole.id)) {
      return;
    }
    
    try {
      // Obtener configuración del módulo
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'roleedit']
      );
      
      if (!config) return;
      
      // Obtener audit log con el helper
      const auditEntry = await antiraidHelper.getAuditLog(guild, {
        type: AuditLogEvent.RoleUpdate,
        targetId: newRole.id
      });
      
      if (!auditEntry) {
        console.warn(`[AntiRaid] No se encontró audit log para edición de rol ${newRole.name}`);
        return;
      }
      
      const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) return;
      
      // Verificar permisos con el helper
      const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, config);
      
      if (permCheck.allowed) return;
      
      // Detectar cambios peligrosos
      const changes = [];
      const dangerousChanges = [];
      
      // Verificar cambios de permisos peligrosos
      const dangerousPerms = [
        'Administrator',
        'ManageGuild',
        'ManageRoles',
        'ManageChannels',
        'ManageWebhooks',
        'BanMembers',
        'KickMembers'
      ];
      
      for (const perm of dangerousPerms) {
        const oldHas = oldRole.permissions.has(perm);
        const newHas = newRole.permissions.has(perm);
        
        if (!oldHas && newHas) {
          dangerousChanges.push(`+${perm}`);
        }
      }
      
      if (oldRole.name !== newRole.name) {
        changes.push(`Nombre: ${oldRole.name} → ${newRole.name}`);
      }
      
      if (oldRole.color !== newRole.color) {
        changes.push(`Color: ${oldRole.hexColor} → ${newRole.hexColor}`);
      }
      
      if (oldRole.hoist !== newRole.hoist) {
        changes.push(`Hoist: ${oldRole.hoist} → ${newRole.hoist}`);
      }
      
      if (oldRole.mentionable !== newRole.mentionable) {
        changes.push(`Mencionable: ${oldRole.mentionable} → ${newRole.mentionable}`);
      }
      
      // Solo actuar si hubo cambios peligrosos
      if (dangerousChanges.length === 0 && changes.length === 0) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Edición no autorizada de rol: ${newRole.name}`;
      
      // Intentar revertir cambios
      let reverted = false;
      try {
        await newRole.edit({
          name: oldRole.name,
          color: oldRole.color,
          hoist: oldRole.hoist,
          permissions: oldRole.permissions,
          mentionable: oldRole.mentionable,
          reason: raison
        });
        reverted = true;
      } catch (error) {
        console.error(`[AntiRaid] Error revirtiendo cambios de rol:`, error.message);
      }
      
      // Aplicar sanción con el helper
      const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
      
      // Enviar log con el helper (previene spam)
      await antiraidHelper.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'role_update_blocked',
        details: {
          role_name: newRole.name,
          changes: changes.join(', '),
          dangerous_changes: dangerousChanges.join(', '),
          reverted: reverted,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en BD con el helper
      await antiraidHelper.createDatabaseLog(
        client,
        guildId,
        executor.id,
        'role_update_blocked',
        newRole.id,
        {
          role_name: newRole.name,
          changes: changes,
          dangerous_changes: dangerousChanges,
          reverted: reverted,
          sanction: config.sanction,
          sanction_success: sanctionResult.success
        }
      );
      
    } catch (error) {
      console.error('[AntiRaid] Error en roleUpdate:', error);
    }
  }
};