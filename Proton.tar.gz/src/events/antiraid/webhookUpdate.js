const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'webhookUpdate',
  async execute(channel, client) {
    if (!channel.guild) return;
    
    const guild = channel.guild;
    const guildId = guild.id;
    
    try {
      // Obtener configuración del módulo webhook
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'webhook']
      );
      
      if (!config) return;
      
      // Obtener webhooks del canal
      const webhooks = await channel.fetchWebhooks().catch(() => null);
      if (!webhooks || webhooks.size === 0) return;
      
      // Obtener audit logs de webhooks
      const auditLogs = await guild.fetchAuditLogs({
        limit: 5,
        type: AuditLogEvent.WebhookCreate
      }).catch(() => null);
      
      if (!auditLogs) return;
      
      // Procesar cada webhook nuevo
      for (const webhook of webhooks.values()) {
        // Prevenir procesamiento duplicado
        if (antiraidHelper.isEventProcessed(guildId, 'webhookCreate', webhook.id)) {
          continue;
        }
        
        // Buscar el audit log de este webhook
        const auditEntry = auditLogs.entries.find(entry => 
          entry.target?.id === webhook.id &&
          Date.now() - entry.createdTimestamp < 10000 // Últimos 10 segundos
        );
        
        if (!auditEntry) continue;
        
        const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
        if (!executor) continue;
        
        // Verificar permisos con el helper
        const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, config);
        
        if (permCheck.allowed) continue;
        
        // Aplicar protección
        const raison = `Anti-Raid | Webhook creado sin autorización: ${webhook.name}`;
        
        // Eliminar el webhook
        let webhookDeleted = false;
        try {
          await webhook.delete(raison);
          webhookDeleted = true;
        } catch (error) {
          console.error(`[AntiRaid] Error eliminando webhook:`, error.message);
        }
        
        // Aplicar sanción con el helper
        const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
        
        // Enviar log con el helper (previene spam)
        await antiraidHelper.sendLog(client, guildId, {
          type: 'antiraid',
          user: executor.user,
          action: 'webhook_create_blocked',
          details: {
            webhook_name: webhook.name,
            webhook_id: webhook.id,
            channel_name: channel.name,
            channel_id: channel.id,
            webhook_deleted: webhookDeleted,
            sanction: config.sanction,
            sanction_success: sanctionResult.success,
            sanction_error: sanctionResult.error
          }
        });
        
        // Registrar en BD con el helper
        await antiraidHelper.createDatabaseLog(
          client,
          guildId,
          executor.id,
          'webhook_create_blocked',
          webhook.id,
          {
            webhook_name: webhook.name,
            channel_name: channel.name,
            webhook_deleted: webhookDeleted,
            sanction: config.sanction,
            sanction_success: sanctionResult.success
          }
        );
      }
      
    } catch (error) {
      console.error('[AntiRaid] Error en webhookUpdate:', error);
    }
  }
};