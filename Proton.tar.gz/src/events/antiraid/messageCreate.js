const antiraidHelper = require('../../utils/antiraidHelper');

// Caché para detección de spam
const messageCache = new Map();
const SPAM_THRESHOLD = 5; // mensajes
const SPAM_WINDOW = 5000; // 5 segundos
const MENTION_THRESHOLD = 5; // menciones

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    // Ignorar bots y mensajes sin guild
    if (!message.guild || message.author.bot) return;
    
    const guild = message.guild;
    const guildId = guild.id;
    const user = message.author;
    const member = message.member;
    
    if (!member) return;
    
    try {
      // ==================== ANTI-SPAM ====================
      
      const [spamConfig] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'spam']
      );
      
      if (spamConfig) {
        // Verificar permisos
        const permCheck = await antiraidHelper.checkPermissions(client, guild, member, spamConfig);
        
        if (!permCheck.allowed) {
          // Obtener mensajes recientes del usuario
          const userKey = `${guildId}-${user.id}`;
          const now = Date.now();
          
          if (!messageCache.has(userKey)) {
            messageCache.set(userKey, []);
          }
          
          const userMessages = messageCache.get(userKey);
          
          // Limpiar mensajes antiguos
          const recentMessages = userMessages.filter(timestamp => now - timestamp < SPAM_WINDOW);
          recentMessages.push(now);
          messageCache.set(userKey, recentMessages);
          
          // Limpiar cache después de 1 minuto
          setTimeout(() => {
            if (messageCache.has(userKey)) {
              const messages = messageCache.get(userKey);
              if (messages.length === 0 || now - messages[messages.length - 1] > 60000) {
                messageCache.delete(userKey);
              }
            }
          }, 60000);
          
          // Detectar spam
          if (recentMessages.length >= SPAM_THRESHOLD) {
            // Prevenir procesamiento duplicado
            if (antiraidHelper.isEventProcessed(guildId, 'spam', `${user.id}-${now}`)) {
              return;
            }
            
            const raison = `Anti-Raid | Spam detectado (${recentMessages.length} mensajes en ${SPAM_WINDOW/1000}s)`;
            
            // Eliminar mensajes del usuario
            let messagesDeleted = 0;
            try {
              const fetched = await message.channel.messages.fetch({ limit: 50 });
              const userMessages = fetched.filter(m => 
                m.author.id === user.id && 
                Date.now() - m.createdTimestamp < SPAM_WINDOW
              );
              
              await message.channel.bulkDelete(userMessages, true);
              messagesDeleted = userMessages.size;
            } catch (error) {
              console.error('[AntiRaid] Error eliminando mensajes de spam:', error.message);
            }
            
            // Aplicar sanción
            const sanctionResult = await antiraidHelper.applySanction(member, spamConfig.sanction, raison);
            
            // Enviar log
            await antiraidHelper.sendLog(client, guildId, {
              type: 'antiraid',
              user: user,
              action: 'spam_detected',
              details: {
                user_name: user.tag,
                messages_count: recentMessages.length,
                messages_deleted: messagesDeleted,
                channel_name: message.channel.name,
                sanction: spamConfig.sanction,
                sanction_success: sanctionResult.success,
                sanction_error: sanctionResult.error
              }
            });
            
            // Registrar en BD
            await antiraidHelper.createDatabaseLog(
              client,
              guildId,
              user.id,
              'spam_detected',
              message.channel.id,
              {
                messages_count: recentMessages.length,
                messages_deleted: messagesDeleted,
                sanction: spamConfig.sanction,
                sanction_success: sanctionResult.success
              }
            );
            
            // Limpiar cache del usuario
            messageCache.delete(userKey);
            
            return; // Ya procesamos, no continuar
          }
        }
      }
      
      // ==================== ANTI-PUBLICIDAD ====================
      
      const [pubConfig] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'pub']
      );
      
      if (pubConfig) {
        // Verificar permisos
        const permCheck = await antiraidHelper.checkPermissions(client, guild, member, pubConfig);
        
        if (!permCheck.allowed) {
          // Detectar links de Discord
          const discordInviteRegex = /(discord\.gg|discord\.com\/invite|discordapp\.com\/invite)\/[a-zA-Z0-9]+/gi;
          const matches = message.content.match(discordInviteRegex);
          
          if (matches && matches.length > 0) {
            // Prevenir procesamiento duplicado
            if (antiraidHelper.isEventProcessed(guildId, 'publicidad', message.id)) {
              return;
            }
            
            const raison = `Anti-Raid | Publicidad detectada (${matches.length} invite(s))`;
            
            // Eliminar mensaje
            let messageDeleted = false;
            try {
              await message.delete();
              messageDeleted = true;
            } catch (error) {
              console.error('[AntiRaid] Error eliminando mensaje de publicidad:', error.message);
            }
            
            // Aplicar sanción
            const sanctionResult = await antiraidHelper.applySanction(member, pubConfig.sanction, raison);
            
            // Enviar log
            await antiraidHelper.sendLog(client, guildId, {
              type: 'antiraid',
              user: user,
              action: 'advertising_detected',
              details: {
                user_name: user.tag,
                invites_found: matches.length,
                invites_list: matches.join(', '),
                message_deleted: messageDeleted,
                channel_name: message.channel.name,
                sanction: pubConfig.sanction,
                sanction_success: sanctionResult.success,
                sanction_error: sanctionResult.error
              }
            });
            
            // Registrar en BD
            await antiraidHelper.createDatabaseLog(
              client,
              guildId,
              user.id,
              'advertising_detected',
              message.id,
              {
                invites_found: matches.length,
                message_deleted: messageDeleted,
                sanction: pubConfig.sanction,
                sanction_success: sanctionResult.success
              }
            );
            
            return; // Ya procesamos, no continuar
          }
        }
      }
      
      // ==================== ANTI-PING MASIVO ====================
      
      const [pingConfig] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'ping']
      );
      
      if (pingConfig) {
        // Verificar permisos
        const permCheck = await antiraidHelper.checkPermissions(client, guild, member, pingConfig);
        
        if (!permCheck.allowed) {
          // Contar menciones
          const mentionsCount = message.mentions.users.size + message.mentions.roles.size;
          const hasEveryoneMention = message.mentions.everyone;
          
          if (mentionsCount >= MENTION_THRESHOLD || hasEveryoneMention) {
            // Prevenir procesamiento duplicado
            if (antiraidHelper.isEventProcessed(guildId, 'pingMasivo', message.id)) {
              return;
            }
            
            const raison = hasEveryoneMention 
              ? 'Anti-Raid | Mención @everyone/@here detectada'
              : `Anti-Raid | Ping masivo detectado (${mentionsCount} menciones)`;
            
            // Eliminar mensaje
            let messageDeleted = false;
            try {
              await message.delete();
              messageDeleted = true;
            } catch (error) {
              console.error('[AntiRaid] Error eliminando mensaje de ping masivo:', error.message);
            }
            
            // Aplicar sanción
            const sanctionResult = await antiraidHelper.applySanction(member, pingConfig.sanction, raison);
            
            // Enviar log
            await antiraidHelper.sendLog(client, guildId, {
              type: 'antiraid',
              user: user,
              action: 'mass_ping_detected',
              details: {
                user_name: user.tag,
                mentions_count: mentionsCount,
                everyone_mention: hasEveryoneMention,
                message_deleted: messageDeleted,
                channel_name: message.channel.name,
                sanction: pingConfig.sanction,
                sanction_success: sanctionResult.success,
                sanction_error: sanctionResult.error
              }
            });
            
            // Registrar en BD
            await antiraidHelper.createDatabaseLog(
              client,
              guildId,
              user.id,
              'mass_ping_detected',
              message.id,
              {
                mentions_count: mentionsCount,
                everyone_mention: hasEveryoneMention,
                message_deleted: messageDeleted,
                sanction: pingConfig.sanction,
                sanction_success: sanctionResult.success
              }
            );
          }
        }
      }
      
    } catch (error) {
      console.error('[AntiRaid] Error en messageCreate:', error);
    }
  }
};