const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member, client) {
    if (!member.guild) return;
    
    const guild = member.guild;
    const guildId = guild.id;
    const user = member.user;
    
    // Prevenir procesamiento duplicado
    if (antiraidHelper.isEventProcessed(guildId, 'guildMemberRemove', user.id)) {
      return;
    }
    
    try {
      // Obtener configuración del módulo kick
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'kick']
      );
      
      if (!config) return;
      
      // Esperar un poco más para audit logs de kick
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Obtener audit log con el helper
      const auditEntry = await antiraidHelper.getAuditLog(guild, {
        type: AuditLogEvent.MemberKick,
        targetId: user.id
      });
      
      // Si no hay audit log, probablemente el usuario se fue voluntariamente
      if (!auditEntry) {
        return;
      }
      
      const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) return;
      
      // Verificar permisos con el helper
      const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, config);
      
      if (permCheck.allowed) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Kick no autorizado de usuario: ${user.tag}`;
      
      // Aplicar sanción con el helper
      const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
      
      // Enviar log con el helper (previene spam)
      await antiraidHelper.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'kick_blocked',
        details: {
          kicked_user: user.tag,
          kicked_user_id: user.id,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en BD con el helper
      await antiraidHelper.createDatabaseLog(
        client,
        guildId,
        executor.id,
        'kick_blocked',
        user.id,
        {
          kicked_user: user.tag,
          sanction: config.sanction,
          sanction_success: sanctionResult.success
        }
      );
      
    } catch (error) {
      console.error('[AntiRaid] Error en guildMemberRemove:', error);
    }
  }
};