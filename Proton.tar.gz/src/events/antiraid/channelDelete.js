const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'channelDelete',
  async execute(channel, client) {
    if (!channel.guild) return;
    
    const guild = channel.guild;
    const guildId = guild.id;
    
    // Prevenir procesamiento duplicado
    if (antiraidHelper.isEventProcessed(guildId, 'channelDelete', channel.id)) {
      return;
    }
    
    try {
      // Obtener configuración del módulo
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'channeldelete']
      );
      
      if (!config) return;
      
      // Obtener audit log con el helper
      const auditEntry = await antiraidHelper.getAuditLog(guild, {
        type: AuditLogEvent.ChannelDelete,
        targetId: channel.id
      });
      
      if (!auditEntry) {
        console.warn(`[AntiRaid] No se encontró audit log para eliminación de canal ${channel.name}`);
        return;
      }
      
      const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) return;
      
      // Verificar permisos con el helper
      const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, config);
      
      if (permCheck.allowed) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Eliminación no autorizada de canal: ${channel.name}`;
      
      // Aplicar sanción con el helper
      const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
      
      // Enviar log con el helper (previene spam)
      await antiraidHelper.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'channel_delete_blocked',
        details: {
          channel_name: channel.name,
          channel_type: channel.type,
          channel_id: channel.id,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en BD con el helper (previene duplicados)
      await antiraidHelper.createDatabaseLog(
        client,
        guildId,
        executor.id,
        'channel_delete_blocked',
        channel.id,
        {
          channel_name: channel.name,
          channel_type: channel.type,
          sanction: config.sanction,
          sanction_success: sanctionResult.success
        }
      );
      
    } catch (error) {
      console.error('[AntiRaid] Error en channelDelete:', error);
    }
  }
};