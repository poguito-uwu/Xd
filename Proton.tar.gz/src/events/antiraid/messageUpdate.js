module.exports = {
  name: 'messageUpdate',
  async execute(oldMessage, newMessage, client) {
    if (!newMessage.guild || newMessage.author.bot) return;
    
    const guild = newMessage.guild;
    const guildId = guild.id;
    const userId = newMessage.author.id;
    
    try {
      // Verificar anti-pub en mensaje editado
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'pub']
      );
      
      if (!config) return;
      
      // Detectar invitaciones Discord en el nuevo mensaje
      const discordInviteRegex = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li|com\/invite)|discordapp\.com\/invite)\/.+/gi;
      const hadInvite = discordInviteRegex.test(oldMessage.content);
      const hasInvite = discordInviteRegex.test(newMessage.content);
      
      // Solo actuar si el nuevo mensaje tiene invitación y el anterior no
      if (!hadInvite && hasInvite) {
        // Verificar whitelist
        const [whitelist] = await client.db.query(
          'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
          [guildId, userId]
        );
        
        if (whitelist) return;
        
        const raison = `Anti-Raid | Publicidad añadida en edición`;
        
        // Eliminar mensaje editado
        try {
          await newMessage.delete();
        } catch (error) {
          console.error('Error eliminando mensaje editado:', error);
        }
        
        // Enviar advertencia
        try {
          const warning = await newMessage.channel.send({
            content: `<@${userId}>`,
            embeds: [client.embeds.warning(
              'Publicidad detectada',
              'No está permitido añadir invitaciones Discord al editar mensajes.'
            )]
          });
          
          setTimeout(() => warning.delete().catch(() => {}), 5000);
        } catch (error) {
          // Ignorar error de advertencia
        }
        
        // Enviar log
        const server = await client.db.getServer(guildId);
        
        if (server?.logs_channel) {
          const logChannel = guild.channels.cache.get(server.logs_channel);
          
          if (logChannel) {
            const embed = client.embeds.info(
              'Publicidad en edición bloqueada',
              `
**Usuario:** <@${userId}> (\`${newMessage.author.tag}\`)
**Canal:** <#${newMessage.channel.id}>
**Acción:** Mensaje eliminado
**Razón:** ${raison}
                            `
            );
            
            await logChannel.send({ embeds: [embed] }).catch(() => {});
          }
        }
        
        // Registrar en base de datos
        await client.db.createLog(guildId, userId, 'advertising_edit_blocked', null, {
          channel_id: newMessage.channel.id,
          message_id: newMessage.id
        });
      }
      
    } catch (error) {
      console.error('Error en messageUpdate:', error);
    }
  }
};