const { AuditLogEvent } = require('discord.js');
const antiraidHelper = require('../../utils/antiraidHelper');

module.exports = {
  name: 'guildMemberUpdate',
  async execute(oldMember, newMember, client) {
    if (!newMember.guild) return;
    
    const guild = newMember.guild;
    const guildId = guild.id;
    
    // Prevenir procesamiento duplicado
    if (antiraidHelper.isEventProcessed(guildId, 'guildMemberUpdate', newMember.id)) {
      return;
    }
    
    try {
      // Obtener configuración del módulo roleadd
      const [config] = await client.db.query(
        'SELECT * FROM antiraid_config WHERE server_id = ? AND module = ? AND enabled = TRUE',
        [guildId, 'roleadd']
      );
      
      if (!config) return;
      
      // Detectar roles añadidos
      const addedRoles = newMember.roles.cache.filter(
        role => !oldMember.roles.cache.has(role.id)
      );
      
      if (addedRoles.size === 0) return;
      
      // Verificar si alguno de los roles añadidos es peligroso
      const dangerousPerms = [
        'Administrator',
        'ManageGuild',
        'ManageRoles',
        'ManageChannels',
        'ManageWebhooks',
        'BanMembers',
        'KickMembers'
      ];
      
      const dangerousRoles = addedRoles.filter(role => 
        dangerousPerms.some(perm => role.permissions.has(perm))
      );
      
      if (dangerousRoles.size === 0) return;
      
      // Obtener audit log con el helper
      const auditEntry = await antiraidHelper.getAuditLog(guild, {
        type: AuditLogEvent.MemberRoleUpdate,
        targetId: newMember.id
      });
      
      if (!auditEntry) {
        console.warn(`[AntiRaid] No se encontró audit log para roleAdd de ${newMember.user.tag}`);
        return;
      }
      
      const executor = await guild.members.fetch(auditEntry.executor.id).catch(() => null);
      if (!executor) return;
      
      // Verificar permisos con el helper
      const permCheck = await antiraidHelper.checkPermissions(client, guild, executor, config);
      
      if (permCheck.allowed) return;
      
      // Aplicar protección
      const raison = `Anti-Raid | Roles peligrosos añadidos sin autorización`;
      
      // Remover los roles peligrosos
      let rolesRemoved = false;
      try {
        await newMember.roles.remove(dangerousRoles, raison);
        rolesRemoved = true;
      } catch (error) {
        console.error(`[AntiRaid] Error removiendo roles peligrosos:`, error.message);
      }
      
      // Aplicar sanción con el helper
      const sanctionResult = await antiraidHelper.applySanction(executor, config.sanction, raison);
      
      // Listar roles añadidos
      const rolesList = dangerousRoles.map(r => r.name).join(', ');
      const permsList = [];
      
      dangerousRoles.forEach(role => {
        dangerousPerms.forEach(perm => {
          if (role.permissions.has(perm)) {
            permsList.push(perm);
          }
        });
      });
      
      // Enviar log con el helper (previene spam)
      await antiraidHelper.sendLog(client, guildId, {
        type: 'antiraid',
        user: executor.user,
        action: 'dangerous_role_add_blocked',
        details: {
          target_user: newMember.user.tag,
          target_user_id: newMember.id,
          roles_added: rolesList,
          dangerous_perms: [...new Set(permsList)].join(', '),
          roles_removed: rolesRemoved,
          sanction: config.sanction,
          sanction_success: sanctionResult.success,
          sanction_error: sanctionResult.error
        }
      });
      
      // Registrar en BD con el helper
      await antiraidHelper.createDatabaseLog(
        client,
        guildId,
        executor.id,
        'dangerous_role_add_blocked',
        newMember.id,
        {
          target_user: newMember.user.tag,
          roles_added: rolesList,
          dangerous_perms: [...new Set(permsList)],
          roles_removed: rolesRemoved,
          sanction: config.sanction,
          sanction_success: sanctionResult.success
        }
      );
      
    } catch (error) {
      console.error('[AntiRaid] Error en guildMemberUpdate:', error);
    }
  }
};