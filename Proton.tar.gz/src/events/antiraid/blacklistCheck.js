module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    // Verificar si el usuario está en la blacklist global
    try {
      const [blacklist] = await client.db.query(
        'SELECT * FROM blacklist WHERE user_id = ?',
        [member.id]
      );
      
      if (blacklist) {
        const guild = member.guild;
        const embeds = client.embeds;
        
        // Intentar banear al usuario
        try {
          await member.ban({
            reason: `Blacklist Global: ${blacklist.reason} | ID: ${blacklist.id}`
          });
          
          // Enviar log al canal de logs si existe
          const serverConfig = await client.getServerConfig(guild.id);
          
          if (serverConfig?.logs_channel) {
            const logChannel = guild.channels.cache.get(serverConfig.logs_channel);
            
            if (logChannel) {
              const addedBy = await client.users.fetch(blacklist.added_by).catch(() => ({ tag: 'Usuario desconocido' }));
              
              const embed = embeds.blacklistEmbed(
                member.user,
                addedBy,
                blacklist.reason,
                blacklist.evidence
              );
              
              await logChannel.send({
                content: `🚨 **Usuario blacklisteado detectado y baneado automáticamente**`,
                embeds: [embed]
              }).catch(() => {});
            }
          }
          
          console.log(`✅ Usuario blacklisteado baneado: ${member.user.tag} en ${guild.name}`);
          
        } catch (banError) {
          console.error(`❌ Error baneando usuario blacklisteado en ${guild.name}:`, banError.message);
          
          // Si no se puede banear, intentar expulsar
          try {
            await member.kick(`Blacklist Global (ban falló): ${blacklist.reason}`);
            console.log(`⚠️ Usuario blacklisteado expulsado: ${member.user.tag} en ${guild.name}`);
          } catch (kickError) {
            console.error(`❌ Error expulsando usuario blacklisteado en ${guild.name}:`, kickError.message);
          }
        }
      }
    } catch (error) {
      console.error('Error verificando blacklist:', error);
    }
  }
};