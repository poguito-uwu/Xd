// Evento ready - CORREGIDO
module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(`✅ ${client.user.tag} está online en ${client.guilds.cache.size} servidores`);
        
        // Verificar servidores (sin usar "cliente")
        console.log('🔄 Verificando configuración de servidores...');
        
        let verified = 0;
        let errors = 0;
        
        for (const guild of client.guilds.cache.values()) {
            try {
                // Usar client.db (NO cliente.db)
                if (client.db && client.db.getServer) {
                    const server = await client.db.getServer(guild.id);
                    
                    if (!server) {
                        // Crear configuración si no existe
                        await client.db.query(
                            'INSERT INTO servers (id, name, owner_id) VALUES (?, ?, ?)',
                            [guild.id, guild.name, guild.ownerId]
                        );
                        console.log(`✅ Configuración creada para: ${guild.name}`);
                    }
                    verified++;
                }
            } catch (error) {
                console.error(`❌ Error verificando servidor ${guild.name}:`, error.message);
                errors++;
            }
        }
        
        console.log(`📊 Verificación completada: ${verified} servidores OK, ${errors} errores`);
    }
};