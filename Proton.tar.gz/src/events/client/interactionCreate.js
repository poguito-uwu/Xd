const { InteractionType, ComponentType } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        // Comandos slash
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) return;
            
            try {
                await command.execute(interaction, client);
                
                // CORREGIDO: createLog con parámetros correctos
                if (client.db && client.db.createLog) {
                    await client.db.createLog(
                        interaction.guild?.id,
                        interaction.user.id,
                        'command_used',
                        null,
                        { 
                            command: interaction.commandName,
                            channel: interaction.channel?.id,
                            guild: interaction.guild?.name
                        }
                    );
                }
            } catch (error) {
                console.error(`Error en comando ${interaction.commandName}:`, error);
                const embed = client.embeds.error('Error', 'Ocurrió un error al ejecutar el comando.');
                
                // CORREGIDO: ephemeral obsoleto reemplazado por flags: 64
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ embeds: [embed], flags: 64 });
                } else {
                    await interaction.reply({ embeds: [embed], flags: 64 });
                }
            }
        }
        
        // Autocomplete
        else if (interaction.isAutocomplete()) {
            const command = client.commands.get(interaction.commandName);
            if (!command || !command.autocomplete) return;
            
            try {
                await command.autocomplete(interaction);
            } catch (error) {
                console.error('Error en autocomplete:', error);
            }
        }
        
        // Menús desplegables
        else if (interaction.isStringSelectMenu()) {
            await this.handleSelectMenu(interaction, client);
        }
        
        // Botones
        else if (interaction.isButton()) {
            await this.handleButton(interaction, client);
        }
        
        // Modal submits
        else if (interaction.isModalSubmit()) {
            await this.handleModal(interaction, client);
        }
    },
    
    async handleSelectMenu(interaction, client) {
        const { customId, values, guildId, user } = interaction;
        
        try {
            await interaction.deferUpdate();
            
            // Setup manual - Selección de módulos
            if (customId === 'setup_modules') {
                // Guardar selección temporal
                if (!client.tempCache) client.tempCache = new Map();
                client.tempCache.set(`setup_${user.id}_modules`, values);
                await interaction.followUp({
                    content: `✅ ${values.length} módulos seleccionados. Configura sanción y whitelist, luego haz clic en "Aplicar".`,
                    flags: 64
                });
            }
            
            // Setup - Sanción
            else if (customId === 'setup_sanction') {
                if (!client.tempCache) client.tempCache = new Map();
                client.tempCache.set(`setup_${user.id}_sanction`, values[0]);
                await interaction.followUp({
                    content: `✅ Sanción predeterminada: \`${values[0]}\``,
                    flags: 64
                });
            }
            
            // Setup - Whitelist
            else if (customId === 'setup_whitelist') {
                if (!client.tempCache) client.tempCache = new Map();
                client.tempCache.set(`setup_${user.id}_whitelist`, values[0] === 'true');
                await interaction.followUp({
                    content: `✅ Whitelist bypass: \`${values[0] === 'true' ? 'Activado' : 'Desactivado'}\``,
                    flags: 64
                });
            }
            
            // Menú de configuración específica
            else if (customId.startsWith('config_')) {
                await this.handleConfigMenu(interaction, client);
            }
            
        } catch (error) {
            console.error('Error en select menu:', error);
            await interaction.followUp({
                content: '❌ Error al procesar la selección.',
                flags: 64
            });
        }
    },
    
    async handleButton(interaction, client) {
        const { customId, guildId, user, message } = interaction;
        
        try {
            await interaction.deferUpdate();
            
            // Setup - Aplicar configuración
            if (customId === 'setup_apply') {
                if (!client.tempCache) client.tempCache = new Map();
                
                const modules = client.tempCache.get(`setup_${user.id}_modules`) || [];
                const sanction = client.tempCache.get(`setup_${user.id}_sanction`) || 'kick';
                const whitelist = client.tempCache.get(`setup_${user.id}_whitelist`) || false;
                
                if (modules.length === 0) {
                    return interaction.followUp({
                        content: '❌ No hay módulos seleccionados.',
                        flags: 64
                    });
                }
                
                // Verificar que db está disponible
                if (!client.db || !client.db.query) {
                    throw new Error('Base de datos no disponible');
                }
                
                // Aplicar configuración
                for (const module of modules) {
                    await client.db.query(
                        `INSERT INTO antiraid_config (server_id, module, enabled, sanction, whitelist_enabled)
                         VALUES (?, ?, TRUE, ?, ?)
                         ON DUPLICATE KEY UPDATE enabled = TRUE, sanction = ?, whitelist_enabled = ?`,
                        [guildId, module, sanction, whitelist, sanction, whitelist]
                    );
                }
                
                // Limpiar cache
                client.tempCache.delete(`setup_${user.id}_modules`);
                client.tempCache.delete(`setup_${user.id}_sanction`);
                client.tempCache.delete(`setup_${user.id}_whitelist`);
                
                // Actualizar mensaje
                await message.edit({
                    content: null,
                    embeds: [client.embeds.success(
                        'Configuración aplicada',
                        `✅ **${modules.length} módulos** activados con sanción \`${sanction}\` y whitelist bypass \`${whitelist ? 'Activado' : 'Desactivado'}\``
                    )],
                    components: []
                });
                
                // CORREGIDO: createLog con parámetros correctos
                if (client.db && client.db.createLog) {
                    await client.db.createLog(
                        guildId,
                        user.id,
                        'setup_applied',
                        null,
                        {
                            modules: modules,
                            sanction: sanction,
                            whitelist: whitelist
                        }
                    );
                }
            }
            
            // Setup - Cancelar
            else if (customId === 'setup_cancel') {
                if (client.tempCache) {
                    // Limpiar cache
                    client.tempCache.delete(`setup_${user.id}_modules`);
                    client.tempCache.delete(`setup_${user.id}_sanction`);
                    client.tempCache.delete(`setup_${user.id}_whitelist`);
                }
                
                await message.edit({
                    content: null,
                    embeds: [client.embeds.error('Configuración cancelada', '❌ La configuración ha sido cancelada.')],
                    components: []
                });
            }
            
            // Paginación de listas
            else if (customId.startsWith('wl1_') || customId.startsWith('wl2_') ||
                     customId.startsWith('bl1_') || customId.startsWith('bl2_') ||
                     customId.startsWith('owner1_') || customId.startsWith('owner2_')) {
                await this.handlePagination(interaction, client, customId, message);
            }
            
            // Botones de confirmación
            else if (customId.includes('_yes') || customId.includes('_non')) {
                await this.handleConfirmation(interaction, client, customId, message);
            }
            
        } catch (error) {
            console.error('Error en button:', error);
            await interaction.followUp({
                content: '❌ Error al procesar el botón.',
                flags: 64
            });
        }
    },
    
    async handleConfigMenu(interaction, client) {
        // Implementar lógica para menús de configuración específica
        await interaction.followUp({
            content: '⚙️ Configuración actualizada.',
            flags: 64
        });
        
        // Opcional: log de configuración
        if (client.db && client.db.createLog) {
            await client.db.createLog(
                interaction.guild?.id,
                interaction.user.id,
                'config_menu_used',
                null,
                { menu: interaction.customId, values: interaction.values }
            );
        }
    },
    
    async handlePagination(interaction, client, customId, message) {
        // Implementar lógica de paginación para listas
        await interaction.followUp({
            content: '📄 Navegación en desarrollo.',
            flags: 64
        });
    },
    
    async handleConfirmation(interaction, client, customId, message) {
        // Implementar lógica de confirmaciones
        await interaction.followUp({
            content: '✅ Confirmación procesada.',
            flags: 64
        });
    },
    
    async handleModal(interaction, client) {
        // Implementar lógica para modals
        await interaction.reply({
            content: '📝 Modal recibido.',
            flags: 64
        });
        
        // Opcional: log de modal
        if (client.db && client.db.createLog) {
            await client.db.createLog(
                interaction.guild?.id,
                interaction.user.id,
                'modal_submitted',
                null,
                { modal: interaction.customId, fields: interaction.fields }
            );
        }
    }
};