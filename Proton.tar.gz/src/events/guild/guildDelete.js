module.exports = {
  name: 'guildDelete',
  async execute(guild, client) {
    console.log(`➖ Bot removido del servidor: ${guild.name} (${guild.id})`);
    
    try {
      // Enviar notificación a canal de logs del dueño
      const owners = process.env.OWNER_IDS?.split(',') || [];
      
      for (const ownerId of owners) {
        try {
          const owner = await client.users.fetch(ownerId);
          const embed = client.embeds.info(
            'Bot removido de servidor',
            `
**Servidor:** ${guild.name}
**ID:** \`${guild.id}\`
**Miembros:** ${guild.memberCount}
**Fecha:** <t:${Math.floor(Date.now() / 1000)}:F>
                        
**Propietario:** ${guild.ownerId ? `<@${guild.ownerId}>` : 'Desconocido'}
                        `
          );
          
          await owner.send({ embeds: [embed] }).catch(() => {
            console.log(`No se pudo enviar DM al owner ${ownerId}`);
          });
        } catch (error) {
          console.error('Error notificando owner:', error);
        }
      }
      
      // Registrar en base de datos (opcional mantener datos por X tiempo)
      // Aquí podrías marcar el servidor como inactivo en lugar de eliminar
      
    } catch (error) {
      console.error('Error en guildDelete:', error);
    }
  }
};