module.exports = {
  name: 'guildCreate',
  async execute(guild, client) {
    console.log(`➕ Bot añadido al servidor: ${guild.name} (${guild.id})`);
    
    // Crear entrada en la base de datos
    try {
      await client.db.query(
        'INSERT INTO servers (id, name, owner_id) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE name = ?',
        [guild.id, guild.name, guild.ownerId, guild.name]
      );
      
      // Enviar mensaje de bienvenida
      const embeds = client.embeds;
      const welcomeEmbed = embeds.welcomeEmbed();
      
      // Buscar canal de sistema o primer canal text disponible
      let welcomeChannel = guild.systemChannel;
      
      if (!welcomeChannel) {
        const channels = guild.channels.cache
          .filter(ch => ch.isTextBased() && ch.permissionsFor(guild.members.me).has('SendMessages'))
          .sort((a, b) => a.position - b.position);
        
        welcomeChannel = channels.first();
      }
      
      if (welcomeChannel) {
        await welcomeChannel.send({ embeds: [welcomeEmbed] }).catch(console.error);
      }
      
      // Crear rol Proton Guard si no existe
      let botRole = guild.roles.cache.find(r => r.name === 'Proton Guard');
      
      if (!botRole) {
        try {
          botRole = await guild.roles.create({
            name: 'Proton Guard',
            color: '#2c2f33',
            reason: 'Rol necesario para el funcionamiento del bot de protección'
          });
          
          console.log(`✅ Rol Proton Guard creado en ${guild.name}`);
        } catch (error) {
          console.error(`❌ Error creando rol en ${guild.name}:`, error.message);
        }
      }
      
      // Dar el rol al bot si no lo tiene
      const botMember = guild.members.cache.get(client.user.id);
      if (botMember && botRole && !botMember.roles.cache.has(botRole.id)) {
        await botMember.roles.add(botRole).catch(console.error);
      }
      
      // Enviar mensaje al owner
      try {
        const owner = await guild.fetchOwner();
        const dmEmbed = embeds.info(
          '¡Gracias por añadir Proton Guard!',
          `
Hola ${owner.user.username}, gracias por añadir **Proton Guard** a **${guild.name}**.
                    
Para configurar la protección completa, sigue estos pasos:
                    
1. **Mueve el rol "Proton Guard" a la primera posición** en Configuración del Servidor → Roles
2. **Configura el canal de logs** usando </logs:0>
3. **Activa la protección** usando </setup:0>
4. **Verifica la seguridad** usando </check:0>
                    
**Importante:** Para un funcionamiento óptimo, el bot necesita el permiso de **Administrador**.
                    `
        );
        
        await owner.send({ embeds: [dmEmbed] }).catch(() => {
          console.log(`No se pudo enviar DM al owner de ${guild.name}`);
        });
      } catch (error) {
        console.error('Error enviando DM al owner:', error);
      }
      
    } catch (error) {
      console.error('Error en guildCreate:', error);
    }
  }
};