const { EmbedBuilder } = require('discord.js');
const database = require('../database/mysql');

class LogSystem {
  constructor(client) {
    this.client = client;
  }
  
  async sendLog(guildId, data) {
    try {
      // Obtener configuración del servidor
      const server = await database.getServer(guildId);
      
      if (!server || !server.logs_channel) {
        return false;
      }
      
      // Obtener canal de logs
      const guild = this.client.guilds.cache.get(guildId);
      if (!guild) return false;
      
      const logChannel = guild.channels.cache.get(server.logs_channel);
      if (!logChannel) return false;
      
      // Verificar permisos
      const botPermissions = logChannel.permissionsFor(guild.members.me);
      if (!botPermissions.has('SendMessages') || !botPermissions.has('EmbedLinks')) {
        return false;
      }
      
      // Crear embed según el tipo de log
      const embed = this.createLogEmbed(data);
      
      // Enviar log
      await logChannel.send({ embeds: [embed] }).catch(() => false);
      
      return true;
      
    } catch (error) {
      console.error('Error enviando log:', error);
      return false;
    }
  }
  
  createLogEmbed(data) {
    const { type, user, target, action, reason, details, timestamp = Date.now() } = data;
    
    const embed = new EmbedBuilder()
      .setTimestamp(timestamp)
      .setFooter({ text: 'PROTON • Sistema de Logs' });
    
    // Colores según tipo
    const colors = {
      'ban': '#f04747',
      'kick': '#faa61a',
      'mute': '#ffcc4d',
      'warn': '#ffcc4d',
      'antiraid': '#43b581',
      'blacklist': '#ed4245',
      'whitelist': '#43b581',
      'settings': '#7289da',
      'error': '#ed4245',
      'info': '#99aab5'
    };
    
    embed.setColor(colors[type] || '#99aab5');
    
    // Títulos según tipo
    const titles = {
      'ban': '🚨 Usuario Baneado',
      'kick': '👢 Usuario Expulsado',
      'mute': '🔇 Usuario Muteado',
      'warn': '⚠️ Advertencia',
      'antiraid': '🛡️ Anti-Raid Activado',
      'blacklist': '🚫 Blacklist Global',
      'whitelist': '✅ Whitelist Actualizada',
      'settings': '⚙️ Configuración Cambiada',
      'error': '❌ Error del Sistema',
      'info': '📝 Información'
    };
    
    embed.setTitle(titles[type] || '📝 Log del Sistema');
    
    // Construir descripción
    let description = '';
    
    if (user) {
      description += `**Usuario:** <@${user.id}> (\`${user.tag || user.id}\`)\n`;
    }
    
    if (target) {
      description += `**Objetivo:** <@${target.id}> (\`${target.tag || target.id}\`)\n`;
    }
    
    if (action) {
      description += `**Acción:** ${action}\n`;
    }
    
    if (reason) {
      description += `**Razón:** ${reason}\n`;
    }
    
    if (details) {
      if (typeof details === 'object') {
        for (const [key, value] of Object.entries(details)) {
          description += `**${key}:** ${value}\n`;
        }
      } else {
        description += `**Detalles:** ${details}\n`;
      }
    }
    
    embed.setDescription(description);
    
    return embed;
  }
  
  async logAction(guildId, userId, action, targetId = null, details = null) {
    try {
      // Guardar en base de datos
      await database.createLog(guildId, userId, action, targetId, details);
      
      // Enviar a canal de logs si está configurado
      const logData = {
        type: this.getLogType(action),
        user: { id: userId },
        target: targetId ? { id: targetId } : null,
        action: action,
        details: details
      };
      
      await this.sendLog(guildId, logData);
      
      return true;
      
    } catch (error) {
      console.error('Error registrando acción:', error);
      return false;
    }
  }
  
  getLogType(action) {
    const typeMap = {
      'ban': 'ban',
      'unban': 'ban',
      'kick': 'kick',
      'mute': 'mute',
      'unmute': 'mute',
      'warn': 'warn',
      'antiraid': 'antiraid',
      'blacklist': 'blacklist',
      'whitelist': 'whitelist',
      'settings': 'settings',
      'error': 'error'
    };
    
    return typeMap[action] || 'info';
  }
  
  async getRecentLogs(guildId, limit = 50) {
    try {
      const { logs } = await database.getLogs(guildId, limit);
      return logs;
    } catch (error) {
      console.error('Error obteniendo logs:', error);
      return [];
    }
  }
  
  async clearOldLogs(days = 30) {
    try {
      const cutoff = new Date();
      cutoff.setDate(cutoff.getDate() - days);
      
      await database.query(
        'DELETE FROM logs WHERE created_at < ?',
        [cutoff]
      );
      
      console.log(`✅ Logs antiguos eliminados (más de ${days} días)`);
      return true;
      
    } catch (error) {
      console.error('Error eliminando logs antiguos:', error);
      return false;
    }
  }
}

module.exports = LogSystem;