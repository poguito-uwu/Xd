const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

class RB3Embeds {
  constructor(color = '#2c2f33') {
    this.color = color;
  }
  
  // Embed de éxito
  success(title, description) {
    return new EmbedBuilder()
      .setTitle(`<:_:1455005035724275804> ${title}`)
      .setDescription(description)
      .setColor('#43b581')
      .setTimestamp()
      .setFooter({ text: 'PROTON • Sistema de Protección' });
  }
  
  // Embed de error
  error(title, description) {
    return new EmbedBuilder()
      .setTitle(`<:_:1455005004619583551> ${title}`)
      .setDescription(description)
      .setColor('#f04747')
      .setTimestamp()
      .setFooter({ text: 'PROTON • Sistema de Protección' });
  }
  
  // Embed de advertencia
  warning(title, description) {
    return new EmbedBuilder()
      .setTitle(`<a:_:1455009802810822818> ${title}`)
      .setDescription(description)
      .setColor('#faa61a')
      .setTimestamp()
      .setFooter({ text: 'PROTON • Sistema de Protección' });
  }
  
  // Embed de información
  info(title, description) {
    return new EmbedBuilder()
      .setTitle(`<a:informacion:943714176492933200> ${title}`)
      .setDescription(description)
      .setColor('#7289da')
      .setTimestamp()
      .setFooter({ text: 'PROTON • Sistema de Protección' });
  }
  
  // Embed de configuración
  config(title, fields) {
    const embed = new EmbedBuilder()
      .setTitle(`<:config:947090506289119272> ${title}`)
      .setColor(this.color)
      .setTimestamp()
      .setFooter({ text: 'PROTON • Panel de Configuración' });
    
    if (fields) {
      embed.addFields(fields);
    }
    
    return embed;
  }
  
  // Embed de verificación del servidor (CHECK)
  serverCheck(guild, issues, warnings, success) {
    const embed = new EmbedBuilder()
      .setTitle('<:active:1228170269131280546> COMPROBACIÓN DE ERRORES')
      .setColor(this.color)
      //.setThumbnail(guild.iconURL({ dynamic: true }))
      .setFooter({ text: `${guild.name} • PROTON Security Scan` })
      .setTimestamp();
    
    if (issues.length > 0) {
      embed.addFields({
        name: `━━━━━━━━ <:_:1455005004619583551> PROTON • Necesario ━━━━━━━━`,
        value: issues.join('\n')
      });
    }
    
    if (warnings.length > 0) {
      embed.addFields({
        name: `━━━━━━━━ <a:_:1455009802810822818> Servidor • Riesgos ━━━━━━━━`,
        value: warnings.join('\n')
      });
    }
    
    if (success.length > 0) {
      embed.addFields({
        name: `━━━━━━━━ <:_:1455005035724275804> PROTON • OK ━━━━━━━━`,
        value: success.join('\n')
      });
    }
    
    return embed;
  }
  
  // Embed de bienvenida al servidor
  welcomeEmbed() {
    return new EmbedBuilder()
      .setTitle('<a:_:1455453068039819295> ¡Gracias por invitarme!')
      .setDescription(`
<:more:1455002688096833758> **Listado de comandos con Slash** \`/\`
<:more:1455002688096833758> **Tutorial Básico:** [Ver tutorial](https://youtu.be/VBbfYFDk9-M)
<:more:1455002688096833758> **Soporte:** [Únete al servidor](https://discord.gg/fHmcxDWdjQ)

**<a:_:1455009802810822818> Recuerda poner el rol de \`PROTON\` en la primera posición para un correcto funcionamiento del bot**
            `)
      .setColor('#7289da')
      .setFooter({ text: 'PROTON • Protección Profesional' })
      .setTimestamp();
  }
  
  // Embed de blacklist
  blacklistEmbed(user, moderator, reason, evidence) {
    return new EmbedBuilder()
      .setTitle('<a:baneado:943714176492933200> Usuario Blacklisteado')
      .setDescription(`
**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Moderador:** <@${moderator.id}> (\`${moderator.tag}\`)
**Razón:** ${reason}
${evidence ? `**Evidencia:** ${evidence}` : ''}
            `)
      .setColor('#f04747')
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({ text: 'PROTON • Sistema de Blacklist Global' });
  }
  
  // Embed de reporte
  reportEmbed(reporter, reported, reason, evidence) {
    return new EmbedBuilder()
      .setTitle('<a:reporte:943714176492933200> Nuevo Reporte')
      .setDescription(`
**Reportado por:** <@${reporter.id}> (\`${reporter.tag}\`)
**Usuario reportado:** <@${reported.id}> (\`${reported.tag}\`)
**Razón:** ${reason}
${evidence ? `**Evidencia:** ${evidence}` : ''}
            `)
      .setColor('#faa61a')
      .setTimestamp()
      .setFooter({ text: 'PROTON • Sistema de Reportes' });
  }
}

module.exports = RB3Embeds;