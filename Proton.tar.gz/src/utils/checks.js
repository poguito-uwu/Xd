const { PermissionsBitField } = require('discord.js');

class SecurityChecks {
  constructor(client) {
    this.client = client;
  }
  
  // Verificar configuración básica del servidor
  async checkServerSetup(guildId) {
    const guild = this.client.guilds.cache.get(guildId);
    if (!guild) return { valid: false, errors: ['Servidor no encontrado'] };
    
    const errors = [];
    const warnings = [];
    const success = [];
    
    // 1. Verificar rol del bot
    const botMember = guild.members.cache.get(this.client.user.id);
    if (!botMember) {
      errors.push('El bot no está en el servidor');
      return { valid: false, errors, warnings, success };
    }
    
    const botRole = botMember.roles.highest;
    const highestPosition = Math.max(...guild.roles.cache.map(r => r.position));
    
    if (botRole.position !== highestPosition) {
      errors.push('El rol del bot no está en la primera posición');
      warnings.push('Coloca el rol "Proton Guard" en la posición más alta para protección completa');
    } else {
      success.push('Rol del bot en posición correcta');
    }
    
    // 2. Verificar permisos del bot
    const requiredPermissions = [
      PermissionsBitField.Flags.Administrator,
      PermissionsBitField.Flags.BanMembers,
      PermissionsBitField.Flags.KickMembers,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.ManageMessages,
      PermissionsBitField.Flags.ViewAuditLog
    ];
    
    const missingPermissions = requiredPermissions.filter(
      perm => !botMember.permissions.has(perm)
    );
    
    if (missingPermissions.length > 0) {
      errors.push(`Faltan permisos: ${missingPermissions.map(p => this.getPermissionName(p)).join(', ')}`);
    } else {
      success.push('Permisos del bot completos');
    }
    
    // 3. Verificar canal de logs
    const server = await this.client.db.getServer(guildId);
    if (!server?.logs_channel) {
      warnings.push('Canal de logs no configurado');
    } else {
      const logChannel = guild.channels.cache.get(server.logs_channel);
      if (!logChannel) {
        errors.push('Canal de logs configurado pero no encontrado');
      } else {
        const channelPerms = logChannel.permissionsFor(botMember);
        if (!channelPerms.has('SendMessages') || !channelPerms.has('EmbedLinks')) {
          errors.push('El bot no tiene permisos en el canal de logs');
        } else {
          success.push('Canal de logs configurado correctamente');
        }
      }
    }
    
    // 4. Verificar configuración anti-raid
    const antiraidConfig = await this.client.db.query(
      'SELECT COUNT(*) as count FROM antiraid_config WHERE server_id = ? AND enabled = TRUE',
      [guildId]
    );
    
    if (antiraidConfig[0]?.count === 0) {
      warnings.push('Sistema anti-raid no configurado');
    } else {
      success.push(`${antiraidConfig[0].count} módulos anti-raid activados`);
    }
    
    // 5. Verificar permisos peligrosos en @everyone
    const everyoneRole = guild.roles.everyone;
    const dangerousPerms = [];
    
    const dangerousPermissions = [
      PermissionsBitField.Flags.Administrator,
      PermissionsBitField.Flags.ManageGuild,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.ManageWebhooks,
      PermissionsBitField.Flags.MentionEveryone,
      PermissionsBitField.Flags.CreateInstantInvite
    ];
    
    dangerousPermissions.forEach(perm => {
      if (everyoneRole.permissions.has(perm)) {
        dangerousPerms.push(this.getPermissionName(perm));
      }
    });
    
    if (dangerousPerms.length > 0) {
      errors.push(`Permisos peligrosos en @everyone: ${dangerousPerms.join(', ')}`);
    } else {
      success.push('Rol @everyone configurado correctamente');
    }
    
    // 6. Verificar 2FA para moderación
    if (guild.mfaLevel === 0) {
      warnings.push('2FA no requerido para moderación');
    } else {
      success.push('2FA requerido para moderación');
    }
    
    // 7. Verificar nivel de verificación
    if (guild.verificationLevel < 2) {
      warnings.push('Nivel de verificación bajo');
    } else {
      success.push('Nivel de verificación adecuado');
    }
    
    return {
      valid: errors.length === 0,
      errors,
      warnings,
      success
    };
  }
  
  // Verificar seguridad de un usuario
  async checkUserSecurity(guildId, userId) {
    const guild = this.client.guilds.cache.get(guildId);
    if (!guild) return null;
    
    const member = await guild.members.fetch(userId).catch(() => null);
    if (!member) return null;
    
    const checks = {
      isAdmin: member.permissions.has(PermissionsBitField.Flags.Administrator),
      hasDangerousPerms: false,
      dangerousPermissions: [],
      isBot: member.user.bot,
      accountAge: Date.now() - member.user.createdTimestamp,
      joinAge: Date.now() - member.joinedTimestamp,
      inWhitelist: false,
      inBlacklist: false
    };
    
    // Verificar permisos peligrosos
    const dangerousPermissions = [
      PermissionsBitField.Flags.Administrator,
      PermissionsBitField.Flags.ManageGuild,
      PermissionsBitField.Flags.ManageRoles,
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.ManageWebhooks,
      PermissionsBitField.Flags.BanMembers,
      PermissionsBitField.Flags.KickMembers,
      PermissionsBitField.Flags.ManageMessages
    ];
    
    dangerousPermissions.forEach(perm => {
      if (member.permissions.has(perm)) {
        checks.dangerousPermissions.push(this.getPermissionName(perm));
        checks.hasDangerousPerms = true;
      }
    });
    
    // Verificar whitelist
    const [whitelist] = await this.client.db.query(
      'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
      [guildId, userId]
    );
    
    checks.inWhitelist = !!whitelist;
    
    // Verificar blacklist global
    const [blacklist] = await this.client.db.query(
      'SELECT * FROM blacklist WHERE user_id = ?',
      [userId]
    );
    
    checks.inBlacklist = !!blacklist;
    
    // Calcular puntuación de riesgo
    let riskScore = 0;
    
    if (checks.isAdmin) riskScore += 50;
    if (checks.hasDangerousPerms) riskScore += checks.dangerousPermissions.length * 10;
    if (checks.isBot) riskScore += 20;
    if (checks.accountAge < 7 * 24 * 60 * 60 * 1000) riskScore += 30; // Cuenta < 7 días
    if (checks.joinAge < 24 * 60 * 60 * 1000) riskScore += 20; // Unido < 24 horas
    if (checks.inWhitelist) riskScore -= 40;
    if (checks.inBlacklist) riskScore = 100;
    
    checks.riskScore = Math.min(100, Math.max(0, riskScore));
    
    // Determinar nivel de riesgo
    if (checks.riskScore >= 80) checks.riskLevel = 'critical';
    else if (checks.riskScore >= 60) checks.riskLevel = 'high';
    else if (checks.riskScore >= 40) checks.riskLevel = 'medium';
    else if (checks.riskScore >= 20) checks.riskLevel = 'low';
    else checks.riskLevel = 'safe';
    
    return checks;
  }
  
  // Verificar canales peligrosos
  checkChannelSecurity(channel) {
    const checks = {
      isPublic: false,
      hasDangerousPerms: false,
      dangerousPermissions: [],
      webhooks: 0
    };
    
    // Verificar si el canal es público
    const everyonePerms = channel.permissionOverwrites.cache.get(channel.guild.id);
    if (everyonePerms) {
      if (everyonePerms.allow.has('ViewChannel')) {
        checks.isPublic = true;
      }
    }
    
    // Verificar permisos peligrosos
    const dangerousPermissions = [
      PermissionsBitField.Flags.ManageChannels,
      PermissionsBitField.Flags.ManageWebhooks,
      PermissionsBitField.Flags.ManageMessages,
      PermissionsBitField.Flags.MentionEveryone,
      PermissionsBitField.Flags.CreateInstantInvite
    ];
    
    channel.permissionOverwrites.cache.forEach(overwrite => {
      dangerousPermissions.forEach(perm => {
        if (overwrite.allow.has(perm)) {
          checks.dangerousPermissions.push({
            target: overwrite.id,
            permission: this.getPermissionName(perm)
          });
          checks.hasDangerousPerms = true;
        }
      });
    });
    
    return checks;
  }
  
  getPermissionName(permission) {
    const names = {
      'Administrator': 'Administrador',
      'ManageGuild': 'Administrar servidor',
      'ManageRoles': 'Administrar roles',
      'ManageChannels': 'Administrar canales',
      'ManageWebhooks': 'Administrar webhooks',
      'BanMembers': 'Banear miembros',
      'KickMembers': 'Expulsar miembros',
      'ManageMessages': 'Administrar mensajes',
      'MentionEveryone': 'Mencionar @everyone',
      'CreateInstantInvite': 'Crear invitaciones',
      'ViewChannel': 'Ver canal',
      'SendMessages': 'Enviar mensajes',
      'EmbedLinks': 'Insertar enlaces',
      'AttachFiles': 'Adjuntar archivos',
      'AddReactions': 'Añadir reacciones',
      'UseExternalEmojis': 'Usar emojis externos',
      'Connect': 'Conectarse',
      'Speak': 'Hablar',
      'MuteMembers': 'Silenciar miembros',
      'DeafenMembers': 'Ensordecer miembros',
      'MoveMembers': 'Mover miembros',
      'UseVAD': 'Usar detección de voz',
      'PrioritySpeaker': 'Prioridad de altavoz',
      'Stream': 'Transmitir'
    };
    
    return names[permission] || permission;
  }
}

module.exports = SecurityChecks;