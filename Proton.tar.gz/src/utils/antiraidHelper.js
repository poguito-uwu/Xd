/**
 * ANTIRAID HELPER MODULE
 * 
 * Módulo centralizado para prevenir spam de logs y mejorar
 * la detección de eventos en el sistema antiraid.
 * 
 * Corrige el bug donde cada evento enviaba 500+ logs al canal.
 */

// Cache global para todos los eventos
const eventCache = new Map();
const logCache = new Map();

// Configuración
const CACHE_DURATION = 3000; // 3 segundos
const LOG_CACHE_DURATION = 5000; // 5 segundos para logs
const AUDIT_LOG_DELAY = 500; // Delay antes de buscar audit logs
const AUDIT_LOG_WINDOW = 5000; // Ventana de tiempo para buscar audit logs

class AntiraidHelper {
  /**
   * Verificar si un evento ya fue procesado (prevenir duplicados)
   */
  isEventProcessed(guildId, eventType, targetId) {
    const cacheKey = `${guildId}-${eventType}-${targetId}`;
    
    if (eventCache.has(cacheKey)) {
      return true; // Ya procesado
    }
    
    // Marcar como procesado
    eventCache.set(cacheKey, Date.now());
    setTimeout(() => eventCache.delete(cacheKey), CACHE_DURATION);
    
    return false;
  }
  
  /**
   * Verificar si un log ya fue enviado (prevenir spam)
   */
  isLogSent(guildId, action, userId) {
    const logKey = `log-${guildId}-${action}-${userId}-${Math.floor(Date.now() / 1000)}`;
    
    if (logCache.has(logKey)) {
      return true; // Ya enviado
    }
    
    // Marcar como enviado
    logCache.set(logKey, Date.now());
    setTimeout(() => logCache.delete(logKey), LOG_CACHE_DURATION);
    
    return false;
  }
  
  /**
   * Obtener audit log con reintento y validación
   */
  async getAuditLog(guild, options) {
    const { type, targetId, maxRetries = 2 } = options;
    
    // Verificar permisos del bot
    const botMember = guild.members.cache.get(guild.client.user.id);
    if (!botMember || !botMember.permissions.has('ViewAuditLog')) {
      throw new Error('Bot sin permiso ViewAuditLog');
    }
    
    // Esperar para que audit logs se actualicen
    await new Promise(resolve => setTimeout(resolve, AUDIT_LOG_DELAY));
    
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const auditLogs = await guild.fetchAuditLogs({
          limit: 5,
          type: type
        });
        
        // Buscar el audit log específico
        const entry = auditLogs.entries.find(e => {
          const isRecent = Date.now() - e.createdTimestamp < AUDIT_LOG_WINDOW;
          const matchesTarget = !targetId || e.target?.id === targetId;
          return isRecent && matchesTarget;
        });
        
        if (entry) {
          return entry;
        }
        
        // Si no encontramos, esperar un poco más
        if (attempt < maxRetries - 1) {
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      } catch (error) {
        console.error(`[AntiraidHelper] Error obteniendo audit log (intento ${attempt + 1}):`, error.message);
        
        if (attempt === maxRetries - 1) {
          throw error;
        }
        
        await new Promise(resolve => setTimeout(resolve, 500));
      }
    }
    
    return null;
  }
  
  /**
   * Verificar permisos y whitelist de forma centralizada
   */
  async checkPermissions(client, guild, executor, config) {
    try {
      // 1. Owner del bot
      const owners = (process.env.OWNER_IDS || process.env.OWNER_ID || '')
        .split(',')
        .map(id => id.trim())
        .filter(Boolean);
        
      if (owners.includes(executor.id)) {
        return { allowed: true, reason: 'bot_owner' };
      }
      
      // 2. Owner del servidor
      if (guild.ownerId === executor.id) {
        return { allowed: true, reason: 'guild_owner' };
      }
      
      // 3. Es el bot mismo
      if (executor.id === client.user.id) {
        return { allowed: true, reason: 'bot_itself' };
      }
      
      // 4. Administrador (si no está configurado para proteger admins)
      if (executor.permissions.has('Administrator')) {
        const protectAdmins = config.custom_settings?.protect_admins !== false;
        if (!protectAdmins) {
          return { allowed: true, reason: 'administrator' };
        }
      }
      
      // 5. Whitelist
      if (config.whitelist_enabled) {
        const [whitelisted] = await client.db.query(
          'SELECT * FROM whitelist WHERE server_id = ? AND user_id = ?',
          [guild.id, executor.id]
        );
        
        if (whitelisted) {
          return { allowed: true, reason: 'whitelist' };
        }
      }
      
      return { allowed: false, reason: 'not_whitelisted' };
      
    } catch (error) {
      console.error('[AntiraidHelper] Error verificando permisos:', error);
      return { allowed: false, reason: 'error' };
    }
  }
  
  /**
   * Aplicar sanción con validación de permisos y jerarquía
   */
  async applySanction(member, sanctionType, reason) {
    const result = {
      success: false,
      error: null,
      sanction: sanctionType
    };
    
    try {
      const guild = member.guild;
      const botMember = guild.members.me;
      
      if (!botMember) {
        result.error = 'Bot no encontrado';
        return result;
      }
      
      // Verificar jerarquía de roles
      if (member.roles.highest.position >= botMember.roles.highest.position) {
        result.error = 'Jerarquía insuficiente';
        return result;
      }
      
      // No sancionar al owner del servidor
      if (guild.ownerId === member.id) {
        result.error = 'No se puede sancionar al owner';
        return result;
      }
      
      switch (sanctionType) {
        case 'ban':
          if (!botMember.permissions.has('BanMembers')) {
            result.error = 'Sin permiso para banear';
            return result;
          }
          await member.ban({ reason, deleteMessageSeconds: 0 });
          result.success = true;
          break;
          
        case 'kick':
          if (!botMember.permissions.has('KickMembers')) {
            result.error = 'Sin permiso para expulsar';
            return result;
          }
          await member.kick(reason);
          result.success = true;
          break;
          
        case 'derank':
          if (!botMember.permissions.has('ManageRoles')) {
            result.error = 'Sin permiso para gestionar roles';
            return result;
          }
          // Guardar roles eliminados
          const removedRoles = member.roles.cache
            .filter(r => r.id !== guild.id)
            .map(r => r.id);
          await member.roles.set([], reason);
          result.success = true;
          result.removedRoles = removedRoles;
          break;
          
        default:
          result.error = `Sanción desconocida: ${sanctionType}`;
      }
      
    } catch (error) {
      result.error = error.message;
      console.error(`[AntiraidHelper] Error aplicando sanción:`, error.message);
    }
    
    return result;
  }
  
  /**
   * Enviar log al canal de logs (previene duplicados)
   */
  async sendLog(client, guildId, data) {
    try {
      // Prevenir spam de logs
      if (this.isLogSent(guildId, data.action, data.user.id)) {
        return; // Ya enviamos este log
      }
      
      const server = await client.db.getServer(guildId);
      if (!server?.logs_channel) return;
      
      const guild = client.guilds.cache.get(guildId);
      if (!guild) return;
      
      const logChannel = guild.channels.cache.get(server.logs_channel);
      if (!logChannel) return;
      
      // Verificar permisos del bot
      const permissions = logChannel.permissionsFor(client.user);
      if (!permissions || !permissions.has(['SendMessages', 'EmbedLinks'])) {
        console.warn(`[Antiraid] Sin permisos en canal de logs de ${guild.name}`);
        return;
      }
      
      // Crear embed basado en el tipo de acción
      const embed = this.createLogEmbed(client, data);
      
      await logChannel.send({ embeds: [embed] }).catch(err => {
        console.error(`[Antiraid] Error enviando log:`, err.message);
      });
      
    } catch (error) {
      console.error('[AntiraidHelper] Error en sendLog:', error);
    }
  }
  
  /**
   * Crear embed para el log
   */
  createLogEmbed(client, data) {
    const { type, user, action, details } = data;
    
    const statusIcon = details.sanction_success ? '✅' : '❌';
    const timestamp = Math.floor(Date.now() / 1000);
    
    let title = '🛡️ Evento Anti-Raid';
    let description = '';
    
    // Personalizar según el tipo de acción
    if (action.includes('channel_create')) {
      title = '🛡️ Creación de Canal Bloqueada';
      description = `**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Canal:** \`${details.channel_name}\`
**Tipo:** ${details.channel_type}
**Canal eliminado:** ${details.channel_deleted ? '✅' : '❌'}
**Sanción:** ${details.sanction} ${statusIcon}`;
      
    } else if (action.includes('role_create')) {
      title = '🛡️ Creación de Rol Bloqueada';
      description = `**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Rol:** \`${details.role_name}\`
**Color:** ${details.role_color || 'Sin color'}
**Rol eliminado:** ${details.role_deleted ? '✅' : '❌'}
**Sanción:** ${details.sanction} ${statusIcon}`;
      
    } else if (action.includes('ban_add')) {
      title = '🛡️ Ban Masivo Detectado';
      description = `**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Target:** <@${details.banned_user}>
**Sanción:** ${details.sanction} ${statusIcon}`;
      
    } else if (action.includes('webhook')) {
      title = '🛡️ Creación de Webhook Bloqueada';
      description = `**Usuario:** <@${user.id}> (\`${user.tag}\`)
**Webhook:** \`${details.webhook_name}\`
**Canal:** <#${details.channel_id}>
**Webhook eliminado:** ${details.webhook_deleted ? '✅' : '❌'}
**Sanción:** ${details.sanction} ${statusIcon}`;
    }
    
    // Añadir error si existe
    if (details.sanction_error) {
      description += `\n**Error:** \`${details.sanction_error}\``;
    }
    
    description += `\n\n**Timestamp:** <t:${timestamp}:F>`;
    
    return client.embeds.warning(title, description);
  }
  
  /**
   * Registrar en base de datos (previene duplicados)
   */
  async createDatabaseLog(client, guildId, userId, action, targetId, details) {
    try {
      // Verificar que no estemos duplicando
      const recentLogs = await client.db.query(
        `SELECT * FROM logs 
         WHERE guild_id = ? 
         AND user_id = ? 
         AND action = ? 
         AND created_at > DATE_SUB(NOW(), INTERVAL 5 SECOND)
         ORDER BY created_at DESC
         LIMIT 1`,
        [guildId, userId, action]
      );
      
      // Si ya existe un log idéntico muy reciente, no crear otro
      if (recentLogs && recentLogs.length > 0) {
        return false;
      }
      
      if (client.db.createLog) {
        await client.db.createLog(guildId, userId, action, targetId, {
          ...details,
          timestamp: Date.now()
        });
        return true;
      }
      
      return false;
    } catch (error) {
      console.error('[AntiraidHelper] Error creando log en BD:', error);
      return false;
    }
  }
  
  /**
   * Limpiar cache (útil para testing o cuando el bot se reinicia)
   */
  clearCache() {
    eventCache.clear();
    logCache.clear();
  }
  
  /**
   * Obtener estadísticas del cache
   */
  getCacheStats() {
    return {
      events: eventCache.size,
      logs: logCache.size
    };
  }
}

module.exports = new AntiraidHelper();