import { ContainerBuilder, SeparatorSpacingSize, MessageFlags } from 'discord.js';
import { ensureGlobalData, ensureGuildLeveling, getMemberSnapshot, xpToNextLevel, getRankPosition } from '../../../utils/leveling.js';
import { renderRankCard } from '../../../utils/rankCard.js';
import EMOJIS from '../../../utils/emojis.js';

const name    = 'rank';
const aliases = ['level', 'profile', 'card'];

async function execute(message, args, client) {
	const guildLeveling = await ensureGuildLeveling(client.db, message.guildId);
	if (!guildLeveling?.enabled) {
		const c = new ContainerBuilder();
		c.addTextDisplayComponents(td => td.setContent(`${EMOJIS.error || '❌'} Leveling is disabled in this server.`));
		return message.reply({ components: [c], flags: MessageFlags.IsComponentsV2, allowedMentions: { repliedUser: false } });
	}

	let member = message.member;
	if (args?.length) {
		const id = args[0].replace(/\D/g, '');
		if (id) member = await message.guild.members.fetch(id).catch(() => message.member);
	}

	const globalData    = await ensureGlobalData(client.db);
	const state         = getMemberSnapshot(globalData, member.id);
	const { position }  = getRankPosition(globalData, member.id);
	const nextXp        = xpToNextLevel(state.level);
	const rc            = state.rankCard || {};

	const buffer = await renderRankCard({
		user:        member.user,
		state,
		position,
		nextXp,
		accentColor: rc.accentColor || '#7c3aed',
		bannerUrl:   rc.bannerUrl   || null,
	});

	const payload = { allowedMentions: { repliedUser: false } };
	if (buffer) payload.files = [{ attachment: buffer, name: 'rank.png' }];
	else payload.content = `${EMOJIS.error || '❌'} Failed to render rank card.`;
	await message.reply(payload);
}

export default { name, category: 'Leveling', description: 'View your global rank card', aliases, execute, components: [] };
