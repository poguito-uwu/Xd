import {
	ContainerBuilder, SeparatorSpacingSize, ButtonBuilder, ButtonStyle,
	ActionRowBuilder, StringSelectMenuBuilder, ChannelSelectMenuBuilder,
	MessageFlags, PermissionFlagsBits, ModalBuilder, TextInputBuilder,
	TextInputStyle, MediaGalleryBuilder, TextDisplayBuilder
} from 'discord.js';
import { ensureGuildLeveling } from '../../../utils/leveling.js';
import EMOJIS from '../../../utils/emojis.js';

const name    = 'leveling';
const aliases = ['levels', 'level-config', 'lvl'];

// ── Dashboard ─────────────────────────────────────────────────────────────────
export const buildDashboard = (leveling, authorId) => {
	const announce = leveling.announce || {};
	const c = new ContainerBuilder();
	c.addTextDisplayComponents(td => td.setContent(`# ${EMOJIS.tada || '🎉'} Level-Up Announcements`));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addTextDisplayComponents(td => td.setContent(
		`**Status:** ${leveling.enabled ? '✅ Enabled' : '❌ Disabled'}\n` +
		`**Mode:** ${announce.mode || 'context'}` +
		(announce.mode === 'channel' && announce.channelId ? ` → <#${announce.channelId}>` : '') + '\n' +
		`-# XP is global and automatic. Only announcement settings are configurable per server.`
	));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));

	// Enable / disable toggle
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new ButtonBuilder()
			.setCustomId(`lv_toggle:${authorId}`)
			.setLabel(leveling.enabled ? '🔴 Disable Announcements' : '🟢 Enable Announcements')
			.setStyle(leveling.enabled ? ButtonStyle.Danger : ButtonStyle.Success)
	));

	// Announce mode
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new StringSelectMenuBuilder()
			.setCustomId(`lv_announce_mode:${authorId}`)
			.setPlaceholder('Where to send level-up messages')
			.setMinValues(1).setMaxValues(1)
			.setOptions([
				{ label: 'Same channel as message', value: 'context',  default: (announce.mode || 'context') === 'context' },
				{ label: 'Specific channel',        value: 'channel',  default: announce.mode === 'channel' },
				{ label: 'DM the user',             value: 'dm',       default: announce.mode === 'dm' },
				{ label: 'No announcements',        value: 'none',     default: announce.mode === 'none' },
			])
	));

	// Channel picker (only shown / relevant when mode = channel)
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new ChannelSelectMenuBuilder()
			.setCustomId(`lv_channel_select:${authorId}`)
			.setPlaceholder(announce.mode === 'channel' ? `Current: ${announce.channelId ? `#${announce.channelId}` : 'none'}` : 'Pick a channel (channel mode only)')
			.setMinValues(0).setMaxValues(1)
			.addChannelTypes(0, 5)
	));

	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new ButtonBuilder().setCustomId(`lv_nav_message:${authorId}`).setLabel('✉️ Customize Message').setStyle(ButtonStyle.Secondary),
		new ButtonBuilder().setCustomId(`lv_nav_ignores:${authorId}`).setLabel('🚫 Ignored Channels').setStyle(ButtonStyle.Secondary)
	));

	return c;
};

// ── Ignored channels panel ────────────────────────────────────────────────────
export const buildIgnores = (leveling, authorId) => {
	const c = new ContainerBuilder();
	c.addTextDisplayComponents(td => td.setContent(`# 🚫 Channels Without XP`));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addTextDisplayComponents(td => td.setContent(
		`**${leveling.ignores?.channels?.length || 0}** channel(s) ignored.\n` +
		`-# Users chatting in these channels will not earn XP in this server.`
	));
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new ChannelSelectMenuBuilder()
			.setCustomId(`lv_ignore_channels:${authorId}`)
			.setPlaceholder('Select channels to ignore (replaces current list)')
			.setMinValues(0).setMaxValues(25)
			.addChannelTypes(0, 5)
	));
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new ButtonBuilder().setCustomId(`lv_nav_back:${authorId}`).setLabel('← Back').setStyle(ButtonStyle.Secondary)
	));
	return c;
};

// ── Level-up message editor ───────────────────────────────────────────────────
export const buildMessageEditor = (leveling, authorId) => {
	const msg = leveling.announce?.message || {};
	const c   = new ContainerBuilder();
	c.addTextDisplayComponents(td => td.setContent(`# ✉️ Level-Up Message`));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addTextDisplayComponents(td => td.setContent(
		`**Variables:** \`{user.mention}\` \`{user.name}\` \`{level}\` \`{xp}\` \`{server}\` \`{timestamp}\``
	));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));

	const preview = [];
	if (msg.content)   preview.push(`**Text:** ${msg.content.substring(0, 60)}...`);
	if (msg.title)     preview.push(`**Title:** ${msg.title}`);
	if (msg.body)      preview.push(`**Body:** ${msg.body.substring(0, 60)}...`);
	if (msg.thumbnail) preview.push(`**Thumbnail:** ✅`);
	if (msg.image)     preview.push(`**Image:** ✅`);
	if (msg.footer)    preview.push(`**Footer:** ${msg.footer}`);

	c.addTextDisplayComponents(td => td.setContent(
		preview.length ? `**Current:**\n${preview.join('\n')}` : '*Using default message.*'
	));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new ButtonBuilder().setCustomId(`lv_msg_content:${authorId}`).setLabel('Text').setStyle(ButtonStyle.Secondary),
		new ButtonBuilder().setCustomId(`lv_msg_title:${authorId}`).setLabel('Title').setStyle(ButtonStyle.Secondary),
		new ButtonBuilder().setCustomId(`lv_msg_body:${authorId}`).setLabel('Body').setStyle(ButtonStyle.Secondary),
		new ButtonBuilder().setCustomId(`lv_msg_footer:${authorId}`).setLabel('Footer').setStyle(ButtonStyle.Secondary)
	));
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new ButtonBuilder().setCustomId(`lv_msg_thumbnail:${authorId}`).setLabel('Thumbnail').setStyle(ButtonStyle.Secondary),
		new ButtonBuilder().setCustomId(`lv_msg_image:${authorId}`).setLabel('Image').setStyle(ButtonStyle.Secondary),
		new ButtonBuilder().setCustomId(`lv_msg_preview:${authorId}`).setLabel('👁️ Preview').setStyle(ButtonStyle.Primary),
		new ButtonBuilder().setCustomId(`lv_msg_reset:${authorId}`).setLabel('🗑️ Reset').setStyle(ButtonStyle.Danger),
		new ButtonBuilder().setCustomId(`lv_nav_back:${authorId}`).setLabel('← Back').setStyle(ButtonStyle.Secondary)
	));
	return c;
};

// ── Auth helpers ──────────────────────────────────────────────────────────────
const requireManageGuild = m =>
	m.permissions.has(PermissionFlagsBits.ManageGuild) ||
	m.permissions.has(PermissionFlagsBits.Administrator);

const handleDash = async (interaction, authorId) => {
	if (interaction.user.id !== authorId) {
		await interaction.reply({ content: '❌ Locked to the command invoker.', ephemeral: true });
		return null;
	}
	if (!requireManageGuild(interaction.member)) {
		await interaction.reply({ content: '❌ Manage Server required.', ephemeral: true });
		return null;
	}
	return ensureGuildLeveling(interaction.client.db, interaction.guildId);
};

const SAFE    = { parse: [], repliedUser: false };
const refresh = async (i, lv, a) => {
	const method = i.update ? 'update' : 'editReply';
	await i[method]({ components: [buildDashboard(lv, a)], flags: MessageFlags.IsComponentsV2, allowedMentions: SAFE }).catch(() => {});
};

// ── Component handlers ────────────────────────────────────────────────────────
const components = [
	{ customId: /^lv_toggle:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_toggle:(\d+)$/) || [];
		const lv = await handleDash(i, a); if (!lv) return;
		lv.enabled = !lv.enabled;
		await i.client.db.updateOne({ guildId: i.guildId }, { $set: { leveling: lv } });
		await refresh(i, lv, a);
	}},
	{ customId: /^lv_announce_mode:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_announce_mode:(\d+)$/) || [];
		const lv = await handleDash(i, a); if (!lv) return;
		lv.announce.mode = i.values?.[0];
		await i.client.db.updateOne({ guildId: i.guildId }, { $set: { leveling: lv } });
		await refresh(i, lv, a);
	}},
	{ customId: /^lv_channel_select:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_channel_select:(\d+)$/) || [];
		const lv = await handleDash(i, a); if (!lv) return;
		lv.announce.channelId = i.values?.[0] || null;
		await i.client.db.updateOne({ guildId: i.guildId }, { $set: { leveling: lv } });
		await refresh(i, lv, a);
	}},
	{ customId: /^lv_nav_message:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_nav_message:(\d+)$/) || [];
		const lv = await handleDash(i, a); if (!lv) return;
		await i.update({ components: [buildMessageEditor(lv, a)], flags: MessageFlags.IsComponentsV2, allowedMentions: SAFE }).catch(() => {});
	}},
	{ customId: /^lv_nav_ignores:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_nav_ignores:(\d+)$/) || [];
		const lv = await handleDash(i, a); if (!lv) return;
		await i.update({ components: [buildIgnores(lv, a)], flags: MessageFlags.IsComponentsV2, allowedMentions: SAFE }).catch(() => {});
	}},
	{ customId: /^lv_nav_back:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_nav_back:(\d+)$/) || [];
		const lv = await handleDash(i, a); if (!lv) return;
		await refresh(i, lv, a);
	}},
	{ customId: /^lv_ignore_channels:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_ignore_channels:(\d+)$/) || [];
		const lv = await handleDash(i, a); if (!lv) return;
		lv.ignores.channels = Array.from(new Set(i.values || []));
		await i.client.db.updateOne({ guildId: i.guildId }, { $set: { leveling: lv } });
		await i.update({ components: [buildIgnores(lv, a)], flags: MessageFlags.IsComponentsV2, allowedMentions: SAFE }).catch(() => {});
	}},
	{ customId: /^lv_msg_(content|title|body|footer|thumbnail|image):(\d+)$/, execute: async (i) => {
		const [,field,a] = i.customId.match(/^lv_msg_(content|title|body|footer|thumbnail|image):(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked.', ephemeral: true });
		const lv  = await ensureGuildLeveling(i.client.db, i.guildId);
		const msg = lv.announce?.message || {};
		const cfg = {
			content:   { label: 'Plain text',        max: 2000, style: TextInputStyle.Paragraph, cur: msg.content },
			title:     { label: 'Title',             max: 256,  style: TextInputStyle.Short,     cur: msg.title },
			body:      { label: 'Body',              max: 2000, style: TextInputStyle.Paragraph, cur: msg.body },
			footer:    { label: 'Footer',            max: 256,  style: TextInputStyle.Short,     cur: msg.footer },
			thumbnail: { label: 'Thumbnail URL',     max: 500,  style: TextInputStyle.Short,     cur: msg.thumbnail },
			image:     { label: 'Image URL',         max: 500,  style: TextInputStyle.Short,     cur: msg.image },
		}[field];
		const modal = new ModalBuilder().setCustomId(`lv_msg_modal:${field}:${a}`).setTitle(`Edit ${cfg.label}`);
		const inp   = new TextInputBuilder().setCustomId('value').setLabel(cfg.label).setStyle(cfg.style).setMaxLength(cfg.max).setRequired(false);
		if (cfg.cur) inp.setValue(cfg.cur);
		modal.addComponents(new ActionRowBuilder().addComponents(inp));
		await i.showModal(modal);
	}},
	{ customId: /^lv_msg_preview:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_msg_preview:(\d+)$/) || [];
		const lv  = await ensureGuildLeveling(i.client.db, i.guildId);
		const msg = lv.announce?.message || {};
		const rv  = s => s ? s
			.replace(/{user\.mention}/g, i.user.toString())
			.replace(/{user\.name}/g,    i.user.username)
			.replace(/{level}/g,         '5')
			.replace(/{xp}/g,            '1250')
			.replace(/{server}/g,        i.guild.name)
			.replace(/{timestamp}/g,     new Date().toLocaleString())
			: s;
		const hasCustom = msg.content || msg.title || msg.body || msg.thumbnail || msg.footer || msg.image;
		if (!hasCustom) {
			const def = new ContainerBuilder();
			def.addTextDisplayComponents(td => td.setContent('✅ Level Up!'));
			def.addSeparatorComponents(s => s.setSpacing(SeparatorSpacingSize.Small));
			def.addTextDisplayComponents(td => td.setContent(`${i.user} just reached level 5! 🎉`));
			def.addTextDisplayComponents(td => td.setContent('-# Default message.'));
			return i.reply({ components: [def], flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral, allowedMentions: { parse: ['users'] } });
		}
		const pc = new ContainerBuilder();
		if (msg.title) { pc.addTextDisplayComponents(td => td.setContent(`**${rv(msg.title)}**`)); pc.addSeparatorComponents(s => s.setSpacing(SeparatorSpacingSize.Small)); }
		if (msg.body || msg.thumbnail) {
			const t = (rv(msg.thumbnail) || '').trim();
			pc.addSectionComponents(sec => {
				sec.addTextDisplayComponents(td => td.setContent(msg.body ? rv(msg.body) : '\u200b'));
				if (t?.startsWith('http')) sec.setThumbnailAccessory(th => th.setURL(t));
				return sec;
			});
		} else if (msg.body) pc.addTextDisplayComponents(td => td.setContent(rv(msg.body)));
		if (msg.image) { const u = (rv(msg.image)||'').trim(); if (u?.startsWith('http')) pc.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(it => it.setURL(u))); }
		if (msg.footer) { pc.addSeparatorComponents(s => s.setSpacing(SeparatorSpacingSize.Small)); pc.addTextDisplayComponents(td => td.setContent(`-# ${rv(msg.footer)}`)); }
		const comps = [];
		if (msg.content) comps.push(new TextDisplayBuilder().setContent(rv(msg.content)));
		comps.push(pc);
		await i.reply({ components: comps, flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral, allowedMentions: { parse: ['users'] } });
	}},
	{ customId: /^lv_msg_reset:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^lv_msg_reset:(\d+)$/) || [];
		const lv = await handleDash(i, a); if (!lv) return;
		lv.announce.message  = {};
		lv.announce.template = '{user.mention} just reached level {level}! 🎉';
		await i.client.db.updateOne({ guildId: i.guildId }, { $set: { leveling: lv } });
		await i.update({ components: [buildMessageEditor(lv, a)], flags: MessageFlags.IsComponentsV2, allowedMentions: SAFE }).catch(() => {});
	}},
];

async function execute(message, args, client) {
	if (!requireManageGuild(message.member)) {
		const c = new ContainerBuilder();
		c.addTextDisplayComponents(td => td.setContent(`${EMOJIS.error || '❌'} **Manage Server** required.`));
		return message.reply({ components: [c], flags: MessageFlags.IsComponentsV2, allowedMentions: { repliedUser: false } });
	}
	const leveling = await ensureGuildLeveling(client.db, message.guildId);
	await message.reply({ components: [buildDashboard(leveling, message.author.id)], flags: MessageFlags.IsComponentsV2, allowedMentions: SAFE });
}

export default { name, category: 'Leveling', aliases, execute, components };
