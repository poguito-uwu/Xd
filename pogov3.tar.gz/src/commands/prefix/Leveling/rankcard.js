import {
	ContainerBuilder, SeparatorSpacingSize, ButtonBuilder, ButtonStyle,
	ActionRowBuilder, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle
} from 'discord.js';
import { ensureGlobalData, ensureMember, saveGlobalData, xpToNextLevel, getRankPosition } from '../../../utils/leveling.js';
import { renderRankCard } from '../../../utils/rankCard.js';
import EMOJIS from '../../../utils/emojis.js';

const name    = 'rankcard';
const aliases = ['rank-card', 'cardsetup', 'card'];

export const buildPanel = (state, authorId) => {
	const rc = state.rankCard || {};
	const c  = new ContainerBuilder();
	c.addTextDisplayComponents(td => td.setContent(`# 🎨 Rank Card`));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addTextDisplayComponents(td => td.setContent(
		`**Accent Color:** ${rc.accentColor || '#7c3aed'}\n` +
		`**Banner URL:** ${rc.bannerUrl ? '✅ Set' : '❌ Not set (default background)'}\n` +
		`-# Customize how your rank card looks. Use **Preview** to see a live render.`
	));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addActionRowComponents(new ActionRowBuilder().addComponents(
		new ButtonBuilder().setCustomId(`rc_accent:${authorId}`).setLabel('🎨 Accent Color').setStyle(ButtonStyle.Secondary),
		new ButtonBuilder().setCustomId(`rc_banner:${authorId}`).setLabel('🖼️ Banner Image').setStyle(ButtonStyle.Primary),
		new ButtonBuilder().setCustomId(`rc_reset:${authorId}`).setLabel('🗑️ Reset').setStyle(ButtonStyle.Danger),
		new ButtonBuilder().setCustomId(`rc_preview:${authorId}`).setLabel('👁️ Preview').setStyle(ButtonStyle.Success)
	));
	return c;
};

const components = [
	// Accent color
	{ customId: /^rc_accent:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^rc_accent:(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked.', ephemeral: true });
		const gd    = await ensureGlobalData(i.client.db);
		const state = ensureMember(gd, i.user.id);
		const modal = new ModalBuilder().setCustomId(`rc_accent_modal:${a}`).setTitle('Accent Color');
		modal.addComponents(new ActionRowBuilder().addComponents(
			new TextInputBuilder().setCustomId('color').setLabel('Hex color (e.g. #7c3aed)').setStyle(TextInputStyle.Short)
				.setRequired(true).setValue(state.rankCard?.accentColor || '#7c3aed').setMaxLength(7)
		));
		await i.showModal(modal);
	}},
	// Banner URL
	{ customId: /^rc_banner:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^rc_banner:(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked.', ephemeral: true });
		const modal = new ModalBuilder().setCustomId(`rc_banner_modal:${a}`).setTitle('Banner Image URL');
		modal.addComponents(new ActionRowBuilder().addComponents(
			new TextInputBuilder().setCustomId('url').setLabel('Direct image URL (https://...)').setStyle(TextInputStyle.Short)
				.setRequired(false).setMaxLength(512).setPlaceholder('Leave empty to remove banner')
		));
		await i.showModal(modal);
	}},
	// Reset
	{ customId: /^rc_reset:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^rc_reset:(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked.', ephemeral: true });
		const gd    = await ensureGlobalData(i.client.db);
		const state = ensureMember(gd, i.user.id);
		state.rankCard = { accentColor: '#7c3aed', bannerUrl: null };
		await saveGlobalData(i.client.db, gd);
		await i.update({ components: [buildPanel(state, a)], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
	}},
	// Preview
	{ customId: /^rc_preview:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^rc_preview:(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked.', ephemeral: true });
		await i.deferReply({ ephemeral: true });
		const gd    = await ensureGlobalData(i.client.db);
		const state = ensureMember(gd, i.user.id);
		const rc    = state.rankCard || {};
		const { position } = getRankPosition(gd, i.user.id);
		const nextXp = xpToNextLevel(state.level);
		const buf    = await renderRankCard({
			user:        i.user,
			state,
			position:    position || 1,
			nextXp,
			accentColor: rc.accentColor || '#7c3aed',
			bannerUrl:   rc.bannerUrl   || null,
		});
		if (buf) await i.editReply({ content: '**Preview:**', files: [{ attachment: buf, name: 'rank-preview.png' }] });
		else     await i.editReply({ content: '❌ Could not render preview.' });
	}},
];

export const modalHandlers = [
	{ customId: /^rc_accent_modal:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^rc_accent_modal:(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked.', ephemeral: true });
		const color = i.fields.getTextInputValue('color').trim();
		if (!/^#[0-9a-fA-F]{6}$/.test(color)) return i.reply({ content: '❌ Use format `#rrggbb` e.g. `#7c3aed`.', ephemeral: true });
		const gd    = await ensureGlobalData(i.client.db);
		const state = ensureMember(gd, i.user.id);
		if (!state.rankCard) state.rankCard = { accentColor: '#7c3aed', bannerUrl: null };
		state.rankCard.accentColor = color;
		await saveGlobalData(i.client.db, gd);
		await i.reply({ components: [buildPanel(state, a)], flags: MessageFlags.IsComponentsV2 });
	}},
	{ customId: /^rc_banner_modal:(\d+)$/, execute: async (i) => {
		const [,a] = i.customId.match(/^rc_banner_modal:(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked.', ephemeral: true });
		const url = i.fields.getTextInputValue('url').trim() || null;
		if (url && !url.startsWith('http')) return i.reply({ content: '❌ URL must start with https://', ephemeral: true });
		const gd    = await ensureGlobalData(i.client.db);
		const state = ensureMember(gd, i.user.id);
		if (!state.rankCard) state.rankCard = { accentColor: '#7c3aed', bannerUrl: null };
		state.rankCard.bannerUrl = url;
		await saveGlobalData(i.client.db, gd);
		await i.reply({ components: [buildPanel(state, a)], flags: MessageFlags.IsComponentsV2 });
	}},
];

async function execute(message, args, client) {
	const globalData = await ensureGlobalData(client.db);
	const state      = ensureMember(globalData, message.author.id);
	await message.reply({ components: [buildPanel(state, message.author.id)], flags: MessageFlags.IsComponentsV2, allowedMentions: { repliedUser: false } });
}

export default { name, aliases, category: 'Leveling', description: 'Customize your rank card', execute, components };
