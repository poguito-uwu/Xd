import { ContainerBuilder, SeparatorSpacingSize, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } from 'discord.js';
import { ensureGlobalData, ensureGuildLeveling, getLeaderboard, xpToNextLevel } from '../../../utils/leveling.js';
import EMOJIS from '../../../utils/emojis.js';

const name    = 'leaderboard';
const aliases = ['lb', 'levels-top', 'leveltop'];
const PER_PAGE = 10;

export const buildPage = (globalData, page, authorId, botName = 'Ares') => {
	const entries    = getLeaderboard(globalData, 200);
	const totalPages = Math.max(1, Math.ceil(entries.length / PER_PAGE));
	const current    = Math.min(Math.max(0, page), totalPages - 1);
	const slice      = entries.slice(current * PER_PAGE, current * PER_PAGE + PER_PAGE);

	const medals = ['🥇', '🥈', '🥉'];
	const c      = new ContainerBuilder();
	c.addTextDisplayComponents(td => td.setContent(`# ${EMOJIS.trophy || '🏆'} Global Leaderboard`));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));

	if (!slice.length) {
		c.addTextDisplayComponents(td => td.setContent('No tracked users yet.'));
	} else {
		const lines = slice.map((entry, idx) => {
			const rank    = current * PER_PAGE + idx + 1;
			const needed  = xpToNextLevel(entry.level);
			const pct     = Math.min(100, Math.round((entry.xp / needed) * 100));
			const bar     = '█'.repeat(Math.floor(pct / 10)) + '░'.repeat(10 - Math.floor(pct / 10));
			const medal   = rank <= 3 ? medals[rank - 1] + ' ' : `**#${rank}** `;
			return `${medal}<@${entry.userId}> — Level **${entry.level}** • ${entry.totalXp?.toLocaleString() || 0} total XP\n\`${bar}\` ${pct}%`;
		});
		c.addTextDisplayComponents(td => td.setContent(lines.join('\n\n')));
	}

	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addTextDisplayComponents(td => td.setContent(`Page ${current + 1} / ${totalPages} • ${botName}`));

	if (totalPages > 1) {
		c.addActionRowComponents(new ActionRowBuilder().addComponents(
			new ButtonBuilder().setCustomId(`lb_prev:${authorId}:${current}`).setLabel('◀ Prev').setStyle(ButtonStyle.Secondary).setDisabled(current === 0),
			new ButtonBuilder().setCustomId(`lb_next:${authorId}:${current}:${totalPages}`).setLabel('Next ▶').setStyle(ButtonStyle.Secondary).setDisabled(current >= totalPages - 1)
		));
	}
	return c;
};

const components = [
	{ customId: /^lb_prev:(\d+):(\d+)$/, execute: async (i) => {
		const [, a, p] = i.customId.match(/^lb_prev:(\d+):(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked to invoker.', ephemeral: true });
		const globalData = await ensureGlobalData(i.client.db);
		const panel = buildPage(globalData, parseInt(p) - 1, a, i.client.user?.username);
		await i.update({ components: [panel], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
	}},
	{ customId: /^lb_next:(\d+):(\d+):(\d+)$/, execute: async (i) => {
		const [, a, p] = i.customId.match(/^lb_next:(\d+):(\d+):(\d+)$/) || [];
		if (i.user.id !== a) return i.reply({ content: '❌ Locked to invoker.', ephemeral: true });
		const globalData = await ensureGlobalData(i.client.db);
		const panel = buildPage(globalData, parseInt(p) + 1, a, i.client.user?.username);
		await i.update({ components: [panel], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
	}},
];

async function execute(message, args, client) {
	const guildLeveling = await ensureGuildLeveling(client.db, message.guildId);
	if (!guildLeveling?.enabled) {
		const c = new ContainerBuilder();
		c.addTextDisplayComponents(td => td.setContent(`${EMOJIS.error || '❌'} Leveling is disabled in this server.`));
		return message.reply({ components: [c], flags: MessageFlags.IsComponentsV2, allowedMentions: { repliedUser: false } });
	}
	const globalData = await ensureGlobalData(client.db);
	const panel      = buildPage(globalData, 0, message.author.id, client.user?.username);
	await message.reply({ components: [panel], flags: MessageFlags.IsComponentsV2, allowedMentions: { repliedUser: false } });
}

export default { name, category: 'Leveling', aliases, execute, components };
