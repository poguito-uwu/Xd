import {
    PermissionFlagsBits,
    ContainerBuilder,
    MessageFlags,
    SeparatorSpacingSize,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
} from 'discord.js';

const WIZARD_TTL = 10 * 60 * 1000; // 10 minutes

// ─── Field definitions ────────────────────────────────────────────────────────

const LINKED_FIELDS = [
    { key: 'author',      label: 'Autor',              emoji: '👤', required: false, placeholder: 'Nombre del autor (opcional)',          max: 256  },
    { key: 'title',       label: 'Título',             emoji: '📝', required: true,  placeholder: 'Título del embed',                    max: 256  },
    { key: 'description', label: 'Descripción',        emoji: '📄', required: true,  placeholder: 'Texto del embed de verificación',      max: 4000 },
    { key: 'image',       label: 'URL de imagen',      emoji: '🖼️', required: false, placeholder: 'https://ejemplo.com/imagen.png',       max: 500  },
    { key: 'footer',      label: 'Footer',             emoji: '📌', required: false, placeholder: 'Texto del footer (opcional)',          max: 256  },
    { key: 'buttonLabel', label: 'Texto del botón',    emoji: '🔘', required: false, placeholder: 'Verificar (se usará si dejas vacío)', max: 80   },
    { key: 'roleName',    label: 'Nombre del rol',     emoji: '🎭', required: true,  placeholder: 'El bot creará este rol automáticamente', max: 100 },
];

const REACTION_FIELDS = [
    { key: 'author',      label: 'Autor',              emoji: '👤', required: false, placeholder: 'Nombre del autor (opcional)',          max: 256  },
    { key: 'title',       label: 'Título',             emoji: '📝', required: true,  placeholder: 'Título del embed',                    max: 256  },
    { key: 'description', label: 'Descripción',        emoji: '📄', required: true,  placeholder: 'Texto del embed de verificación',      max: 4000 },
    { key: 'image',       label: 'URL de imagen',      emoji: '🖼️', required: false, placeholder: 'https://ejemplo.com/imagen.png',       max: 500  },
    { key: 'footer',      label: 'Footer',             emoji: '📌', required: false, placeholder: 'Texto del footer (opcional)',          max: 256  },
    { key: 'emoji',       label: 'Emoji de reacción',  emoji: '😀', required: false, placeholder: '✅ (se usará si dejas vacío)',         max: 64   },
    { key: 'roleId',      label: 'Rol a asignar',      emoji: '🎭', required: true,  placeholder: '@MenciónaElRol o pega el ID',         max: 200  },
];

export function getFieldsByType(type) {
    return type === 'linked' ? LINKED_FIELDS : REACTION_FIELDS;
}

// ─── Wizard state factory ─────────────────────────────────────────────────────

export function createWizardState(userId, guildId, type) {
    return {
        type,
        userId,
        guildId,
        wizardMessageId: null,
        wizardChannelId: null,
        config: {
            author: null,
            title: null,
            description: null,
            thumbnail: false,
            image: null,
            footer: null,
            buttonLabel: null,
            roleName: null,  // linked only — bot creates the role
            roleId: null,    // reaction only — user provides existing role
            _roleName: null, // display name for reaction roleId
            emoji: null,     // reaction only
        },
        expiresAt: Date.now() + WIZARD_TTL,
    };
}

// ─── Wizard container builder ─────────────────────────────────────────────────

export function buildWizardContainer(state) {
    const fields = getFieldsByType(state.type);
    const isLinked = state.type === 'linked';

    // Determine required completeness
    const requiredFields = fields.filter(f => f.required);
    const allRequiredFilled = requiredFields.every(f => {
        const val = state.config[f.key];
        return val && val.trim().length > 0;
    });

    // Build status lines
    let statusText = '';
    for (const f of fields) {
        const val = f.key === 'roleId'
            ? (state.config.roleId ? (state.config._roleName || state.config.roleId) : null)
            : state.config[f.key];
        const icon = val ? '✅' : (f.required ? '❌' : '⬜');
        const display = val
            ? (val.length > 45 ? val.substring(0, 45) + '…' : val)
            : '*(vacío)*';
        statusText += `${icon} **${f.emoji} ${f.label}**: ${display}\n`;
    }
    // Thumbnail toggle
    statusText += `${state.config.thumbnail ? '✅' : '⬜'} **🖼️ Thumbnail**: ${state.config.thumbnail ? 'Ícono del servidor' : '*(desactivado)*'}\n`;

    const container = new ContainerBuilder();

    const typeLabel = isLinked ? '🔗 Linked Roles' : '😀 Reacción';
    container.addTextDisplayComponents(td =>
        td.setContent(`# ⚙️ Configurar Verificación — ${typeLabel}`)
    );
    container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
    container.addTextDisplayComponents(td =>
        td.setContent(
            `Selecciona un campo del menú para editarlo.\n\n` +
            statusText + '\n' +
            (allRequiredFilled
                ? '✨ **Todos los campos requeridos están completos.** Haz clic en **Publicar**.'
                : '⚠️ Completa los campos marcados con ❌ para poder publicar.')
        )
    );
    container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));

    // ── Select menu ──
    const options = fields.map(f => {
        const val = f.key === 'roleId'
            ? (state.config.roleId ? state.config._roleName || state.config.roleId : null)
            : state.config[f.key];

        return new StringSelectMenuOptionBuilder()
            .setValue(f.key)
            .setLabel(`${f.emoji} ${f.label}`)
            .setDescription(
                val
                    ? `Actual: ${val.substring(0, 45)}`
                    : f.required ? '⚠️ Requerido' : 'Opcional — clic para editar'
            );
    });

    // Thumbnail toggle option
    options.push(
        new StringSelectMenuOptionBuilder()
            .setValue('thumbnail')
            .setLabel('🖼️ Thumbnail')
            .setDescription(state.config.thumbnail
                ? 'Activado (ícono del servidor) — clic para desactivar'
                : 'Desactivado — clic para activar con ícono del servidor')
    );

    const select = new StringSelectMenuBuilder()
        .setCustomId(`verify_wizard_select:${state.userId}`)
        .setPlaceholder('Selecciona un campo para editar…')
        .addOptions(options);

    container.addActionRowComponents(() => new ActionRowBuilder().addComponents(select));

    // ── Post / Cancel buttons ──
    const postBtn = new ButtonBuilder()
        .setCustomId(`verify_wizard_post:${state.userId}`)
        .setLabel('📤 Publicar')
        .setStyle(allRequiredFilled ? ButtonStyle.Success : ButtonStyle.Secondary)
        .setDisabled(!allRequiredFilled);

    const cancelBtn = new ButtonBuilder()
        .setCustomId(`verify_wizard_cancel:${state.userId}`)
        .setLabel('✕ Cancelar')
        .setStyle(ButtonStyle.Danger);

    container.addActionRowComponents(() => new ActionRowBuilder().addComponents(postBtn, cancelBtn));

    return container;
}

// ─── Command export ───────────────────────────────────────────────────────────

export default {
    name: 'verify',
    description: 'Sistema de verificación — Linked Roles o reacción de emoji',
    category: 'Verification',
    aliases: ['verification', 'verif'],
    usage: 'setup <linked|reaction> | list | delete <id>',
    examples: [
        'verify setup linked',
        'verify setup reaction',
        'verify list',
        'verify delete abc123',
    ],
    userPermissions: [PermissionFlagsBits.ManageGuild],

    async execute(message, args, client) {
        if (!message.guild) return;

        const sub = args[0]?.toLowerCase();

        if (sub === 'setup') {
            const type = args[1]?.toLowerCase();
            if (type !== 'linked' && type !== 'reaction') return this.showHelp(message);
            return this.startWizard(message, client, type);
        }

        if (sub === 'list') return this.listPanels(message, client);

        if (sub === 'delete' || sub === 'remove') {
            return this.deletePanel(message, args[1], client);
        }

        return this.showHelp(message);
    },

    // ── Help ──────────────────────────────────────────────────────────────────

    async showHelp(message) {
        const container = new ContainerBuilder();
        container.addTextDisplayComponents(td => td.setContent('# 🔐 Sistema de Verificación'));
        container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
        container.addTextDisplayComponents(td =>
            td.setContent(
                `**Subcomandos:**\n` +
                `> \`!verify setup linked\` — Panel con Linked Roles (inicio de sesión OAuth)\n` +
                `> \`!verify setup reaction\` — Panel con reacción de emoji\n` +
                `> \`!verify list\` — Ver paneles activos\n` +
                `> \`!verify delete <id>\` — Eliminar un panel\n\n` +
                `**Tipos:**\n` +
                `🔗 **Linked Roles** — El bot crea un rol; el usuario inicia sesión via OAuth para obtenerlo.\n` +
                `😀 **Reacción** — El usuario reacciona con un emoji para obtener un rol existente.`
            )
        );
        await message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { repliedUser: false },
        });
    },

    // ── Start wizard ──────────────────────────────────────────────────────────

    async startWizard(message, client, type) {
        const stateKey = `verify_wizard:${message.author.id}:${message.guildId}`;

        // Clear any previous wizard
        client.componentContexts.delete(stateKey);

        const state = createWizardState(message.author.id, message.guildId, type);
        const container = buildWizardContainer(state);

        const reply = await message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { repliedUser: false },
        });

        // Store message reference so modal submit can edit it
        state.wizardMessageId = reply.id;
        state.wizardChannelId = reply.channelId;
        client.componentContexts.set(stateKey, state);

        // Auto-expire
        setTimeout(() => client.componentContexts.delete(stateKey), WIZARD_TTL);
    },

    // ── List panels ───────────────────────────────────────────────────────────

    async listPanels(message, client) {
        const guildData = await client.db.findOne({ guildId: message.guildId }) || {};
        const panels = guildData.verificationPanels || [];

        const container = new ContainerBuilder();
        container.addTextDisplayComponents(td => td.setContent('# 🔐 Paneles de Verificación'));
        container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));

        if (panels.length === 0) {
            container.addTextDisplayComponents(td =>
                td.setContent('No hay paneles configurados. Usa `!verify setup linked` o `!verify setup reaction` para crear uno.')
            );
        } else {
            let content = '';
            for (const [i, p] of panels.entries()) {
                const icon = p.type === 'linked' ? '🔗' : '😀';
                content += `**${i + 1}.** ${icon} ID: \`${p.id}\`\n`;
                content += `   Título: **${p.config.title || '*(sin título)*'}**\n`;
                content += `   Canal: <#${p.channelId}> • Rol: <@&${p.roleId}>\n\n`;
            }
            container.addTextDisplayComponents(td => td.setContent(content.trim()));
        }

        await message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { repliedUser: false },
        });
    },

    // ── Delete panel ──────────────────────────────────────────────────────────

    async deletePanel(message, panelId, client) {
        if (!panelId) {
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(td => td.setContent('# ❌ Error'));
            container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
            container.addTextDisplayComponents(td => td.setContent('Especifica el ID del panel. Usa `!verify list` para ver los IDs.'));
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { repliedUser: false } });
        }

        const guildData = await client.db.findOne({ guildId: message.guildId }) || {};
        const panels = guildData.verificationPanels || [];

        const index = panels.findIndex(p => p.id === panelId);
        if (index === -1) {
            const container = new ContainerBuilder();
            container.addTextDisplayComponents(td => td.setContent('# ❌ Panel no encontrado'));
            container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
            container.addTextDisplayComponents(td => td.setContent(`No se encontró el panel \`${panelId}\`. Usa \`!verify list\` para ver los disponibles.`));
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2, allowedMentions: { repliedUser: false } });
        }

        panels.splice(index, 1);
        await client.db.updateOne({ guildId: message.guildId }, { $set: { verificationPanels: panels } });

        const container = new ContainerBuilder();
        container.addTextDisplayComponents(td => td.setContent('# ✅ Panel Eliminado'));
        container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
        container.addTextDisplayComponents(td => td.setContent(`Panel \`${panelId}\` eliminado correctamente.`));

        await message.reply({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
            allowedMentions: { repliedUser: false },
        });
    },
};
