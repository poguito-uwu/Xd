import { SlashCommandBuilder, MessageFlags } from 'discord.js';
import { ensureGlobalData, ensureGuildLeveling } from '../../../utils/leveling.js';
import { buildPage } from '../../prefix/Leveling/leaderboard.js';

export default {
	data: new SlashCommandBuilder()
		.setName('leaderboard')
		.setDescription('View the global XP leaderboard')
		.setDMPermission(false),
	async execute(interaction) {
		const guildLeveling = await ensureGuildLeveling(interaction.client.db, interaction.guildId);
		if (!guildLeveling?.enabled) return interaction.reply({ content: '❌ Leveling is disabled in this server.', ephemeral: true });
		const globalData = await ensureGlobalData(interaction.client.db);
		const panel      = buildPage(globalData, 0, interaction.user.id, interaction.client.user?.username);
		await interaction.reply({ components: [panel], flags: MessageFlags.IsComponentsV2 });
	},
	components: []
};
