import { SlashCommandBuilder, ContainerBuilder, SeparatorSpacingSize, ButtonBuilder, ButtonStyle, ActionRowBuilder, MessageFlags } from 'discord.js';
import { ensureGlobalData, ensureMember } from '../../../utils/leveling.js';
import { buildPanel } from '../../prefix/Leveling/rankcard.js';

export default {
	data: new SlashCommandBuilder()
		.setName('rankcard')
		.setDescription('Customize your rank card appearance')
		.setDMPermission(false),
	async execute(interaction) {
		const gd    = await ensureGlobalData(interaction.client.db);
		const state = ensureMember(gd, interaction.user.id);
		await interaction.reply({ components: [buildPanel(state, interaction.user.id)], flags: MessageFlags.IsComponentsV2 });
	},
	components: []
};
