import { SlashCommandBuilder, MessageFlags } from 'discord.js';
import { ensureGuildLeveling } from '../../../utils/leveling.js';
import { buildDashboard } from '../../prefix/Leveling/leveling.js';

export default {
	data: new SlashCommandBuilder()
		.setName('leveling')
		.setDescription('Configure level-up announcements for this server')
		.setDefaultMemberPermissions(1 << 5)
		.setDMPermission(false),
	async execute(interaction) {
		if (!interaction.memberPermissions.has('ManageGuild') && !interaction.memberPermissions.has('Administrator'))
			return interaction.reply({ content: '❌ Manage Server required.', ephemeral: true });
		const leveling = await ensureGuildLeveling(interaction.client.db, interaction.guildId);
		await interaction.reply({ components: [buildDashboard(leveling, interaction.user.id)], flags: MessageFlags.IsComponentsV2 });
	},
	components: []
};
