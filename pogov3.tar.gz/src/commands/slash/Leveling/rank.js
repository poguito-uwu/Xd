import { SlashCommandBuilder } from 'discord.js';
import { ensureGlobalData, ensureGuildLeveling, getMemberSnapshot, xpToNextLevel, getRankPosition } from '../../../utils/leveling.js';
import { renderRankCard } from '../../../utils/rankCard.js';

export default {
	data: new SlashCommandBuilder()
		.setName('rank')
		.setDescription('View your global rank card')
		.setDMPermission(false)
		.addUserOption(o => o.setName('user').setDescription('User to check').setRequired(false)),
	async execute(interaction) {
		const guildLeveling = await ensureGuildLeveling(interaction.client.db, interaction.guildId);
		if (!guildLeveling?.enabled) return interaction.reply({ content: '❌ Leveling is disabled in this server.', ephemeral: true });
		await interaction.deferReply();
		const target        = interaction.options.getUser('user') || interaction.user;
		const globalData    = await ensureGlobalData(interaction.client.db);
		const state         = getMemberSnapshot(globalData, target.id);
		const { position }  = getRankPosition(globalData, target.id);
		const nextXp        = xpToNextLevel(state.level);
		const rc            = state.rankCard || {};
		const buffer        = await renderRankCard({ user: target, state, position, nextXp, accentColor: rc.accentColor || '#7c3aed', bannerUrl: rc.bannerUrl || null });
		if (buffer) await interaction.editReply({ files: [{ attachment: buffer, name: 'rank.png' }] });
		else        await interaction.editReply({ content: '❌ Failed to render rank card.' });
	},
	components: []
};
