import { ButtonBuilder, ButtonStyle, ContainerBuilder, MessageFlags, SeparatorSpacingSize, SlashCommandBuilder } from 'discord.js';
import EMOJIS from '../../../utils/emojis.js';
const COMPONENT_IDS = {
  refresh: 'ping:refresh'
};

async function getDbPing(client) {
  try {
    const DatabaseManager = (await import('../../../utils/DatabaseManager.js')).default;
    const start = Date.now();
    await DatabaseManager.ping();
    return { type: 'mysql', ping: Date.now() - start };
  } catch {
    return { type: 'mysql', ping: null };
  }
}

const buildComponentLayout = (client, state = 'active', dbPing = null, dbType = null) => {
  const latency = Math.round(client.ws.ping);
  let dbPingText = dbPing !== null ? `\n**Database** (${dbType}): ${dbPing}ms` : '';
  const container = new ContainerBuilder()
    .addTextDisplayComponents((textDisplay) =>
      textDisplay.setContent(
        state === 'active'
          ? `**${EMOJIS.ping} Current gateway latency: ${latency}ms**${dbPingText}`
          : 'Ping check closed.'
      )
    )
    .addSeparatorComponents((separator) =>
      separator.setSpacing(SeparatorSpacingSize.Small)
    )
    .addActionRowComponents((actionRow) =>
      actionRow.setComponents(
        new ButtonBuilder()
          .setCustomId(COMPONENT_IDS.refresh)
          .setLabel('Refresh')
          .setStyle(ButtonStyle.Primary)
      )
    );

  return [container];
};

export default {
  data: new SlashCommandBuilder()
    .setName('ping')
    .setDescription('Check the bot latency.'),
  async execute(interaction) {
    const { type: dbType, ping: dbPing } = await getDbPing(interaction.client);
    await interaction.reply({
      components: buildComponentLayout(interaction.client, 'active', dbPing, dbType),
      flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
    });
  },
  components: [
    {
      customId: COMPONENT_IDS.refresh,
      async execute(interaction) {
        const { type: dbType, ping: dbPing } = await getDbPing(interaction.client);
        await interaction.update({
          components: buildComponentLayout(interaction.client, 'active', dbPing, dbType),
          flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
        });
      }
    }
  ]
};
