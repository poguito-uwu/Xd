import { ContainerBuilder, MessageFlags, SeparatorSpacingSize, ChannelType, MediaGalleryBuilder, TextDisplayBuilder } from 'discord.js';
import EMOJIS from './emojis.js';

// ─── Global storage ID ───────────────────────────────────────────────────────
export const GLOBAL_ID = '__global_leveling__';

// ─── Fixed global XP config (no longer per-server) ───────────────────────────
export const GLOBAL_XP = {
	text:  { enabled: true, minXp: 15, maxXp: 25 },
	voice: { enabled: true, minXp: 10, maxXp: 20 },
	cooldownMs: 60_000,
};

// ─── Default per-guild leveling config ───────────────────────────────────────
export const DEFAULT_GUILD_LEVELING = {
	enabled: false,
	announce: {
		mode: 'context',      // 'context' | 'channel' | 'dm' | 'none'
		channelId: null,
		template: '{user.mention} just reached level {level}! 🎉',
		message: {}           // rich message override
	},
	ignores: {
		channels: []          // channels where XP is NOT granted in this server
	},
	announceBanner: {         // optional banner shown on level-up cards
		url: null,
		bgColor: '#0f172a'
	}
};

// ─── Default per-user data (stored globally) ─────────────────────────────────
const DEFAULT_MEMBER = (userId) => ({
	userId,
	xp: 0,
	level: 0,
	totalXp: 0,
	lastMessageAt: 0,
	lastVoiceAt: 0,
	muteAnnouncements: false,
	rankCard: {
		bgColor:    '#0f172a',
		accentColor:'#22c55e',
		bannerUrl:  null
	}
});

const cloneGuildDefault = () => JSON.parse(JSON.stringify(DEFAULT_GUILD_LEVELING));

// ─── DB helpers ───────────────────────────────────────────────────────────────

export const ensureGlobalData = async (db) => {
	const row = await db.findOne({ guildId: GLOBAL_ID }) || { guildId: GLOBAL_ID };
	if (!row.members) {
		row.members = {};
		await db.updateOne({ guildId: GLOBAL_ID }, { $set: { members: {} } });
	}
	return row;
};

export const saveGlobalData = async (db, globalData) => {
	await db.updateOne({ guildId: GLOBAL_ID }, { $set: { members: globalData.members } });
};

export const ensureGuildLeveling = async (db, guildId) => {
	const guildData = await db.findOne({ guildId }) || { guildId };
	if (!guildData.leveling) {
		guildData.leveling = cloneGuildDefault();
		await db.updateOne({ guildId }, { $set: { leveling: guildData.leveling } });
	}
	// Migrate: remove legacy fields that no longer belong per-guild
	let dirty = false;
	for (const old of ['xp', 'rewards', 'autoCleanup', 'members', 'leaderboardTitle']) {
		if (old in guildData.leveling) {
			delete guildData.leveling[old];
			dirty = true;
		}
	}
	if (!guildData.leveling.ignores) { guildData.leveling.ignores = { channels: [] }; dirty = true; }
	if (!guildData.leveling.ignores.channels) { guildData.leveling.ignores.channels = []; dirty = true; }
	if (!guildData.leveling.announceBanner) { guildData.leveling.announceBanner = { url: null, bgColor: '#0f172a' }; dirty = true; }
	if (dirty) await db.updateOne({ guildId }, { $set: { leveling: guildData.leveling } });
	return guildData.leveling;
};

// Legacy alias used by old imports
export const ensureLevelingConfig = ensureGuildLeveling;

// ─── Member helpers ───────────────────────────────────────────────────────────

export const ensureMember = (globalData, userId) => {
	if (!globalData.members[userId]) {
		globalData.members[userId] = DEFAULT_MEMBER(userId);
	}
	return globalData.members[userId];
};

export const getMemberSnapshot = (globalData, userId) => ensureMember(globalData, userId);

// ─── Leaderboard (global) ─────────────────────────────────────────────────────

export const getLeaderboard = (globalData, limit = 100) => {
	return Object.values(globalData.members || {})
		.sort((a, b) => (b.totalXp || 0) - (a.totalXp || 0) || (b.level || 0) - (a.level || 0))
		.slice(0, limit);
};

export const getRankPosition = (globalData, userId) => {
	const sorted = Object.values(globalData.members || {})
		.sort((a, b) => (b.totalXp || 0) - (a.totalXp || 0));
	const idx = sorted.findIndex(e => e.userId === userId);
	return { position: idx === -1 ? null : idx + 1, total: sorted.length };
};

// ─── XP math ──────────────────────────────────────────────────────────────────

export const xpToNextLevel = (level) => Math.floor(5 * level * level + 50 * level + 100);

const addXp = (memberState, amount) => {
	let gained = Math.max(0, Math.floor(amount));
	if (gained === 0) return { leveledUp: false, levelsGained: 0 };

	memberState.xp    += gained;
	memberState.totalXp += gained;

	let leveledUp = false;
	let levelsGained = 0;

	while (memberState.xp >= xpToNextLevel(memberState.level)) {
		memberState.xp   -= xpToNextLevel(memberState.level);
		memberState.level += 1;
		levelsGained      += 1;
		leveledUp          = true;
	}

	return { leveledUp, levelsGained, gained };
};

const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

// ─── Template renderer ────────────────────────────────────────────────────────

const renderTemplate = (template, ctx) => {
	if (!template || typeof template !== 'string') return `${ctx.userMention} reached level ${ctx.level}!`;
	const map = {
		'{user}':           ctx.userMention,
		'{user.name}':      ctx.userName,
		'{user.tag}':       ctx.userTag,
		'{user.id}':        ctx.userId,
		'{user.mention}':   ctx.userMention,
		'{level}':          String(ctx.level),
		'{xp}':             String(ctx.xp),
		'{totalXp}':        String(ctx.totalXp),
		'{nextLevelXp}':    String(ctx.nextLevelXp),
		'{server}':         ctx.serverName || '',
		'{server.icon}':    ctx.serverIcon || '',
		'{server.members}': String(ctx.serverMembers || 0),
		'{timestamp}':      new Date().toLocaleString(),
	};
	let out = template;
	for (const [k, v] of Object.entries(map)) out = out.split(k).join(v);
	return out.replace(/\\n/g, '\n');
};

// ─── Announcement builder ─────────────────────────────────────────────────────

const buildAnnouncementContainer = (text) => {
	const c = new ContainerBuilder();
	c.addTextDisplayComponents(td => td.setContent(`${EMOJIS.success || '✅'} Level Up!`));
	c.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	c.addTextDisplayComponents(td => td.setContent(text));
	return c;
};

const buildRichAnnouncement = (guildLeveling, ctx) => {
	const msg = guildLeveling.announce?.message || {};
	const rv  = (str) => str ? renderTemplate(str, ctx) : str;

	const hasCustom = msg.content || msg.title || msg.body || msg.thumbnail || msg.footer || msg.image;

	if (!hasCustom) {
		const text = renderTemplate(guildLeveling.announce?.template, ctx);
		return { components: [buildAnnouncementContainer(text)], flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: ['users'] } };
	}

	const container = new ContainerBuilder();

	if (msg.title) {
		container.addTextDisplayComponents(td => td.setContent(`**${rv(msg.title)}**`));
		container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
	}

	if (msg.body || msg.thumbnail) {
		const thumbUrl = msg.thumbnail ? (rv(msg.thumbnail) || '').trim() : null;
		container.addSectionComponents(section => {
			section.addTextDisplayComponents(td => td.setContent(msg.body ? rv(msg.body) : '\u200b'));
			if (thumbUrl?.startsWith('http')) section.setThumbnailAccessory(t => t.setURL(thumbUrl));
			return section;
		});
	} else if (msg.body) {
		container.addTextDisplayComponents(td => td.setContent(rv(msg.body)));
	}

	if (msg.image) {
		const imgUrl = (rv(msg.image) || '').trim();
		if (imgUrl?.startsWith('http')) {
			container.addMediaGalleryComponents(new MediaGalleryBuilder().addItems(i => i.setURL(imgUrl)));
		}
	}

	if (msg.footer) {
		container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
		container.addTextDisplayComponents(td => td.setContent(`-# ${rv(msg.footer)}`));
	}

	const payload = { flags: MessageFlags.IsComponentsV2, allowedMentions: { parse: ['users'] } };
	const components = [];
	if (msg.content) components.push(new TextDisplayBuilder().setContent(rv(msg.content)));
	components.push(container);
	payload.components = components;
	return payload;
};

// ─── Voice session tracker ────────────────────────────────────────────────────

const voiceSessions = new Map();

// ─── Message XP ───────────────────────────────────────────────────────────────

export const handleMessageXp = async (client, message) => {
	if (!client?.db) return;
	const guildId = message.guildId;

	const guildLeveling = await ensureGuildLeveling(client.db, guildId);
	if (!guildLeveling?.enabled) return;

	// Check ignored channels
	if (guildLeveling.ignores.channels?.includes(message.channelId)) return;

	// Ignore bot commands
	if (!GLOBAL_XP.text.enabled) return;
	if (client.prefix && message.content?.startsWith?.(client.prefix)) return;

	// Load global data
	const globalData = await ensureGlobalData(client.db);
	const memberState = ensureMember(globalData, message.author.id);

	const now = Date.now();
	if (now - (memberState.lastMessageAt || 0) < GLOBAL_XP.cooldownMs) return;

	const xpGain = rand(GLOBAL_XP.text.minXp, GLOBAL_XP.text.maxXp);
	const result = addXp(memberState, xpGain);
	memberState.lastMessageAt = now;

	await saveGlobalData(client.db, globalData);

	if (!result.leveledUp || memberState.muteAnnouncements) return;

	const ctx = {
		userMention:   `<@${message.author.id}>`,
		userName:      message.author.username,
		userTag:       message.author.tag,
		userId:        message.author.id,
		userAvatar:    message.author.displayAvatarURL({ size: 512 }),
		level:         memberState.level,
		xp:            memberState.xp,
		totalXp:       memberState.totalXp,
		nextLevelXp:   xpToNextLevel(memberState.level),
		serverName:    message.guild?.name || '',
		serverIcon:    message.guild?.iconURL({ size: 512 }) || '',
		serverMembers: message.guild?.memberCount || 0,
	};

	const payload = buildRichAnnouncement(guildLeveling, ctx);
	const mode    = guildLeveling.announce?.mode || 'context';
	try {
		if (mode === 'none') return;
		if (mode === 'dm') { await message.author.send(payload).catch(() => {}); return; }
		if (mode === 'channel') {
			const ch = guildLeveling.announce?.channelId
				? await message.client.channels.fetch(guildLeveling.announce.channelId).catch(() => null)
				: null;
			if (ch?.isTextBased()) { await ch.send(payload).catch(() => {}); return; }
		}
		await message.channel.send(payload).catch(() => {});
	} catch (err) {
		console.error('[Leveling] level-up message failed:', err);
	}
};

// ─── Voice XP ─────────────────────────────────────────────────────────────────

const endVoiceSession = async (client, guildId, userId, now, channelId, member) => {
	const key     = `${guildId}:${userId}`;
	const session = voiceSessions.get(key);
	if (!session) return;
	voiceSessions.delete(key);

	const minutes = Math.floor((now - session.startedAt) / 60_000);
	if (minutes <= 0) return;

	const guildLeveling = await ensureGuildLeveling(client.db, guildId);
	if (!guildLeveling?.enabled || !GLOBAL_XP.voice.enabled) return;
	if (guildLeveling.ignores.channels?.includes(session.channelId)) return;

	const globalData  = await ensureGlobalData(client.db);
	const memberState = ensureMember(globalData, userId);
	const xpGain      = minutes * rand(GLOBAL_XP.voice.minXp, GLOBAL_XP.voice.maxXp);
	const result      = addXp(memberState, xpGain);
	memberState.lastVoiceAt = now;

	await saveGlobalData(client.db, globalData);

	if (!result.leveledUp || memberState.muteAnnouncements) return;

	const memberUser = member?.user;
	const guild      = member?.guild;
	const ctx = {
		userMention:   `<@${userId}>`,
		userName:      memberUser?.username || 'Member',
		userTag:       memberUser?.tag || memberUser?.username || 'member',
		userId,
		userAvatar:    memberUser?.displayAvatarURL?.({ size: 512 }) || '',
		level:         memberState.level,
		xp:            memberState.xp,
		totalXp:       memberState.totalXp,
		nextLevelXp:   xpToNextLevel(memberState.level),
		serverName:    guild?.name || '',
		serverIcon:    guild?.iconURL?.({ size: 512 }) || '',
		serverMembers: guild?.memberCount || 0,
	};

	const payload = buildRichAnnouncement(guildLeveling, ctx);
	const mode    = guildLeveling.announce?.mode || 'context';
	try {
		if (mode === 'none') return;
		if (mode === 'dm') {
			const user = await client.users.fetch(userId).catch(() => null);
			if (user) await user.send(payload).catch(() => {});
			return;
		}
		if (mode === 'channel') {
			const targetId = guildLeveling.announce?.channelId;
			const ch = targetId ? await client.channels.fetch(targetId).catch(() => null) : null;
			if (ch?.isTextBased()) { await ch.send(payload).catch(() => {}); return; }
		}
		const ch = channelId ? await client.channels.fetch(channelId).catch(() => null) : null;
		if (ch?.isTextBased()) await ch.send(payload).catch(() => {});
	} catch (err) {
		console.error('[Leveling] voice level-up message failed:', err);
	}
};

export const handleVoiceStateUpdate = async (client, oldState, newState) => {
	if (!client?.db) return;
	const user = newState?.member?.user || oldState?.member?.user;
	if (!user || user.bot) return;

	const guildId      = newState?.guild?.id || oldState?.guild?.id;
	const oldChannelId = oldState?.channelId;
	const newChannelId = newState?.channelId;
	const now          = Date.now();

	const channelType = newState?.channel?.type ?? oldState?.channel?.type;
	if (channelType && ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channelType)) return;

	const key = `${guildId}:${user.id}`;

	if (!oldChannelId && newChannelId) {
		voiceSessions.set(key, { startedAt: now, channelId: newChannelId });
		return;
	}
	if (oldChannelId && !newChannelId) {
		await endVoiceSession(client, guildId, user.id, now, oldChannelId, oldState?.member || newState?.member);
		return;
	}
	if (oldChannelId && newChannelId && oldChannelId !== newChannelId) {
		await endVoiceSession(client, guildId, user.id, now, oldChannelId, oldState?.member || newState?.member);
		voiceSessions.set(key, { startedAt: now, channelId: newChannelId });
	}
};
