import { createCanvas, loadImage } from '@napi-rs/canvas';

const W = 800;
const H = 200;

// ── Rounded rect path ─────────────────────────────────────────────────────────
const roundRect = (ctx, x, y, w, h, r) => {
	r = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.lineTo(x + w - r, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + r);
	ctx.lineTo(x + w, y + h - r);
	ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
	ctx.lineTo(x + r, y + h);
	ctx.quadraticCurveTo(x, y + h, x, y + h - r);
	ctx.lineTo(x, y + r);
	ctx.quadraticCurveTo(x, y, x + r, y);
	ctx.closePath();
};

// ── Circle clip helper ────────────────────────────────────────────────────────
const clipCircle = (ctx, cx, cy, r) => {
	ctx.beginPath();
	ctx.arc(cx, cy, r, 0, Math.PI * 2);
	ctx.closePath();
	ctx.clip();
};

/**
 * Renders a Nekotina-style rank card.
 *
 * @param {object} opts
 * @param {import('discord.js').User} opts.user
 * @param {object}  opts.state         - { xp, level, totalXp }
 * @param {number}  opts.position      - global rank number
 * @param {number}  opts.nextXp        - XP needed for next level
 * @param {string}  [opts.accentColor] - hex, default purple
 * @param {string}  [opts.bgColor]     - hex fallback bg
 * @param {string}  [opts.bannerUrl]   - custom banner image URL
 */
export async function renderRankCard({
	user,
	state,
	position,
	nextXp,
	accentColor = '#7c3aed',
	bgColor     = '#0f0f14',
	bannerUrl   = null,
}) {
	const canvas = createCanvas(W, H);
	const ctx    = canvas.getContext('2d');

	// ── 1. BACKGROUND (banner or gradient) ────────────────────────────────────
	ctx.save();
	roundRect(ctx, 0, 0, W, H, 16);
	ctx.clip();

	if (bannerUrl) {
		try {
			const img = await loadImage(bannerUrl);
			// Cover-fit: scale so image fills card, crop excess
			const scale = Math.max(W / img.width, H / img.height);
			const sw    = img.width  * scale;
			const sh    = img.height * scale;
			ctx.drawImage(img, (W - sw) / 2, (H - sh) / 2, sw, sh);
		} catch {
			_drawFallbackBg(ctx, bgColor);
		}
	} else {
		_drawFallbackBg(ctx, bgColor);
	}
	ctx.restore();

	// ── 2. DARK OVERLAYS ──────────────────────────────────────────────────────
	ctx.save();
	roundRect(ctx, 0, 0, W, H, 16);
	ctx.clip();

	// Left-side dark vignette (so avatar+text area is always readable)
	const leftGrad = ctx.createLinearGradient(0, 0, 420, 0);
	leftGrad.addColorStop(0,   'rgba(8,8,18,0.92)');
	leftGrad.addColorStop(0.55,'rgba(8,8,18,0.70)');
	leftGrad.addColorStop(1,   'rgba(8,8,18,0.00)');
	ctx.fillStyle = leftGrad;
	ctx.fillRect(0, 0, W, H);

	// Bottom stats panel dark strip
	const STATS_H  = 58;
	const STATS_Y  = H - STATS_H;
	const botGrad  = ctx.createLinearGradient(0, STATS_Y - 20, 0, H);
	botGrad.addColorStop(0, 'rgba(5,5,15,0.00)');
	botGrad.addColorStop(1, 'rgba(5,5,15,0.97)');
	ctx.fillStyle = botGrad;
	ctx.fillRect(0, STATS_Y - 20, W, STATS_H + 20);

	ctx.restore();

	// ── 3. AVATAR ─────────────────────────────────────────────────────────────
	const AV_R  = 52;       // radius
	const AV_CX = 20 + AV_R; // center X
	const AV_CY = H / 2 - 14; // center Y (shift up slightly, stats below center)

	// Accent ring
	ctx.save();
	ctx.beginPath();
	ctx.arc(AV_CX, AV_CY, AV_R + 4, 0, Math.PI * 2);
	ctx.fillStyle = accentColor;
	ctx.fill();
	ctx.restore();

	// Dark gap ring
	ctx.save();
	ctx.beginPath();
	ctx.arc(AV_CX, AV_CY, AV_R + 2, 0, Math.PI * 2);
	ctx.fillStyle = 'rgba(5,5,15,0.95)';
	ctx.fill();
	ctx.restore();

	// Avatar image
	try {
		const avatarUrl = user.displayAvatarURL({ size: 256, extension: 'png' });
		const avatar    = await loadImage(avatarUrl);
		ctx.save();
		clipCircle(ctx, AV_CX, AV_CY, AV_R);
		ctx.drawImage(avatar, AV_CX - AV_R, AV_CY - AV_R, AV_R * 2, AV_R * 2);
		ctx.restore();
	} catch { /* skip avatar on error */ }

	// ── 4. USERNAME ───────────────────────────────────────────────────────────
	const TEXT_X   = AV_CX + AV_R + 20;
	const NAME_Y   = AV_CY - 16;
	const XP_BAR_Y = NAME_Y + 30;

	ctx.fillStyle = '#ffffff';
	ctx.font      = 'bold 26px "Segoe UI", Arial, sans-serif';
	ctx.fillText(truncate(ctx, user.username || 'User', 300), TEXT_X, NAME_Y);

	// ── 5. XP COUNTER (top-right) ─────────────────────────────────────────────
	const progress = Math.max(0, Math.min(1, (state.xp || 0) / Math.max(1, nextXp)));
	const xpStr    = `${Math.floor(state.xp).toLocaleString()} / ${nextXp.toLocaleString()} XP`;
	ctx.font       = '14px "Segoe UI", Arial, sans-serif';
	ctx.fillStyle  = 'rgba(255,255,255,0.75)';
	ctx.textAlign  = 'right';
	ctx.fillText(xpStr, W - 18, NAME_Y - 2);
	ctx.textAlign  = 'left';

	// ── 6. XP PROGRESS BAR ────────────────────────────────────────────────────
	const BAR_X = TEXT_X;
	const BAR_W = W - TEXT_X - 18;
	const BAR_H = 8;

	// Track
	ctx.fillStyle = 'rgba(255,255,255,0.10)';
	roundRect(ctx, BAR_X, XP_BAR_Y, BAR_W, BAR_H, BAR_H / 2);
	ctx.fill();

	// Fill
	if (progress > 0) {
		const fillW = Math.max(BAR_H, BAR_W * progress);
		const barGrad = ctx.createLinearGradient(BAR_X, 0, BAR_X + fillW, 0);
		barGrad.addColorStop(0, accentColor);
		barGrad.addColorStop(1, _lighten(accentColor, 40));
		ctx.fillStyle = barGrad;
		roundRect(ctx, BAR_X, XP_BAR_Y, fillW, BAR_H, BAR_H / 2);
		ctx.fill();
	}

	// ── 7. STATS ROW ──────────────────────────────────────────────────────────
	const stats = [
		{ label: 'RANK',    value: `#${position ?? '?'}` },
		{ label: 'LEVEL',   value: String(state.level ?? 0) },
		{ label: 'EXP',     value: abbreviate(state.xp ?? 0) },
		{ label: 'TOTAL XP',value: abbreviate(state.totalXp ?? 0) },
	];

	const STAT_Y   = H - STATS_H + 6;
	const colW     = W / stats.length;

	stats.forEach((s, i) => {
		const cx = colW * i + colW / 2;

		// Label (purple, small caps)
		ctx.font      = 'bold 11px "Segoe UI", Arial, sans-serif';
		ctx.fillStyle = accentColor;
		ctx.textAlign = 'center';
		ctx.fillText(s.label.toUpperCase(), cx, STAT_Y + 14);

		// Value (white, large)
		ctx.font      = 'bold 22px "Segoe UI", Arial, sans-serif';
		ctx.fillStyle = '#ffffff';
		ctx.fillText(s.value, cx, STAT_Y + 38);
	});

	ctx.textAlign = 'left';

	return canvas.toBuffer('image/png');
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function _drawFallbackBg(ctx, hex) {
	const g = ctx.createLinearGradient(0, 0, W, H);
	g.addColorStop(0, hex);
	g.addColorStop(1, _darken(hex, 30));
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, W, H);
}

function truncate(ctx, text, maxWidth) {
	if (ctx.measureText(text).width <= maxWidth) return text;
	while (text.length > 1 && ctx.measureText(text + '…').width > maxWidth) text = text.slice(0, -1);
	return text + '…';
}

function abbreviate(n) {
	n = Math.floor(n || 0);
	if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
	if (n >= 1_000)     return (n / 1_000).toFixed(1).replace(/\.0$/, '') + 'K';
	return n.toLocaleString();
}

function _lighten(hex, amount) {
	return _shiftColor(hex, amount);
}
function _darken(hex, amount) {
	return _shiftColor(hex, -amount);
}
function _shiftColor(hex, amount) {
	const n = parseInt(hex.replace('#', ''), 16);
	const r = Math.min(255, Math.max(0, (n >> 16) + amount));
	const g = Math.min(255, Math.max(0, ((n >> 8) & 0xff) + amount));
	const b = Math.min(255, Math.max(0, (n & 0xff) + amount));
	return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}
