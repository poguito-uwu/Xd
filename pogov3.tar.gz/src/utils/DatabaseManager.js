import mysql from 'mysql2/promise';

class DatabaseManager {
	constructor() {
		this.type = 'mysql';
		this.pool = null;
		this.cache = new Map();
		this.cacheTTL = 30000;
	}

	async initialize() {
		await this.initializeMySQL();
		console.log('✅ Using MySQL');
	}

	async initializeMySQL() {
		const poolConfig = process.env.DATABASE_URL
			? { uri: process.env.DATABASE_URL }
			: {
				host:     process.env.DB_HOST     || 'localhost',
				port:     parseInt(process.env.DB_PORT) || 3306,
				database: process.env.DB_NAME     || 'ares_bot',
				user:     process.env.DB_USER     || 'root',
				password: process.env.DB_PASSWORD || '',
				ssl:      process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
				waitForConnections: true,
				connectionLimit:    10,
				queueLimit:         0,
			};

		this.pool = mysql.createPool(poolConfig);

		// verify connection
		const conn = await this.pool.getConnection();
		conn.release();

		await this.createMySQLTables();
	}

	async createMySQLTables() {
		const queries = [
			`CREATE TABLE IF NOT EXISTS guilds (
				guildId   VARCHAR(255) PRIMARY KEY,
				data      JSON         NOT NULL,
				createdAt DATETIME     DEFAULT CURRENT_TIMESTAMP,
				updatedAt DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
			)`,
			`CREATE TABLE IF NOT EXISTS moderation (
				id          INT AUTO_INCREMENT PRIMARY KEY,
				guildId     VARCHAR(255) NOT NULL,
				userId      VARCHAR(255) NOT NULL,
				moderatorId VARCHAR(255) NOT NULL,
				action      VARCHAR(50)  NOT NULL,
				reason      TEXT,
				timestamp   DATETIME     DEFAULT CURRENT_TIMESTAMP,
				FOREIGN KEY (guildId) REFERENCES guilds(guildId)
			)`,
		];

		for (const query of queries) {
			try {
				await this.pool.query(query);
			} catch (error) {
				if (!error.message.includes('Duplicate key name')) {
					console.error('Error creating MySQL table:', error.message);
				}
			}
		}

		// Indexes (separate to avoid errors if they already exist)
		const indexes = [
			`CREATE INDEX idx_moderation_guild ON moderation(guildId)`,
			`CREATE INDEX idx_moderation_user  ON moderation(userId)`,
		];
		for (const idx of indexes) {
			try { await this.pool.query(idx); } catch (_) { /* already exists */ }
		}
	}

	getType() {
		return this.type;
	}

	// ─── Nested helpers ──────────────────────────────────────────────────────

	_getNestedValue(obj, path) {
		return path.split('.').reduce((cur, part) => {
			if (cur === undefined || cur === null) return 0;
			return cur[part];
		}, obj) ?? 0;
	}

	_setNestedValue(obj, path, value) {
		const parts = path.split('.');
		let cursor = obj;
		for (let i = 0; i < parts.length; i++) {
			const part = parts[i];
			if (i === parts.length - 1) {
				cursor[part] = value;
			} else {
				if (typeof cursor[part] !== 'object' || cursor[part] === null) cursor[part] = {};
				cursor = cursor[part];
			}
		}
	}

	_deleteNestedValue(obj, path) {
		const parts = path.split('.');
		let cursor = obj;
		for (let i = 0; i < parts.length; i++) {
			const part = parts[i];
			if (i === parts.length - 1) {
				if (cursor && Object.prototype.hasOwnProperty.call(cursor, part)) delete cursor[part];
			} else {
				if (!cursor || typeof cursor[part] !== 'object') break;
				cursor = cursor[part];
			}
		}
	}

	// ─── Public API ──────────────────────────────────────────────────────────

	async findOne(collection, filter) {
		const cacheKey = `${collection}:${filter.guildId}`;
		const cached = this.cache.get(cacheKey);
		if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
			return cached.data;
		}

		try {
			const [rows] = await this.pool.query(
				`SELECT data FROM \`${collection}\` WHERE guildId = ?`,
				[filter.guildId]
			);
			if (rows.length === 0) return null;

			const result = typeof rows[0].data === 'string'
				? JSON.parse(rows[0].data)
				: rows[0].data;

			this.cache.set(cacheKey, { data: result, timestamp: Date.now() });
			return result;
		} catch (error) {
			console.error('MySQL findOne error:', error.message);
			return null;
		}
	}

	async updateOne(collection, filter, update) {
		const cacheKey = `${collection}:${filter.guildId}`;
		this.cache.delete(cacheKey);

		try {
			const [rows] = await this.pool.query(
				`SELECT data FROM \`${collection}\` WHERE guildId = ?`,
				[filter.guildId]
			);

			let existing = {};
			if (rows.length > 0) {
				existing = typeof rows[0].data === 'string'
					? JSON.parse(rows[0].data)
					: rows[0].data;
			}

			const setOps   = update.$set   || {};
			const unsetOps = update.$unset  || {};
			const incOps   = update.$inc    || {};
			let merged = { ...existing };

			for (const key of Object.keys(incOps)) {
				this._setNestedValue(merged, key, this._getNestedValue(merged, key) + incOps[key]);
			}
			for (const key of Object.keys(setOps)) {
				this._setNestedValue(merged, key, setOps[key]);
			}
			for (const key of Object.keys(unsetOps)) {
				this._deleteNestedValue(merged, key);
			}
			if (!update.$set && !update.$unset && !update.$inc) {
				merged = { ...existing, ...update };
			}

			await this.pool.query(
				`INSERT INTO \`${collection}\` (guildId, data)
				 VALUES (?, ?)
				 ON DUPLICATE KEY UPDATE data = VALUES(data), updatedAt = CURRENT_TIMESTAMP`,
				[filter.guildId, JSON.stringify(merged)]
			);

			return { ok: 1, modifiedCount: 1 };
		} catch (error) {
			console.error('MySQL updateOne error:', error.message);
			return { ok: 0 };
		}
	}

	getGuilds() {
		return {
			findOne:   (filter)         => this.findOne('guilds', filter),
			updateOne: (filter, update) => this.updateOne('guilds', filter, update),
		};
	}

	async ping() {
		const start = performance.now();
		try {
			await this.pool.query('SELECT 1');
			return Math.round(performance.now() - start);
		} catch {
			return -1;
		}
	}

	/** Expose raw pool for advanced use (dashboard, migration) */
	getPool() {
		return this.pool;
	}
}

export default new DatabaseManager();
