import { createCanvas, loadImage } from '@napi-rs/canvas';

const W = 1200;
const H = 400;

// ── Helper: rounded rect path ────────────────────────────────────────────────
const roundRect = (ctx, x, y, w, h, r) => {
	r = Math.min(r, w / 2, h / 2);
	ctx.beginPath();
	ctx.moveTo(x + r, y);
	ctx.lineTo(x + w - r, y);
	ctx.quadraticCurveTo(x + w, y, x + w, y + r);
	ctx.lineTo(x + w, y + h - r);
	ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
	ctx.lineTo(x + r, y + h);
	ctx.quadraticCurveTo(x, y + h, x, y + h - r);
	ctx.lineTo(x, y + r);
	ctx.quadraticCurveTo(x, y, x + r, y);
	ctx.closePath();
};

// ── Draw the subtle grid overlay ─────────────────────────────────────────────
const drawGrid = (ctx) => {
	ctx.save();
	ctx.strokeStyle = 'rgba(255,255,255,0.04)';
	ctx.lineWidth   = 1;
	const CELL = 40;
	for (let x = 0; x <= W; x += CELL) {
		ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
	}
	for (let y = 0; y <= H; y += CELL) {
		ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
	}
	ctx.restore();
};

/**
 * Renders the POGO-style welcome banner.
 *
 * @param {object} opts
 * @param {import('discord.js').GuildMember} opts.member
 * @param {string}  [opts.accentColor='#4f6ef7']  – ring + underline color
 * @param {string}  [opts.bgColor='#0d1117']       – background color
 * @param {string}  [opts.bannerUrl]               – custom background image
 * @param {string}  [opts.botTag='POGO']           – label in top-right corner
 */
export async function renderWelcomeBanner({
	member,
	accentColor = '#4f6ef7',
	bgColor     = '#0d1117',
	bannerUrl   = null,
	botTag      = 'POGO',
}) {
	const canvas = createCanvas(W, H);
	const ctx    = canvas.getContext('2d');

	// ── 1. BACKGROUND ──────────────────────────────────────────────────────────
	ctx.save();
	roundRect(ctx, 0, 0, W, H, 20);
	ctx.clip();

	if (bannerUrl) {
		try {
			const bgImg = await loadImage(bannerUrl);
			const scale = Math.max(W / bgImg.width, H / bgImg.height);
			const bw = bgImg.width  * scale;
			const bh = bgImg.height * scale;
			ctx.drawImage(bgImg, (W - bw) / 2, (H - bh) / 2, bw, bh);
			// Dim it significantly so text is readable
			ctx.fillStyle = 'rgba(10,12,22,0.78)';
			ctx.fillRect(0, 0, W, H);
		} catch {
			_solidBg(ctx, bgColor);
		}
	} else {
		_solidBg(ctx, bgColor);
	}

	// Grid overlay
	drawGrid(ctx);
	ctx.restore();

	// ── 2. TOP-RIGHT BRAND TAG ────────────────────────────────────────────────
	const TAG_X = W - 24;
	const TAG_Y = 48;

	ctx.fillStyle = '#ffffff';
	ctx.font      = 'bold 38px "Segoe UI", Arial, sans-serif';
	ctx.textAlign = 'right';
	ctx.fillText(botTag, TAG_X, TAG_Y);

	// Accent underline beneath the tag
	const tagMeasure = ctx.measureText(botTag);
	const lineW      = tagMeasure.width;
	const lineY      = TAG_Y + 8;
	ctx.fillStyle    = accentColor;
	ctx.fillRect(TAG_X - lineW, lineY, lineW, 3);
	ctx.textAlign    = 'left';

	// ── 3. AVATAR ─────────────────────────────────────────────────────────────
	const AV_R  = 90;
	const AV_CX = 24 + 30 + AV_R;   // left padding + margin + radius
	const AV_CY = H / 2 - 20;        // center-ish, shifted up from bottom strip

	// Outer glow ring
	ctx.save();
	const glow = ctx.createRadialGradient(AV_CX, AV_CY, AV_R + 2, AV_CX, AV_CY, AV_R + 18);
	glow.addColorStop(0, accentColor + 'aa');
	glow.addColorStop(1, accentColor + '00');
	ctx.beginPath();
	ctx.arc(AV_CX, AV_CY, AV_R + 18, 0, Math.PI * 2);
	ctx.fillStyle = glow;
	ctx.fill();
	ctx.restore();

	// Hard accent ring
	ctx.save();
	ctx.beginPath();
	ctx.arc(AV_CX, AV_CY, AV_R + 5, 0, Math.PI * 2);
	ctx.strokeStyle = accentColor;
	ctx.lineWidth   = 4;
	ctx.stroke();
	ctx.restore();

	// Inner dark gap
	ctx.save();
	ctx.beginPath();
	ctx.arc(AV_CX, AV_CY, AV_R + 2, 0, Math.PI * 2);
	ctx.strokeStyle = bgColor;
	ctx.lineWidth   = 4;
	ctx.stroke();
	ctx.restore();

	// Avatar image
	try {
		const avatarUrl = member.user.displayAvatarURL({ size: 256, extension: 'png' });
		const avatar    = await loadImage(avatarUrl);
		ctx.save();
		ctx.beginPath();
		ctx.arc(AV_CX, AV_CY, AV_R, 0, Math.PI * 2);
		ctx.closePath();
		ctx.clip();
		ctx.drawImage(avatar, AV_CX - AV_R, AV_CY - AV_R, AV_R * 2, AV_R * 2);
		ctx.restore();
	} catch { /* avatar unavailable */ }

	// ── 4. TEXT BLOCK ─────────────────────────────────────────────────────────
	const TEXT_X = AV_CX + AV_R + 60;
	const TEXT_Y = AV_CY - 60;

	// "IDENTIFIED ACCESS" label
	ctx.font      = 'italic bold 20px "Segoe UI", Arial, sans-serif';
	ctx.fillStyle = accentColor;
	ctx.fillText('IDENTIFIED ACCESS', TEXT_X, TEXT_Y);

	// "Welcome" heading
	ctx.font      = 'bold 80px "Segoe UI", Arial, sans-serif';
	ctx.fillStyle = '#ffffff';
	ctx.fillText('Welcome', TEXT_X, TEXT_Y + 90);

	// Username
	ctx.font      = '32px "Segoe UI", Arial, sans-serif';
	ctx.fillStyle = 'rgba(255,255,255,0.85)';
	const uname   = _truncate(ctx, member.user.username, W - TEXT_X - 40);
	ctx.fillText(uname, TEXT_X + 2, TEXT_Y + 140);

	// ── 5. BOTTOM INFO STRIP ──────────────────────────────────────────────────
	const STRIP_H  = 52;
	const STRIP_Y  = H - STRIP_H - 24;
	const STRIP_W  = W - TEXT_X - 40;
	const STRIP_R  = 10;

	ctx.fillStyle = 'rgba(255,255,255,0.07)';
	roundRect(ctx, TEXT_X, STRIP_Y, STRIP_W, STRIP_H, STRIP_R);
	ctx.fill();

	// MEMBER # label + value
	const memberNum = member.guild.memberCount;
	ctx.font      = 'bold 16px "Segoe UI", Arial, sans-serif';
	ctx.fillStyle = accentColor;
	ctx.fillText('MEMBER', TEXT_X + 24, STRIP_Y + 20);

	ctx.font      = 'bold 18px "Segoe UI", Arial, sans-serif';
	ctx.fillStyle = '#ffffff';
	ctx.fillText(`#${memberNum}`, TEXT_X + 24, STRIP_Y + 40);

	// DATE value
	const now       = new Date();
	const dateStr   = `${String(now.getDate()).padStart(2,'0')}/${String(now.getMonth()+1).padStart(2,'0')}/${now.getFullYear()}`;
	const DATE_LABEL_X = TEXT_X + STRIP_W / 2 + 20;

	ctx.font      = 'bold 14px "Segoe UI", Arial, sans-serif';
	ctx.fillStyle = 'rgba(255,255,255,0.55)';
	ctx.fillText('DATE', DATE_LABEL_X, STRIP_Y + 20);

	ctx.font      = 'bold 18px "Segoe UI", Arial, sans-serif';
	ctx.fillStyle = 'rgba(255,255,255,0.85)';
	ctx.fillText(dateStr, DATE_LABEL_X, STRIP_Y + 40);

	return canvas.toBuffer('image/png');
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function _solidBg(ctx, hex) {
	const g = ctx.createLinearGradient(0, 0, W, H);
	g.addColorStop(0, hex);
	g.addColorStop(1, _darken(hex, 20));
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, W, H);
}

function _truncate(ctx, text, maxW) {
	if (ctx.measureText(text).width <= maxW) return text;
	while (text.length > 1 && ctx.measureText(text + '…').width > maxW) text = text.slice(0, -1);
	return text + '…';
}

function _darken(hex, amount) {
	const n = parseInt(hex.replace('#', ''), 16);
	const r = Math.max(0, (n >> 16) - amount);
	const g = Math.max(0, ((n >> 8) & 0xff) - amount);
	const b = Math.max(0, (n & 0xff) - amount);
	return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}
