import { Router } from 'express';
import { randomUUID } from 'node:crypto';

const DISCORD_API = 'https://discord.com/api/v10';

// In-memory state store (TTL: 10 min). In prod use Redis / DB.
const stateStore = new Map();
const STATE_TTL = 10 * 60 * 1000;

function cleanStates() {
    const now = Date.now();
    for (const [k, v] of stateStore) {
        if (now > v.expiresAt) stateStore.delete(k);
    }
}
setInterval(cleanStates, 5 * 60 * 1000);

async function refreshToken(clientId, clientSecret, refreshTok) {
    const res = await fetch(`${DISCORD_API}/oauth2/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
            client_id:     clientId,
            client_secret: clientSecret,
            grant_type:    'refresh_token',
            refresh_token: refreshTok,
        }),
    });
    if (!res.ok) return null;
    return res.json();
}

async function pushRoleMetadata(clientId, accessToken, username, metadata = {}) {
    const res = await fetch(
        `${DISCORD_API}/users/@me/applications/${clientId}/role-connection`,
        {
            method: 'PUT',
            headers: {
                Authorization:  `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                platform_name:     'Pogo Verification',
                platform_username: username,
                metadata,
            }),
        }
    );
    if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(`Discord API ${res.status}: ${JSON.stringify(err)}`);
    }
}

async function addUserToSupportGuild(guildId, userId, userAccessToken, botToken) {
    const res = await fetch(`${DISCORD_API}/guilds/${guildId}/members/${userId}`, {
        method: 'PUT',
        headers: {
            Authorization:  `Bot ${botToken}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            access_token: userAccessToken,
        }),
    });

    if (res.status !== 201 && res.status !== 204) {
        const error = await res.json().catch(() => ({}));
        throw new Error(`Failed to add user to support guild: ${res.status} - ${JSON.stringify(error)}`);
    }

    return res.status;
}

async function sendVerificationDM(botToken, userId, guildName, inviteUrl) {
    const channelRes = await fetch(`${DISCORD_API}/users/@me/channels`, {
        method: 'POST',
        headers: {
            Authorization:  `Bot ${botToken}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ recipient_id: userId }),
    });

    if (!channelRes.ok) {
        const e = await channelRes.json().catch(() => ({}));
        throw new Error(`Failed to create DM channel: ${channelRes.status} - ${JSON.stringify(e)}`);
    }

    const channel = await channelRes.json();

    const messageRes = await fetch(`${DISCORD_API}/channels/${channel.id}/messages`, {
        method: 'POST',
        headers: {
            Authorization:  `Bot ${botToken}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            embeds: [
                {
                    color: 0x57F287,
                    title: '✅ ¡Verificación completada!',
                    description: `Has sido verificado correctamente.`,
                    fields: [
                        {
                            name: '¿Qué significa esto?',
                            value: 'Tu identidad ha sido confirmada y tienes acceso a los canales verificados del servidor.',
                        },
                    ],
                    footer: { text: 'Alerta de Verificación' },
                    timestamp: new Date().toISOString(),
                },
            ],
            components: inviteUrl
                ? [
                    {
                        type: 1,
                        components: [
                            {
                                type: 2,
                                style: 5,
                                label: '📱 Ir al servidor de soporte',
                                url: inviteUrl,
                            },
                        ],
                    },
                ]
                : [],
        }),
    });

    if (!messageRes.ok) {
        const e = await messageRes.json().catch(() => ({}));
        throw new Error(`Failed to send DM: ${messageRes.status} - ${JSON.stringify(e)}`);
    }

    return messageRes.json();
}

async function createOneTimeInvite(guildId, botToken) {
    const guildRes = await fetch(`${DISCORD_API}/guilds/${guildId}`, {
        headers: { Authorization: `Bot ${botToken}` },
    });

    let channelId = null;

    if (guildRes.ok) {
        const guild = await guildRes.json();
        channelId = guild.system_channel_id;
    }

    if (!channelId) {
        const channelsRes = await fetch(`${DISCORD_API}/guilds/${guildId}/channels`, {
            headers: { Authorization: `Bot ${botToken}` },
        });
        if (channelsRes.ok) {
            const channels = await channelsRes.json();
            const textChannel = channels.find(c => c.type === 0);
            channelId = textChannel?.id;
        }
    }

    if (!channelId) throw new Error('No suitable channel found for invite creation.');

    const res = await fetch(`${DISCORD_API}/channels/${channelId}/invites`, {
        method: 'POST',
        headers: {
            Authorization:  `Bot ${botToken}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            max_age:  3600,
            max_uses: 1,
            unique:   true,
        }),
    });

    if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        throw new Error(`Failed to create invite: ${res.status} - ${JSON.stringify(e)}`);
    }

    const invite = await res.json();
    return `https://discord.gg/${invite.code}`;
}

export function createVerificationRouter(client) {
    const router = Router();

    const clientId         = client.user?.id || process.env.DISCORD_CLIENT_ID;
    const clientSecret     = process.env.DISCORD_CLIENT_SECRET;
    const botToken         = process.env.DISCORD_TOKEN;
    const supportGuildId   = process.env.SUPPORT_GUILD_ID;
    const supportGuildName = process.env.SUPPORT_GUILD_NAME || 'Servidor de Soporte';
    const baseUrl          = process.env.DASHBOARD_URL || `http://localhost:${process.env.DASHBOARD_PORT || 3000}`;
    const redirectUri      = `${baseUrl}/verify/callback`;

    // ── Step 1: Redirect to Discord OAuth ────────────────────────────────────
    router.get('/', (req, res) => {
        const { guild, panel } = req.query;

        if (!guild || !panel) {
            return res.status(400).send(htmlPage('Enlace inválido', 'El enlace de verificación no es válido.', false));
        }

        const state = randomUUID();
        stateStore.set(state, {
            guildId: guild,
            panelId: panel,
            expiresAt: Date.now() + STATE_TTL,
        });

        const params = new URLSearchParams({
            client_id:     clientId,
            redirect_uri:  redirectUri,
            response_type: 'code',
            scope:         'identify role_connections.write guilds.join',
            state,
        });

        res.redirect(`https://discord.com/oauth2/authorize?${params}`);
    });

    // ── Step 2: OAuth callback ────────────────────────────────────────────────
    router.get('/callback', async (req, res) => {
        const { code, state, error } = req.query;

        if (error) {
            return res.send(htmlPage(
                'Verificación cancelada',
                'Cancelaste el proceso de verificación. Puedes cerrar esta ventana.',
                false
            ));
        }

        if (!code || !state || !stateStore.has(state)) {
            return res.status(400).send(htmlPage(
                'Enlace inválido',
                'El enlace expiró o no es válido. Vuelve al servidor e intenta de nuevo.',
                false
            ));
        }

        const ctx = stateStore.get(state);
        stateStore.delete(state);

        try {
            // ── Exchange code for tokens ──
            const tokenRes = await fetch(`${DISCORD_API}/oauth2/token`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    client_id:     clientId,
                    client_secret: clientSecret,
                    grant_type:    'authorization_code',
                    code,
                    redirect_uri:  redirectUri,
                }),
            });

            if (!tokenRes.ok) {
                const e = await tokenRes.json().catch(() => ({}));
                console.error('[Verify] Token exchange failed:', e);
                return res.send(htmlPage(
                    'Error',
                    'Error al obtener tokens de Discord. Intenta de nuevo.',
                    false
                ));
            }

            const tokens = await tokenRes.json();

            // ── Fetch user info ──
            const userRes    = await fetch(`${DISCORD_API}/users/@me`, {
                headers: { Authorization: `Bearer ${tokens.access_token}` },
            });
            const discordUser = await userRes.json();

            const userId      = discordUser.id;
            const username    = discordUser.global_name || discordUser.username;
            const usermention = discordUser.username;
            const avatarHash  = discordUser.avatar;

            // ── Push role metadata ──
            await pushRoleMetadata(clientId, tokens.access_token, username, { verified: 1 });

            // ── Add user to support guild + send DM ──
            let inviteLink = null;

            if (supportGuildId && botToken) {
                try {
                    const addStatus = await addUserToSupportGuild(
                        supportGuildId, userId, tokens.access_token, botToken
                    );
                    const alreadyMember = addStatus === 204;
                    console.log(`[Verify] ${alreadyMember ? 'Already member' : 'Added'}: ${username} (${userId})`);

                    inviteLink = `https://discord.com/channels/${supportGuildId}`;

                } catch (err) {
                    console.error(`[Verify] addUserToSupportGuild failed: ${err.message}`);

                    try {
                        inviteLink = await createOneTimeInvite(supportGuildId, botToken);
                        console.log(`[Verify] Fallback invite created: ${inviteLink}`);
                    } catch (inviteErr) {
                        console.error(`[Verify] createOneTimeInvite failed: ${inviteErr.message}`);
                    }
                }

                try {
                    await sendVerificationDM(botToken, userId, supportGuildName, inviteLink);
                    console.log(`[Verify] DM sent to ${username}`);
                } catch (dmErr) {
                    console.warn(`[Verify] DM failed (user may have DMs disabled): ${dmErr.message}`);
                }
            }

            // ── Assign role in the original verification guild ──
            const guildData = await client.db.findOne({ guildId: ctx.guildId }) || {};
            const panels    = guildData.verificationPanels || [];
            const panel     = panels.find(p => p.id === ctx.panelId);

            if (panel) {
                if (!guildData.verificationTokens) guildData.verificationTokens = {};
                guildData.verificationTokens[userId] = {
                    refreshToken: tokens.refresh_token,
                    updatedAt:    Date.now(),
                };

                const guild  = client.guilds.cache.get(ctx.guildId);
                const member = guild ? await guild.members.fetch(userId).catch(() => null) : null;
                const role   = guild ? guild.roles.cache.get(panel.roleId) : null;

                if (member && role) {
                    const botMember = guild.members.me;
                    if (
                        botMember?.permissions.has('ManageRoles') &&
                        role.position < botMember.roles.highest.position
                    ) {
                        await member.roles.add(role, '[Verify] Linked Roles verificación').catch(() => {});
                    }
                }

                await client.db.updateOne(
                    { guildId: ctx.guildId },
                    { $set: { verificationTokens: guildData.verificationTokens } },
                    { upsert: true }
                );
            }

            // ── Render success page ──
            return res.send(htmlPage(
                '¡Verificado!',
                `✅ <strong>¡Verificación completada exitosamente!</strong><br><br>` +
                `📨 Te enviamos un mensaje directo con más información.<br><br>` +
                `Si el rol no aparece de inmediato, espera unos segundos y recarga Discord.`,
                true,
                userId,
                avatarHash,
                username,
                usermention
            ));

        } catch (err) {
            console.error('[Verify] Callback error:', err);
            return res.send(htmlPage('Error inesperado', escapeHtml(err.message), false));
        }
    });

    return router;
}

// ─── HTML helpers ─────────────────────────────────────────────────────────────

function escapeHtml(str) {
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function htmlPage(
    title,
    message,
    success,
    userId      = null,
    avatarHash  = null,
    username    = 'Pogo',
    usermention = 'pogo_os'
) {
    const accentColor = success ? '#57F287' : '#ED4245';

    let avatarUrl;
    if (avatarHash && userId) {
        const format = avatarHash.startsWith('a_') ? 'gif' : 'png';
        avatarUrl = `https://cdn.discordapp.com/avatars/${userId}/${avatarHash}.${format}?size=256`;
    } else {
        avatarUrl = `https://cdn.discordapp.com/embed/avatars/0.png`;
    }

    const coverUrl = success
        ? 'https://i.ibb.co/rWL2Cq5/25a2b83103724a544acb225a031d2d67.jpg'
        : 'https://i.ibb.co/rWL2Cq5/25a2b83103724a544acb225a031d2d67.jpg';

    return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(title)} — Verificación</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@400;500&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: radial-gradient(ellipse 80% 60% at 50% 0%, #0d1117 0%, #060608 100%);
      font-family: 'DM Sans', ui-sans-serif, system-ui, sans-serif;
      color: #e6e8f0;
      padding: 1.5rem;
    }

    body::before {
      content: '';
      position: fixed;
      inset: 0;
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='0.04'/%3E%3C/svg%3E");
      pointer-events: none;
      z-index: 0;
    }

    .card {
      position: relative;
      z-index: 1;
      width: 100%;
      max-width: 420px;
      background: #0e0e14;
      border-radius: 20px;
      border: 1px solid rgba(255,255,255,0.07);
      box-shadow:
        0 0 0 1px rgba(0,0,0,.6),
        0 24px 64px rgba(0,0,0,.7),
        0 0 80px rgba(${success ? '87,242,135' : '237,66,69'},.06);
      overflow: hidden;
      animation: fadeUp .55s cubic-bezier(.22,1,.36,1) both;
    }

    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(24px) scale(.98); }
      to   { opacity: 1; transform: translateY(0) scale(1); }
    }

    .cover {
      position: relative;
      height: 160px;
      background: url('${coverUrl}') center/cover no-repeat, #0d1117;
      border-radius: 20px 20px 0 0;
    }
    .cover::after {
      content: '';
      position: absolute;
      inset: 0;
      background: linear-gradient(to bottom, rgba(0,0,0,.1) 0%, rgba(0,0,0,.45) 100%);
      border-radius: 20px 20px 0 0;
    }

    .cover-socials {
      position: absolute;
      bottom: 12px;
      right: 14px;
      display: flex;
      gap: 10px;
      z-index: 2;
    }
    .cover-socials a {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 30px; height: 30px;
      background: rgba(255,255,255,.12);
      backdrop-filter: blur(6px);
      border-radius: 50%;
      color: #fff;
      text-decoration: none;
      transition: background .2s;
    }
    .cover-socials a:hover { background: rgba(255,255,255,.25); }
    .cover-socials svg { width: 14px; height: 14px; fill: #fff; }

    .body { padding: 0 1.4rem 1.6rem; }

    .profile-row {
      display: flex;
      align-items: flex-end;
      justify-content: space-between;
      margin-top: -36px;
      margin-bottom: 14px;
    }

    .avatar-wrap { position: relative; flex-shrink: 0; }
    .avatar {
      width: 72px; height: 72px;
      border-radius: 50%;
      border: 3px solid #0e0e14;
      background: url('${avatarUrl}') center/cover no-repeat, #1a1a2e;
      box-shadow: 0 0 0 1px rgba(255,255,255,.08);
      display: block;
    }
    .avatar-wrap::after {
      content: '';
      position: absolute;
      bottom: 3px; right: 3px;
      width: 12px; height: 12px;
      border-radius: 50%;
      background: ${accentColor};
      border: 2px solid #0e0e14;
      box-shadow: 0 0 8px ${accentColor}80;
    }

    .btn-soporte {
      display: inline-flex;
      align-items: center;
      gap: 7px;
      padding: .5rem 1.2rem;
      background: #fff;
      color: #0a0a0f;
      font-family: 'Syne', sans-serif;
      font-weight: 700;
      font-size: .875rem;
      letter-spacing: .02em;
      border-radius: 999px;
      text-decoration: none;
      border: none;
      cursor: pointer;
      transition: opacity .2s, transform .15s;
      white-space: nowrap;
      margin-bottom: 4px;
    }
    .btn-soporte:hover { opacity: .88; transform: scale(.97); }
    .btn-soporte svg { width: 15px; height: 15px; }

    .name-row {
      display: flex;
      align-items: center;
      gap: 6px;
      margin-bottom: 2px;
    }
    .name {
      font-family: 'Syne', sans-serif;
      font-weight: 800;
      font-size: 1.15rem;
      color: #f0f2f8;
      letter-spacing: -.01em;
    }
    .badge-verified {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 18px; height: 18px;
      flex-shrink: 0;
    }
    .badge-verified svg { width: 18px; height: 18px; }

    .handle {
      font-size: .85rem;
      color: #525670;
      text-decoration: none;
      transition: color .15s;
      margin-bottom: 12px;
      display: block;
    }
    .handle:hover { color: #8b90b8; }

    .divider {
      width: 100%;
      height: 1px;
      background: rgba(255,255,255,.06);
      margin: 14px 0;
    }

    .status-label {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      font-size: .7rem;
      font-weight: 600;
      letter-spacing: .08em;
      text-transform: uppercase;
      color: ${accentColor};
      margin-bottom: 8px;
    }
    .status-label svg { width: 12px; height: 12px; }

    .description {
      font-size: .9rem;
      color: #6a6f8f;
      line-height: 1.65;
    }

    .glow-bar {
      position: absolute;
      top: 0; left: 0; right: 0;
      height: 2px;
      background: linear-gradient(
        90deg,
        transparent,
        ${accentColor}80,
        ${accentColor},
        ${accentColor}80,
        transparent
      );
      border-radius: 20px 20px 0 0;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="glow-bar"></div>

    <div class="cover">
      <div class="cover-socials">
        <a href="https://x.com/pogo_os" target="_blank" aria-label="Twitter/X">
          <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.748l7.73-8.835L1.254 2.25H8.08l4.253 5.622 5.911-5.622zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
          </svg>
        </a>
      </div>
    </div>

    <div class="body">
      <div class="profile-row">
        <div class="avatar-wrap">
          <span class="avatar"></span>
        </div>
        <a class="btn-soporte" href="https://discord.gg/KsmhWnz33G" target="_blank">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
          Soporte
        </a>
      </div>

      <div class="name-row">
        <span class="name">${escapeHtml(username)}</span>
        <span class="badge-verified" title="Verificado">
          <svg viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="11" cy="11" r="11" fill="#1D9BF0"/>
            <path d="M6.5 11.5l3 3 6-6" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </span>
      </div>
      <a class="handle" href="https://x.com/pogo_os" target="_blank">@${escapeHtml(usermention)}</a>

      <div class="divider"></div>

      <div class="status-label">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          ${success
            ? '<polyline points="20 6 9 17 4 12"/>'
            : '<line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>'}
        </svg>
        ${success ? 'Verificado' : 'Error'}
      </div>
      <p class="description">${message}</p>
    </div>
  </div>
</body>
</html>`;
}
