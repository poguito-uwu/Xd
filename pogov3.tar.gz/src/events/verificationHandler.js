import {
    EmbedBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ContainerBuilder,
    SeparatorSpacingSize,
    MessageFlags,
} from 'discord.js';
import { randomUUID } from 'node:crypto';
import { buildWizardContainer, getFieldsByType } from '../commands/prefix/Verification/verify.js';

// ─── Register all verification listeners ─────────────────────────────────────

export default function registerVerificationHandler(client) {

    // ── Wizard & modal interactions ──────────────────────────────────────────
    client.on('interactionCreate', async (interaction) => {
        try {
            // Select menu: pick a field to edit
            if (interaction.isStringSelectMenu() &&
                interaction.customId.startsWith('verify_wizard_select:')) {
                return await handleWizardSelect(interaction, client);
            }

            // Button: post or cancel
            if (interaction.isButton()) {
                if (interaction.customId.startsWith('verify_wizard_post:'))
                    return await handleWizardPost(interaction, client);
                if (interaction.customId.startsWith('verify_wizard_cancel:'))
                    return await handleWizardCancel(interaction, client);
            }

            // Modal submit: field value entered
            if (interaction.isModalSubmit() &&
                interaction.customId.startsWith('verify_modal:')) {
                return await handleModalSubmit(interaction, client);
            }
        } catch (err) {
            console.error('[Verify] Interaction error:', err);
        }
    });

    // ── Reaction add: assign role ────────────────────────────────────────────
    client.on('messageReactionAdd', async (reaction, user) => {
        if (user.bot) return;
        try {
            if (reaction.partial) await reaction.fetch();
            if (reaction.message.partial) await reaction.message.fetch();
            await handleReaction(reaction, user, client, 'add');
        } catch (err) {
            console.error('[Verify] messageReactionAdd error:', err.message);
        }
    });

    // ── Reaction remove: revoke role ─────────────────────────────────────────
    client.on('messageReactionRemove', async (reaction, user) => {
        if (user.bot) return;
        try {
            if (reaction.partial) await reaction.fetch();
            if (reaction.message.partial) await reaction.message.fetch();
            await handleReaction(reaction, user, client, 'remove');
        } catch (err) {
            console.error('[Verify] messageReactionRemove error:', err.message);
        }
    });
}

// ─── Wizard: Select menu handler ──────────────────────────────────────────────

async function handleWizardSelect(interaction, client) {
    const userId = interaction.customId.split(':')[1];

    if (interaction.user.id !== userId) {
        return interaction.reply({ content: '❌ Este wizard no es tuyo.', flags: 64 });
    }

    const stateKey = `verify_wizard:${userId}:${interaction.guildId}`;
    const state = client.componentContexts.get(stateKey);

    if (!state || Date.now() > state.expiresAt) {
        client.componentContexts.delete(stateKey);
        return interaction.reply({ content: '❌ El wizard expiró. Ejecuta `!verify setup` de nuevo.', flags: 64 });
    }

    const fieldKey = interaction.values[0];

    // ── Thumbnail: toggle without modal ──
    if (fieldKey === 'thumbnail') {
        state.config.thumbnail = !state.config.thumbnail;
        client.componentContexts.set(stateKey, state);
        const container = buildWizardContainer(state);
        return interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }

    // ── All other fields: show modal ──
    const fields = getFieldsByType(state.type);
    const fieldDef = fields.find(f => f.key === fieldKey);
    if (!fieldDef) return;

    const modal = new ModalBuilder()
        .setCustomId(`verify_modal:${fieldKey}:${userId}`)
        .setTitle(`Configurar: ${fieldDef.label}`);

    const input = new TextInputBuilder()
        .setCustomId('value')
        .setLabel(fieldDef.label)
        .setStyle(fieldKey === 'description' ? TextInputStyle.Paragraph : TextInputStyle.Short)
        .setPlaceholder(fieldDef.placeholder || '')
        .setRequired(fieldDef.required)
        .setMaxLength(fieldDef.max || 1000);

    // Pre-fill current value
    const currentVal = fieldKey === 'roleId'
        ? (state.config._roleName || state.config.roleId || '')
        : (state.config[fieldKey] || '');
    if (currentVal) input.setValue(currentVal);

    modal.addComponents(new ActionRowBuilder().addComponents(input));
    await interaction.showModal(modal);
}

// ─── Wizard: Modal submit ─────────────────────────────────────────────────────

async function handleModalSubmit(interaction, client) {
    const parts = interaction.customId.split(':');
    const fieldKey = parts[1];
    const userId = parts[2];

    if (interaction.user.id !== userId) {
        return interaction.reply({ content: '❌ Este wizard no es tuyo.', flags: 64 });
    }

    const stateKey = `verify_wizard:${userId}:${interaction.guildId}`;
    const state = client.componentContexts.get(stateKey);

    if (!state || Date.now() > state.expiresAt) {
        client.componentContexts.delete(stateKey);
        return interaction.reply({ content: '❌ El wizard expiró.', flags: 64 });
    }

    const rawValue = interaction.fields.getTextInputValue('value').trim();

    // ── roleId: extract from mention or raw ID ──
    if (fieldKey === 'roleId') {
        const roleMatch = rawValue.match(/^<@&(\d+)>$/) || rawValue.match(/^(\d+)$/);
        if (!roleMatch) {
            return interaction.reply({
                content: '❌ Formato inválido. Menciona el rol (`@NombreRol`) o pega su ID numérico.',
                flags: 64,
            });
        }
        const role = interaction.guild.roles.cache.get(roleMatch[1]);
        if (!role) {
            return interaction.reply({ content: '❌ Rol no encontrado en este servidor.', flags: 64 });
        }
        state.config.roleId = role.id;
        state.config._roleName = role.name;
    } else {
        state.config[fieldKey] = rawValue || null;
    }

    client.componentContexts.set(stateKey, state);

    // Update the wizard message
    await refreshWizardMessage(interaction, state);
}

// ─── Wizard: Post button ──────────────────────────────────────────────────────

async function handleWizardPost(interaction, client) {
    const userId = interaction.customId.split(':')[1];

    if (interaction.user.id !== userId) {
        return interaction.reply({ content: '❌ Este wizard no es tuyo.', flags: 64 });
    }

    const stateKey = `verify_wizard:${userId}:${interaction.guildId}`;
    const state = client.componentContexts.get(stateKey);

    if (!state || Date.now() > state.expiresAt) {
        client.componentContexts.delete(stateKey);
        return interaction.reply({ content: '❌ El wizard expiró.', flags: 64 });
    }

    await interaction.deferUpdate();

    try {
        const guild = interaction.guild;
        const panelId = randomUUID().split('-')[0]; // short 8-char ID
        let roleId;

        // ── Linked Roles: bot creates the role ──
        if (state.type === 'linked') {
            const newRole = await guild.roles.create({
                name: state.config.roleName,
                color: 0x5865F2,
                reason: `[Verify] Linked Roles panel — creado por ${interaction.user.tag}`,
            });
            roleId = newRole.id;
        } else {
            // Reaction: use existing role
            roleId = state.config.roleId;
        }

        // ── Build the verification embed ──
        const embed = new EmbedBuilder().setColor(0x5865F2);

        if (state.config.author)
            embed.setAuthor({ name: state.config.author });
        if (state.config.title)
            embed.setTitle(state.config.title);
        if (state.config.description)
            embed.setDescription(state.config.description);
        if (state.config.thumbnail)
            embed.setThumbnail(guild.iconURL({ dynamic: true, size: 256 }));
        if (state.config.image)
            embed.setImage(state.config.image);
        if (state.config.footer)
            embed.setFooter({ text: state.config.footer });

        embed.setTimestamp();

        let sentMessage;

        if (state.type === 'linked') {
            // ── Link button → OAuth URL ──
            const dashboardUrl = process.env.DASHBOARD_URL || `http://localhost:${process.env.DASHBOARD_PORT || 3000}`;
            const verifyUrl = `${dashboardUrl}/verify?guild=${guild.id}&panel=${panelId}`;

            const btn = new ButtonBuilder()
                .setLabel(state.config.buttonLabel || 'Verificar')
                .setStyle(ButtonStyle.Link)
                .setURL(verifyUrl)
                .setEmoji('🔗');

            const row = new ActionRowBuilder().addComponents(btn);
            sentMessage = await interaction.channel.send({ embeds: [embed], components: [row] });

        } else {
            // ── Reaction panel: send embed, bot reacts ──
            sentMessage = await interaction.channel.send({ embeds: [embed] });
            const emoji = state.config.emoji || '✅';
            await sentMessage.react(emoji).catch(async () => {
                await sentMessage.react('✅'); // fallback to checkmark
            });
        }

        // ── Persist panel to DB ──
        const guildData = await client.db.findOne({ guildId: guild.id }) || {};
        const panels = guildData.verificationPanels || [];

        panels.push({
            id: panelId,
            type: state.type,
            channelId: interaction.channel.id,
            messageId: sentMessage.id,
            roleId,
            config: { ...state.config },
            createdBy: interaction.user.id,
            createdAt: Date.now(),
        });

        await client.db.updateOne(
            { guildId: guild.id },
            { $set: { verificationPanels: panels } },
            { upsert: true }
        );

        client.componentContexts.delete(stateKey);

        // ── Update wizard to success message ──
        const dashboardUrl = process.env.DASHBOARD_URL || `http://localhost:${process.env.DASHBOARD_PORT || 3000}`;
        const successContainer = new ContainerBuilder();
        successContainer.addTextDisplayComponents(td => td.setContent('# ✅ Panel Publicado'));
        successContainer.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));

        let details =
            `**Tipo:** ${state.type === 'linked' ? '🔗 Linked Roles' : '😀 Reacción'}\n` +
            `**ID del panel:** \`${panelId}\`\n` +
            `**Canal:** <#${interaction.channel.id}>\n` +
            `**Rol:** <@&${roleId}>\n\n`;

        if (state.type === 'linked') {
            details +=
                `⚠️ **Paso final:** Configura la **Linked Roles Verification URL** en el [Developer Portal](https://discord.com/developers/applications) apuntando a:\n` +
                `\`${dashboardUrl}/verify\`\n\n` +
                `También agrega \`${dashboardUrl}/verify/callback\` en **OAuth2 → Redirects**.`;
        } else {
            details += `Los usuarios que reaccionen con ${state.config.emoji || '✅'} recibirán el rol <@&${roleId}> automáticamente.`;
        }

        successContainer.addTextDisplayComponents(td => td.setContent(details));

        await interaction.editReply({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });

    } catch (err) {
        console.error('[Verify] Post error:', err);
        const errContainer = new ContainerBuilder();
        errContainer.addTextDisplayComponents(td => td.setContent('# ❌ Error al publicar'));
        errContainer.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
        errContainer.addTextDisplayComponents(td =>
            td.setContent(`Ocurrió un error: \`${err.message}\`\n\nVerifica que el bot tenga permisos para **Gestionar Roles** y que el rol de verificación esté por debajo del rol del bot.`)
        );
        await interaction.editReply({ components: [errContainer], flags: MessageFlags.IsComponentsV2 });
    }
}

// ─── Wizard: Cancel button ────────────────────────────────────────────────────

async function handleWizardCancel(interaction, client) {
    const userId = interaction.customId.split(':')[1];

    if (interaction.user.id !== userId) {
        return interaction.reply({ content: '❌ No puedes cancelar este wizard.', flags: 64 });
    }

    const stateKey = `verify_wizard:${userId}:${interaction.guildId}`;
    client.componentContexts.delete(stateKey);

    const container = new ContainerBuilder();
    container.addTextDisplayComponents(td => td.setContent('# ❌ Wizard Cancelado'));
    container.addSeparatorComponents(sep => sep.setSpacing(SeparatorSpacingSize.Small));
    container.addTextDisplayComponents(td => td.setContent('Configuración cancelada. Ejecuta `!verify setup` cuando quieras retomarlo.'));

    await interaction.update({ components: [container], flags: MessageFlags.IsComponentsV2 });
}

// ─── Reaction role handler ────────────────────────────────────────────────────

async function handleReaction(reaction, user, client, action) {
    const guildId = reaction.message.guildId;
    if (!guildId) return;

    const guildData = await client.db.findOne({ guildId });
    const panels = guildData?.verificationPanels;
    if (!panels?.length) return;

    // Find a reaction-type panel matching this message
    const panel = panels.find(p =>
        p.type === 'reaction' && p.messageId === reaction.message.id
    );
    if (!panel) return;

    // Match emoji — normalize both sides to handle variation selectors / whitespace
    const panelEmoji  = (panel.config.emoji || '✅').trim();
    const reactionId  = reaction.emoji.id;   // null for unicode emojis
    const reactionName = reaction.emoji.name;

    const normalize = (s) => String(s ?? '').replace(/[\uFE0F\uFE0E\u200D]/g, '').trim();

    let matches = false;

    if (reactionId) {
        // Custom emoji: compare by ID (stored as <:name:ID> or raw ID)
        const storedId = panelEmoji.match(/(\d{15,20})/)?.[1];
        matches = storedId ? storedId === reactionId : panelEmoji === reactionId;
    } else {
        // Unicode emoji: normalize both sides before comparing
        matches = normalize(reactionName) === normalize(panelEmoji);
    }

    if (!matches) return;

    const guild = reaction.message.guild;
    const member = await guild.members.fetch(user.id).catch(() => null);
    if (!member) return;

    const role = guild.roles.cache.get(panel.roleId);
    if (!role) return;

    const botMember = guild.members.me;
    if (!botMember?.permissions.has('ManageRoles')) return;
    if (role.position >= botMember.roles.highest.position) return;

    if (action === 'add') {
        if (!member.roles.cache.has(role.id)) {
            await member.roles.add(role, '[Verify] Reacción de verificación').catch(err =>
                console.error('[Verify] Role add error:', err.message)
            );
        }
    } else {
        if (member.roles.cache.has(role.id)) {
            await member.roles.remove(role, '[Verify] Verificación revocada').catch(err =>
                console.error('[Verify] Role remove error:', err.message)
            );
        }
    }
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

/**
 * After a modal submit, the wizard message must be edited via stored channel/message IDs.
 * We reply ephemerally to acknowledge the modal, then update the wizard.
 */
async function refreshWizardMessage(modalInteraction, state) {
    try {
        const channel = await modalInteraction.client.channels.fetch(state.wizardChannelId).catch(() => null);
        if (!channel) {
            return modalInteraction.reply({ content: '❌ No se encontró el canal del wizard.', flags: 64 });
        }

        const wizardMsg = await channel.messages.fetch(state.wizardMessageId).catch(() => null);
        if (!wizardMsg) {
            return modalInteraction.reply({ content: '❌ El mensaje del wizard ya no existe.', flags: 64 });
        }

        const container = buildWizardContainer(state);

        // Acknowledge modal without a visible reply, then edit the original wizard message
        await modalInteraction.deferReply({ flags: 64 });
        await wizardMsg.edit({ components: [container], flags: MessageFlags.IsComponentsV2 });
        await modalInteraction.deleteReply().catch(() => {});

    } catch (err) {
        console.error('[Verify] refreshWizardMessage error:', err);
        await modalInteraction.reply({ content: '❌ Error al actualizar el wizard.', flags: 64 }).catch(() => {});
    }
}
