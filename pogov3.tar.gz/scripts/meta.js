/**
 * scripts/register-linked-roles-metadata.js
 * ─────────────────────────────────────────────────────────
 * Run ONCE (or whenever you change the metadata schema):
 *
 *   node scripts/register-linked-roles-metadata.js
 *
 * Requires: DISCORD_CLIENT_ID + DISCORD_BOT_TOKEN in .env
 */

import { config as loadEnv } from 'dotenv';
loadEnv();

const APP_ID   = process.env.DISCORD_CLIENT_ID;
const BOT_TOKEN = process.env.DISCORD_TOKEN;

if (!APP_ID || !BOT_TOKEN) {
    console.error('❌ Missing DISCORD_CLIENT_ID or DISCORD_TOKEN in .env');
    process.exit(1);
}

const metadata = [
    {
        key:         'verified',
        name:        'Verificado',
        description: 'El usuario completó la verificación del servidor',
        type:        7,   // BOOLEAN_EQUAL
    },
];

const url = `https://discord.com/api/v10/applications/${APP_ID}/role-connections/metadata`;

const res = await fetch(url, {
    method:  'PUT',
    headers: {
        Authorization:  `Bot ${BOT_TOKEN}`,
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(metadata),
});

if (res.ok) {
    const data = await res.json();
    console.log('✅ Metadata registrada correctamente:');
    console.log(JSON.stringify(data, null, 2));
} else {
    const err = await res.json().catch(() => ({}));
    console.error(`❌ Error ${res.status}:`, JSON.stringify(err, null, 2));
    process.exit(1);
}