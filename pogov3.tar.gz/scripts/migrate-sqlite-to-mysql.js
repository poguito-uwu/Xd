/**
 * migrate-sqlite-to-mysql.js
 * ──────────────────────────
 * Migra todos los datos de SQLite (data/ares.db) → MySQL.
 * 
 * Uso:
 *   node scripts/migrate-sqlite-to-mysql.js
 * 
 * Variables de entorno requeridas (igual que el bot):
 *   DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD
 *   o DATABASE_URL=mysql://user:pass@host:port/dbname
 */

import { createRequire } from 'module';
import path from 'path';
import { fileURLToPath } from 'url';
import mysql from 'mysql2/promise';

const require = createRequire(import.meta.url);
const Database = require('better-sqlite3');

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const SQLITE_PATH = path.join(__dirname, '..', 'data', 'ares.db');

// ── MySQL connection ──────────────────────────────────────────────────────────
async function createMySQLConnection() {
    if (process.env.DATABASE_URL) {
        return mysql.createConnection({ uri: process.env.DATABASE_URL });
    }
    return mysql.createConnection({
        host:     process.env.DB_HOST     || 'localhost',
        port:     parseInt(process.env.DB_PORT) || 3306,
        database: process.env.DB_NAME     || 'ares_bot',
        user:     process.env.DB_USER     || 'root',
        password: process.env.DB_PASSWORD || '',
    });
}

// ── Ensure tables exist ───────────────────────────────────────────────────────
async function ensureTables(conn) {
    await conn.query(`CREATE TABLE IF NOT EXISTS guilds (
        guildId   VARCHAR(255) PRIMARY KEY,
        data      JSON         NOT NULL,
        createdAt DATETIME     DEFAULT CURRENT_TIMESTAMP,
        updatedAt DATETIME     DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`);

    await conn.query(`CREATE TABLE IF NOT EXISTS moderation (
        id          INT AUTO_INCREMENT PRIMARY KEY,
        guildId     VARCHAR(255) NOT NULL,
        userId      VARCHAR(255) NOT NULL,
        moderatorId VARCHAR(255) NOT NULL,
        action      VARCHAR(50)  NOT NULL,
        reason      TEXT,
        timestamp   DATETIME     DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (guildId) REFERENCES guilds(guildId)
    )`);
    console.log('✅ Tablas MySQL verificadas/creadas');
}

// ── Migrate guilds ────────────────────────────────────────────────────────────
async function migrateGuilds(sqlite, conn) {
    const rows = sqlite.prepare('SELECT guildId, data, createdAt, updatedAt FROM guilds').all();
    console.log(`📦 Migrando ${rows.length} guilds...`);

    let ok = 0, skip = 0, err = 0;

    for (const row of rows) {
        try {
            // Validate JSON
            let parsedData;
            try {
                parsedData = typeof row.data === 'string' ? JSON.parse(row.data) : row.data;
            } catch {
                console.warn(`  ⚠️  guildId ${row.guildId}: JSON inválido, se omite`);
                skip++;
                continue;
            }

            await conn.query(
                `INSERT INTO guilds (guildId, data, createdAt, updatedAt)
                 VALUES (?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE data = VALUES(data), updatedAt = VALUES(updatedAt)`,
                [
                    row.guildId,
                    JSON.stringify(parsedData),
                    row.createdAt || new Date().toISOString().slice(0, 19).replace('T', ' '),
                    row.updatedAt || new Date().toISOString().slice(0, 19).replace('T', ' '),
                ]
            );
            ok++;
        } catch (e) {
            console.error(`  ❌ guildId ${row.guildId}:`, e.message);
            err++;
        }
    }

    console.log(`  ✅ ${ok} insertados | ⚠️  ${skip} omitidos | ❌ ${err} errores`);
}

// ── Migrate moderation ────────────────────────────────────────────────────────
async function migrateModeration(sqlite, conn) {
    const rows = sqlite.prepare('SELECT * FROM moderation').all();
    if (rows.length === 0) {
        console.log('ℹ️  Tabla moderation vacía, nada que migrar');
        return;
    }
    console.log(`📦 Migrando ${rows.length} registros de moderación...`);

    let ok = 0, err = 0;
    for (const row of rows) {
        try {
            await conn.query(
                `INSERT IGNORE INTO moderation (id, guildId, userId, moderatorId, action, reason, timestamp)
                 VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [row.id, row.guildId, row.userId, row.moderatorId, row.action, row.reason || null, row.timestamp]
            );
            ok++;
        } catch (e) {
            console.error(`  ❌ moderation id ${row.id}:`, e.message);
            err++;
        }
    }
    console.log(`  ✅ ${ok} insertados | ❌ ${err} errores`);
}

// ── Main ──────────────────────────────────────────────────────────────────────
(async () => {
    console.log('\n🔄 Iniciando migración SQLite → MySQL\n');

    // Open SQLite
    let sqlite;
    try {
        sqlite = new Database(SQLITE_PATH, { readonly: true });
        // Checkpoint WAL
        try { sqlite.pragma('wal_checkpoint(FULL)'); } catch (_) {}
        console.log(`✅ SQLite abierto: ${SQLITE_PATH}`);
    } catch (e) {
        console.error('❌ No se pudo abrir SQLite:', e.message);
        process.exit(1);
    }

    // Connect MySQL
    let conn;
    try {
        conn = await createMySQLConnection();
        await conn.connect();
        const [[dbRow]] = await conn.query('SELECT DATABASE() AS db');
        console.log(`✅ MySQL conectado → base de datos: ${dbRow.db}\n`);
    } catch (e) {
        console.error('❌ No se pudo conectar a MySQL:', e.message);
        process.exit(1);
    }

    try {
        await ensureTables(conn);
        await migrateGuilds(sqlite, conn);
        await migrateModeration(sqlite, conn);

        // Verify
        const [[{ total }]] = await conn.query('SELECT COUNT(*) AS total FROM guilds');
        console.log(`\n🎉 Migración completada. Total guilds en MySQL: ${total}`);
    } catch (e) {
        console.error('❌ Error durante la migración:', e.message);
    } finally {
        sqlite.close();
        await conn.end();
    }
})();
