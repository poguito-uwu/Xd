// ================================================
// ARES SQLite Admin Panel - Configuración
// ================================================

module.exports = {
    // Puerto del servidor
    port: process.env.PORT || 3000,
    
    // Contraseña de acceso (CAMBIAR en producción)
    password: process.env.ADMIN_PASSWORD || 'admin123',
    
    // Ruta a la base de datos
    dbPath: process.env.DB_PATH || '../data/ares.db',
    
    // Secret para sesiones (CAMBIAR en producción)
    sessionSecret: process.env.SESSION_SECRET || 'ares-admin-panel-secret-key-2026',
    
    // Límite de registros por página
    recordsPerPage: 50,
    
    // Configuración de sesión
    session: {
        resave: false,
        saveUninitialized: false,
        cookie: {
            secure: false, // Cambiar a true si usas HTTPS
            maxAge: 24 * 60 * 60 * 1000 // 24 horas
        }
    }
};
