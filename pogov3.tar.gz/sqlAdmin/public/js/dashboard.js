// ================================================
// ARES SQLite Admin Panel 2026 - Dashboard JS
// ================================================

// Actualizar reloj en tiempo real
function updateTime() {
    const timeElement = document.getElementById('current-time');
    if (timeElement) {
        const now = new Date();
        const timeString = now.toLocaleTimeString('es-ES', { 
            hour: '2-digit', 
            minute: '2-digit' 
        });
        timeElement.textContent = timeString;
    }
}

// Función para exportar tabla
function exportTable(tableName) {
    window.open(`/api/export/${tableName}`, '_blank');
}

// Toggle sidebar en móvil
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
}

// Cerrar sidebar al hacer click fuera en móvil
document.addEventListener('click', (e) => {
    const sidebar = document.getElementById('sidebar');
    const btnMenu = document.querySelector('.btn-menu');
    
    if (window.innerWidth <= 1024 && sidebar && sidebar.classList.contains('open')) {
        if (!sidebar.contains(e.target) && !btnMenu.contains(e.target)) {
            sidebar.classList.remove('open');
        }
    }
});

// Inicializar
document.addEventListener('DOMContentLoaded', () => {
    updateTime();
    setInterval(updateTime, 1000);
    
    // Animación de entrada de tarjetas
    const cards = document.querySelectorAll('.stat-card, .table-card');
    cards.forEach((card, index) => {
        setTimeout(() => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            setTimeout(() => {
                card.style.transition = 'all 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 50);
        }, index * 50);
    });
});
