// ================================================
// ARES SQLite Admin Panel 2026 - Table JS
// ================================================

// Toggle sidebar en móvil
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('open');
}

// Función para exportar tabla
function exportTable(tableName) {
    window.open(`/api/export/${tableName}`, '_blank');
}

// Cerrar sidebar al hacer click fuera en móvil
document.addEventListener('click', (e) => {
    const sidebar = document.getElementById('sidebar');
    const btnMenu = document.querySelector('.btn-menu');
    
    if (window.innerWidth <= 1024 && sidebar && sidebar.classList.contains('open')) {
        if (!sidebar.contains(e.target) && !btnMenu.contains(e.target)) {
            sidebar.classList.remove('open');
        }
    }
});

// Animación de entrada de filas
document.addEventListener('DOMContentLoaded', () => {
    const rows = document.querySelectorAll('.data-table tbody tr');
    rows.forEach((row, index) => {
        setTimeout(() => {
            row.style.opacity = '0';
            row.style.transform = 'translateX(-20px)';
            setTimeout(() => {
                row.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
                row.style.opacity = '1';
                row.style.transform = 'translateX(0)';
            }, 50);
        }, index * 30);
    });
});
