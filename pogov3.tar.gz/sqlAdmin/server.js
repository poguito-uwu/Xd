import express from 'express';
import path from 'path';
import mysql from 'mysql2/promise';
import bodyParser from 'body-parser';
import session from 'express-session';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname  = path.dirname(__filename);

const app  = express();
const PORT = 25461;

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('sqlAdmin/public'));
app.use(session({
    secret: 'ares-admin-panel-secret-key-2026',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ── Auth ──────────────────────────────────────────────────────────────────────
const AUTH_PASSWORD = process.env.ADMIN_PANEL_PASSWORD || '33476373Dr*';

function requireAuth(req, res, next) {
    if (req.session.authenticated) return next();
    res.redirect('/login');
}

// ── MySQL pool (shared) ───────────────────────────────────────────────────────
function createPool() {
    if (process.env.DATABASE_URL) {
        return mysql.createPool({ uri: process.env.DATABASE_URL });
    }
    return mysql.createPool({
        host:     process.env.DB_HOST     || 'localhost',
        port:     parseInt(process.env.DB_PORT) || 3306,
        database: process.env.DB_NAME     || 'ares_bot',
        user:     process.env.DB_USER     || 'root',
        password: process.env.DB_PASSWORD || '',
        ssl:      process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : undefined,
        waitForConnections: true,
        connectionLimit: 5,
    });
}

let pool;
try { pool = createPool(); } catch (e) { console.error('MySQL pool error:', e.message); }

// ── Auth routes ───────────────────────────────────────────────────────────────
app.get('/login', (req, res) => res.render('login', { error: null }));

app.post('/login', (req, res) => {
    if (req.body.password === AUTH_PASSWORD) {
        req.session.authenticated = true;
        res.redirect('/');
    } else {
        res.render('login', { error: 'Contraseña incorrecta' });
    }
});

app.get('/logout', (req, res) => { req.session.destroy(); res.redirect('/login'); });

// ── Dashboard ─────────────────────────────────────────────────────────────────
app.get('/', requireAuth, async (req, res) => {
    try {
        // Get all user tables
        const [tables] = await pool.query(
            `SELECT TABLE_NAME AS name, TABLE_ROWS AS \`rows\`, DATA_LENGTH + INDEX_LENGTH AS size_bytes
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE()
             ORDER BY TABLE_NAME`
        );

        // Accurate row counts
        const tableStats = await Promise.all(tables.map(async t => {
            const [[{ count }]] = await pool.query(`SELECT COUNT(*) AS count FROM \`${t.name}\``);
            return { name: t.name, count };
        }));

        // DB size in MB
        const [[sizeRow]] = await pool.query(
            `SELECT SUM(DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024 AS size_mb
             FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE()`
        );
        const dbSize = parseFloat(sizeRow.size_mb || 0).toFixed(2);

        res.render('dashboard', { tables, dbSize, tableStats });
    } catch (err) {
        res.status(500).send('Error al obtener tablas: ' + err.message);
    }
});

// ── Table view ────────────────────────────────────────────────────────────────
app.get('/table/:name', requireAuth, async (req, res) => {
    const tableName = req.params.name;
    const page   = parseInt(req.query.page) || 1;
    const limit  = 50;
    const offset = (page - 1) * limit;

    try {
        const [[{ total }]] = await pool.query(`SELECT COUNT(*) AS total FROM \`${tableName}\``);
        const totalPages = Math.ceil(total / limit);

        const [rows]    = await pool.query(`SELECT * FROM \`${tableName}\` LIMIT ? OFFSET ?`, [limit, offset]);
        const [colMeta] = await pool.query(`DESCRIBE \`${tableName}\``);

        // Map to same format the EJS template expects (compatible with old SQLite PRAGMA format)
        const columns = colMeta.map(c => ({
            name: c.Field,
            type: c.Type,
            pk:   c.Key === 'PRI' ? 1 : 0,
            notnull: c.Null === 'NO' ? 1 : 0,
            dflt_value: c.Default,
        }));

        res.render('table', { tableName, columns, rows, currentPage: page, totalPages, total });
    } catch (err) {
        res.status(500).send('Error: ' + err.message);
    }
});

// ── API: custom SQL query ─────────────────────────────────────────────────────
app.post('/api/query', requireAuth, async (req, res) => {
    const { query } = req.body;
    try {
        const isSelect = query.trim().toLowerCase().startsWith('select');
        const [result] = await pool.query(query);
        if (isSelect) {
            res.json({ success: true, data: result });
        } else {
            res.json({ success: true, message: 'Consulta ejecutada correctamente', changes: result.affectedRows, lastID: result.insertId });
        }
    } catch (err) {
        res.json({ success: false, error: err.message });
    }
});

// ── API: get record ───────────────────────────────────────────────────────────
app.get('/api/record/:table/:id', requireAuth, async (req, res) => {
    const { table, id } = req.params;
    try {
        const [colMeta] = await pool.query(`DESCRIBE \`${table}\``);
        const pkCol = colMeta.find(c => c.Key === 'PRI');
        const pkName = pkCol ? pkCol.Field : 'id';
        const columns = colMeta.map(c => ({ name: c.Field, type: c.Type, pk: c.Key === 'PRI' ? 1 : 0 }));
        const [[row]] = await pool.query(`SELECT * FROM \`${table}\` WHERE \`${pkName}\` = ?`, [id]);
        res.json({ success: true, data: row || null, columns });
    } catch (err) {
        res.json({ success: false, error: err.message });
    }
});

// ── API: update record ────────────────────────────────────────────────────────
app.put('/api/record/:table/:id', requireAuth, async (req, res) => {
    const { table, id } = req.params;
    const data = req.body;
    try {
        const [colMeta] = await pool.query(`DESCRIBE \`${table}\``);
        const pkCol  = colMeta.find(c => c.Key === 'PRI');
        const pkName = pkCol ? pkCol.Field : 'id';
        const sets   = Object.keys(data).map(k => `\`${k}\` = ?`).join(', ');
        const values = [...Object.values(data), id];
        const [result] = await pool.query(`UPDATE \`${table}\` SET ${sets} WHERE \`${pkName}\` = ?`, values);
        res.json({ success: true, changes: result.affectedRows });
    } catch (err) {
        res.json({ success: false, error: err.message });
    }
});

// ── API: insert record ────────────────────────────────────────────────────────
app.post('/api/record/:table', requireAuth, async (req, res) => {
    const { table } = req.params;
    const data = req.body;
    try {
        const cols = Object.keys(data).map(k => `\`${k}\``).join(', ');
        const placeholders = Object.keys(data).map(() => '?').join(', ');
        const [result] = await pool.query(
            `INSERT INTO \`${table}\` (${cols}) VALUES (${placeholders})`,
            Object.values(data)
        );
        res.json({ success: true, lastID: result.insertId });
    } catch (err) {
        res.json({ success: false, error: err.message });
    }
});

// ── API: delete record ────────────────────────────────────────────────────────
app.delete('/api/record/:table/:id', requireAuth, async (req, res) => {
    const { table, id } = req.params;
    try {
        const [colMeta] = await pool.query(`DESCRIBE \`${table}\``);
        const pkCol  = colMeta.find(c => c.Key === 'PRI');
        const pkName = pkCol ? pkCol.Field : 'id';
        const [result] = await pool.query(`DELETE FROM \`${table}\` WHERE \`${pkName}\` = ?`, [id]);
        res.json({ success: true, changes: result.affectedRows });
    } catch (err) {
        res.json({ success: false, error: err.message });
    }
});

// ── API: export table as JSON ─────────────────────────────────────────────────
app.get('/api/export/:table', requireAuth, async (req, res) => {
    const { table } = req.params;
    try {
        const [rows] = await pool.query(`SELECT * FROM \`${table}\``);
        res.setHeader('Content-Type', 'application/json');
        res.setHeader('Content-Disposition', `attachment; filename="${table}.json"`);
        res.send(JSON.stringify(rows, null, 2));
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// ── API: table structure ──────────────────────────────────────────────────────
app.get('/api/structure/:table', requireAuth, async (req, res) => {
    const { table } = req.params;
    try {
        const [colMeta] = await pool.query(`DESCRIBE \`${table}\``);
        const columns = colMeta.map(c => ({ name: c.Field, type: c.Type, pk: c.Key === 'PRI' ? 1 : 0 }));
        res.json({ success: true, columns });
    } catch (err) {
        res.json({ success: false, error: err.message });
    }
});

// ── Start ─────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
    const db = process.env.DB_NAME || 'ares_bot';
    const host = process.env.DB_HOST || 'localhost';
    console.log(`
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║        🚀 ARES MySQL Admin Panel - 2026 🚀           ║
║                                                       ║
║  Server running on: http://localhost:${PORT}          ║
║  Database: ${db}@${host}                             
║                                                       ║
╚═══════════════════════════════════════════════════════╝
    `);
});

export default app;
