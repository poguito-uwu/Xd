# 🚀 ARES SQLite Admin Panel 2026

Panel de administración moderno y elegante para bases de datos SQLite con diseño glassmorphism.

## ✨ Características

- ✅ **Dashboard Interactivo**: Visualiza estadísticas y tablas en tiempo real
- ✅ **Gestión Completa CRUD**: Crear, leer, actualizar y eliminar registros
- ✅ **Ejecutor SQL**: Ejecuta consultas SQL personalizadas desde la interfaz
- ✅ **Exportación JSON**: Descarga cualquier tabla como archivo JSON
- ✅ **Diseño Moderno 2026**: Glassmorphism, dark mode y animaciones fluidas
- ✅ **Responsive**: Funciona perfecto en desktop, tablet y móvil
- ✅ **Paginación**: Manejo eficiente de grandes volúmenes de datos
- ✅ **Autenticación**: Sistema de login con contraseña

## 📦 Instalación

### 1. Clonar o copiar los archivos

Coloca la carpeta `sqlite-admin-panel` en tu proyecto.

### 2. Estructura requerida

```
tu-proyecto/
├── data/
│   ├── sessions/
│   ├── ares.db
│   ├── ares.db-shm
│   └── ares.db-wal
└── sqlite-admin-panel/
    ├── public/
    │   ├── css/
    │   │   └── styles.css
    │   └── js/
    │       ├── dashboard.js
    │       └── table.js
    ├── views/
    │   ├── partials/
    │   │   ├── header.ejs
    │   │   ├── sidebar.ejs
    │   │   ├── query-modal.ejs
    │   │   └── edit-modal.ejs
    │   ├── login.ejs
    │   ├── dashboard.ejs
    │   └── table.ejs
    ├── package.json
    └── server.js
```

### 3. Instalar dependencias

```bash
cd sqlite-admin-panel
npm install
```

### 4. Configuración

Edita `server.js` y cambia la contraseña:

```javascript
const AUTH_PASSWORD = 'admin123'; // ⚠️ CAMBIAR ESTO
```

También puedes cambiar el puerto:

```javascript
const PORT = process.env.PORT || 3000;
```

### 5. Iniciar el panel

```bash
npm start
```

O para desarrollo con auto-recarga:

```bash
npm run dev
```

## 🎯 Uso

### Acceder al Panel

1. Abre tu navegador en `http://localhost:3000`
2. Ingresa la contraseña (default: `admin123`)
3. ¡Listo! Ya puedes gestionar tu base de datos

### Funcionalidades

#### 🏠 Dashboard
- Visualiza todas las tablas de tu base de datos
- Estadísticas generales (total de tablas, registros, tamaño)
- Acceso rápido a cada tabla
- Exportación de tablas a JSON

#### 📊 Vista de Tabla
- Lista todos los registros con paginación (50 por página)
- Información de columnas (nombre, tipo, primary key)
- Editar registros existentes
- Crear nuevos registros
- Eliminar registros con confirmación

#### 💻 Ejecutor SQL
- Ejecuta cualquier consulta SQL
- Resultados en tabla o mensaje de éxito
- Ejemplos rápidos incluidos
- Manejo de errores detallado

## 🔒 Seguridad

**IMPORTANTE**: Este panel está diseñado para uso local o en redes privadas.

Para producción, considera:
- Cambiar la contraseña predeterminada
- Implementar HTTPS
- Agregar más capas de autenticación
- Limitar acceso por IP
- Usar variables de entorno para credenciales

## 🎨 Personalización

### Cambiar Colores

Edita `public/css/styles.css` en las variables CSS:

```css
:root {
    --accent-blue: #4f97ff;
    --accent-purple: #9b59ff;
    --accent-green: #00d88f;
    /* ... más colores */
}
```

### Cambiar Logo

Edita el SVG en `views/partials/header.ejs` y `views/login.ejs`.

## 📱 Screenshots

El panel incluye:
- ✨ Animaciones suaves y transiciones
- 🌌 Fondo animado con estrellas
- 💎 Efectos glassmorphism
- 🎯 Interfaz intuitiva y moderna
- 📱 Diseño responsive

## 🛠️ Tecnologías

- **Backend**: Node.js + Express
- **Base de datos**: SQLite3
- **Template Engine**: EJS
- **Frontend**: HTML5 + CSS3 + JavaScript vanilla
- **Diseño**: Glassmorphism + Dark Mode

## 📝 API Endpoints

El panel expone estos endpoints:

### Autenticación
- `GET /login` - Página de login
- `POST /login` - Autenticar usuario
- `GET /logout` - Cerrar sesión

### Vistas
- `GET /` - Dashboard principal
- `GET /table/:name` - Ver tabla específica

### API REST
- `POST /api/query` - Ejecutar consulta SQL
- `GET /api/record/:table/:id` - Obtener registro
- `PUT /api/record/:table/:id` - Actualizar registro
- `POST /api/record/:table` - Insertar registro
- `DELETE /api/record/:table/:id` - Eliminar registro
- `GET /api/export/:table` - Exportar tabla como JSON
- `GET /api/structure/:table` - Obtener estructura de tabla

## ⚙️ Configuración Avanzada

### Cambiar ruta de la base de datos

En `server.js`:

```javascript
const DB_PATH = path.join(__dirname, 'tu-ruta', 'tu-base.db');
```

### Cambiar límite de paginación

En `server.js`, busca:

```javascript
const limit = 50; // Cambiar este valor
```

### Deshabilitar autenticación (no recomendado)

Comenta la línea `requireAuth` en las rutas:

```javascript
app.get('/', /* requireAuth, */ (req, res) => {
```

## 🐛 Solución de Problemas

### Error: Cannot find module 'sqlite3'

```bash
npm install sqlite3 --build-from-source
```

### Error: ENOENT: no such file or directory

Verifica que la ruta a la base de datos sea correcta en `server.js`.

### La base de datos está bloqueada

Asegúrate de que no haya otro proceso usando la base de datos.

## 📄 Licencia

MIT License - Libre para uso personal y comercial.

## 👨‍💻 Soporte

Para reportar bugs o solicitar características, crea un issue o contacta al desarrollador.

---

**Hecho con ❤️ usando diseño 2026**
